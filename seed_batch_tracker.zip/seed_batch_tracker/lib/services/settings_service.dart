import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// Cấu hình trỏ tới 1 THƯ MỤC trên GitHub (không phải 1 file cụ thể).
/// Thư mục này có thể chứa nhiều file batch khác nhau (nhiều file JSON
/// cumulative theo từng lần scan, nhiều file .json batch theo từng kỳ) -
/// app sẽ tự liệt kê và xử lý tất cả.
class GithubConfig {
  final String owner; // vd: thuantn005
  final String repo; // vd: lotto-scan
  final String branch; // vd: main
  final String folderPath; // vd: results  (hoặc "" nếu ở gốc repo)

  GithubConfig({
    required this.owner,
    required this.repo,
    required this.branch,
    required this.folderPath,
  });

  /// URL GitHub API để liệt kê nội dung thư mục.
  String get apiListUrl {
    final path = folderPath.trim();
    final cleanPath = path.isEmpty ? '' : '/$path';
    return 'https://api.github.com/repos/$owner/$repo/contents$cleanPath?ref=$branch';
  }

  bool get isValid => owner.isNotEmpty && repo.isNotEmpty && branch.isNotEmpty;

  Map<String, dynamic> toJson() => {
        'owner': owner,
        'repo': repo,
        'branch': branch,
        'folderPath': folderPath,
      };

  factory GithubConfig.fromJson(Map<String, dynamic> json) => GithubConfig(
        owner: json['owner'] as String? ?? '',
        repo: json['repo'] as String? ?? '',
        branch: json['branch'] as String? ?? 'main',
        folderPath: json['folderPath'] as String? ?? '',
      );

  factory GithubConfig.empty() =>
      GithubConfig(owner: '', repo: '', branch: 'main', folderPath: '');
}

class SettingsService {
  static const _fileName = 'github_config.json';

  Future<File> _getFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$_fileName');
  }

  Future<GithubConfig> loadConfig() async {
    try {
      final file = await _getFile();
      if (!await file.exists()) return GithubConfig.empty();
      final content = await file.readAsString();
      if (content.trim().isEmpty) return GithubConfig.empty();
      return GithubConfig.fromJson(jsonDecode(content) as Map<String, dynamic>);
    } catch (e) {
      return GithubConfig.empty();
    }
  }

  Future<void> saveConfig(GithubConfig config) async {
    final file = await _getFile();
    await file.writeAsString(jsonEncode(config.toJson()));
  }
}
