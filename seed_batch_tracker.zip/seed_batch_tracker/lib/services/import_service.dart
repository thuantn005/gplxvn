import 'dart:convert';
import 'dart:io';

import '../models/batch.dart';

class ImportService {
  /// Parse 1 file JSON batch (đúng format scanner C++ thật xuất ra, ví dụ
  /// output của chế độ EXACT_ONLY=1 cho 1 kỳ cụ thể):
  ///
  /// {
  ///   "status": "completed",
  ///   "scan_start": ..., "scan_end": ..., "scanned": ...,
  ///   "found": 1022,
  ///   "results": [
  ///     {
  ///       "seed": 494594670382,
  ///       "j1_count": 1,
  ///       "jackpot1_hits": [
  ///         {"draw_id": 816, "draw_date": "2026-08-10",
  ///          "numbers": [2,8,22,23,30], "special": 12}
  ///       ]
  ///     },
  ///     ...
  ///   ]
  /// }
  ///
  /// Toàn bộ seed trong "results" của 1 file được coi là 1 batch, gắn với
  /// kỳ lấy từ jackpot1_hits[0] của phần tử đầu tiên (mọi seed trong file
  /// EXACT_ONLY cho 1 kỳ đều cùng chung 1 kỳ trúng).
  static Batch parseNewBatchContent(String content) {
    late final Map<String, dynamic> data;
    try {
      data = jsonDecode(content) as Map<String, dynamic>;
    } catch (e) {
      throw FormatException('File không phải JSON hợp lệ: $e');
    }

    final results = data['results'] as List<dynamic>?;
    if (results == null || results.isEmpty) {
      throw const FormatException('File JSON không có "results" hoặc rỗng');
    }

    final first = results.first as Map<String, dynamic>;
    final firstHits = first['jackpot1_hits'] as List<dynamic>?;
    if (firstHits == null || firstHits.isEmpty) {
      throw const FormatException(
          'Không tìm thấy "jackpot1_hits" trong phần tử đầu tiên');
    }
    final firstHit = firstHits.first as Map<String, dynamic>;

    final kyId = firstHit['draw_id'] as int;
    final kyDate = firstHit['draw_date'] as String;
    final kyNumbers =
        (firstHit['numbers'] as List).map((e) => e as int).toList();
    final kySpecial = firstHit['special'] as int;

    final seeds = <int>{};
    for (final r in results) {
      final map = r as Map<String, dynamic>;
      final seed = map['seed'] as int;
      seeds.add(seed);
    }

    if (seeds.isEmpty) {
      throw const FormatException('Không tìm thấy seed nào trong file');
    }

    return Batch(
      kyId: kyId,
      kyDate: kyDate,
      kyNumbers: kyNumbers,
      kySpecial: kySpecial,
      seeds: seeds,
      importedAt: DateTime.now(),
    );
  }

  /// Wrapper đọc từ file trên máy (chọn thủ công qua file_picker) - vẫn giữ
  /// để phòng khi cần import tay 1 batch ngoài luồng đồng bộ GitHub.
  static Future<Batch> parseNewBatchFile(File file) async {
    final content = await file.readAsString();
    return parseNewBatchContent(content);
  }
}
