import 'dart:math';

import 'package:flutter/material.dart';

import '../models/batch.dart';
import '../services/sync_service.dart';
import '../services/ticket_formula.dart';
import 'settings_screen.dart';

/// Sinh MỘT SỐ ÍT vé (1-5) từ pool gộp seed của TẤT CẢ batch đang active.
/// Mỗi lần bấm "Sinh vé": app TỰ ĐỘNG tải file mới nhất từ GitHub, chạy lại
/// retirement check trên toàn bộ batch, rồi mới chọn ngẫu nhiên seed trong
/// pool (chỉ từ batch còn active) để tính vé.
class AllBatchesTicketsScreen extends StatefulWidget {
  const AllBatchesTicketsScreen({super.key});

  @override
  State<AllBatchesTicketsScreen> createState() =>
      _AllBatchesTicketsScreenState();
}

class _AllBatchesTicketsScreenState extends State<AllBatchesTicketsScreen> {
  final _drawIdController = TextEditingController();
  final _sync = SyncService();
  int _ticketCount = 3; // 1-5
  List<_TicketWithSource>? _tickets;
  bool _computing = false;
  String? _syncInfo;
  int? _lastDrawId;
  List<Batch> _activeBatches = [];

  Future<void> _generate() async {
    final drawId = int.tryParse(_drawIdController.text.trim());
    if (drawId == null) {
      _showMessage('Nhập số kỳ hợp lệ (vd: 846)');
      return;
    }

    setState(() {
      _computing = true;
      _syncInfo = 'Đang tải dữ liệu mới nhất từ GitHub...';
      _tickets = null;
    });

    try {
      final outcome = await _sync.syncNow();
      _activeBatches = outcome.activeBatches;

      // Gộp toàn bộ seed từ các batch active thành 1 pool (kèm nguồn batch),
      // rồi chọn ngẫu nhiên tối đa _ticketCount seed - KHÔNG sinh hết pool.
      final pool = <_SeedWithSource>[];
      for (final batch in _activeBatches) {
        for (final seed in batch.seeds) {
          pool.add(_SeedWithSource(seed: seed, sourceKyId: batch.kyId));
        }
      }
      pool.shuffle(Random.secure());
      final picked = pool.take(_ticketCount).toList();

      final results = picked
          .map((p) => _TicketWithSource(
                ticket: TicketFormula.generate(p.seed, drawId),
                sourceKyId: p.sourceKyId,
              ))
          .toList();

      final removedCount = outcome.removedBatches.length;
      final newCount = outcome.newBatches.length;

      setState(() {
        _tickets = results;
        _lastDrawId = drawId;
        _computing = false;
        _syncInfo =
            'Đã đồng bộ GitHub xong. ${_activeBatches.length} batch active, ${pool.length} seed trong pool.'
            '${newCount > 0 ? ' Mới: $newCount batch.' : ''}'
            '${removedCount > 0 ? ' Đã gỡ: $removedCount batch.' : ''}';
      });
    } on GithubNotConfiguredException catch (e) {
      setState(() {
        _computing = false;
        _syncInfo = null;
      });
      _showMessage(e.message);
      final ok = await Navigator.push<bool>(
        context,
        MaterialPageRoute(builder: (_) => const SettingsScreen()),
      );
      if (ok == true) _generate();
    } catch (e) {
      setState(() {
        _computing = false;
        _syncInfo = null;
      });
      _showMessage('Lỗi đồng bộ: $e');
    }
  }

  void _showMessage(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sinh vé — tất cả batch')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Mỗi lần sinh vé sẽ tự đồng bộ GitHub, loại bỏ batch vừa '
                  'trúng lần 2, rồi CHỌN NGẪU NHIÊN tối đa 5 seed trong pool '
                  'gộp của các batch còn active để tính vé (không sinh hết '
                  'toàn bộ pool — tránh nặng máy).',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: TextField(
                        controller: _drawIdController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'Kỳ muốn sinh vé (vd: 846)',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      flex: 1,
                      child: DropdownButtonFormField<int>(
                        initialValue: _ticketCount,
                        decoration: const InputDecoration(
                          labelText: 'Số vé',
                          border: OutlineInputBorder(),
                        ),
                        items: [1, 2, 3, 4, 5]
                            .map((n) => DropdownMenuItem(
                                value: n, child: Text('$n')))
                            .toList(),
                        onChanged: (v) {
                          if (v != null) setState(() => _ticketCount = v);
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _computing ? null : _generate,
                    child: _computing
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Text('Sinh $_ticketCount vé'),
                  ),
                ),
                if (_syncInfo != null) ...[
                  const SizedBox(height: 8),
                  Text(_syncInfo!,
                      style: const TextStyle(fontSize: 12, color: Colors.orange)),
                ],
              ],
            ),
          ),
          const Divider(height: 1),
          if (_tickets != null && _tickets!.isNotEmpty && _lastDrawId != null)
            Container(
              width: double.infinity,
              color: Colors.indigo.withOpacity(0.08),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Text(
                'Dự đoán cho KỲ $_lastDrawId  •  công thức: ticket(seed, $_lastDrawId)  •  ${_tickets!.length} vé',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              ),
            ),
          Expanded(
            child: _tickets == null
                ? const Center(
                    child: Text('Nhập số kỳ rồi bấm "Sinh vé" để xem kết quả.'),
                  )
                : _tickets!.isEmpty
                    ? const Center(child: Text('Không có vé nào để hiển thị.'))
                    : ListView.builder(
                        itemCount: _tickets!.length,
                        itemBuilder: (context, i) {
                          final item = _tickets![i];
                          final t = item.ticket;
                          return Card(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 4),
                            child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Vé #${i + 1}  •  Kỳ ${t.drawId}  •  từ batch kỳ ${item.sourceKyId}',
                                        style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12,
                                            color: Colors.indigo),
                                      ),
                                      Chip(
                                        label: Text('ĐB ${t.special}'),
                                        visualDensity: VisualDensity.compact,
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    t.numbers
                                        .map((n) => n.toString().padLeft(2, '0'))
                                        .join('  '),
                                    style: const TextStyle(
                                        fontFamily: 'monospace',
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 4),
                                  SelectableText(
                                    'seed: ${t.seed}',
                                    style: const TextStyle(
                                        fontSize: 11, color: Colors.grey),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

class _SeedWithSource {
  final int seed;
  final int sourceKyId;
  _SeedWithSource({required this.seed, required this.sourceKyId});
}

class _TicketWithSource {
  final TicketResult ticket;
  final int sourceKyId;
  _TicketWithSource({required this.ticket, required this.sourceKyId});
}
