import 'package:flutter/material.dart';

import '../services/settings_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _settingsService = SettingsService();
  final _ownerCtrl = TextEditingController();
  final _repoCtrl = TextEditingController();
  final _branchCtrl = TextEditingController(text: 'main');
  final _pathCtrl = TextEditingController();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await _settingsService.loadConfig();
    _ownerCtrl.text = cfg.owner;
    _repoCtrl.text = cfg.repo;
    _branchCtrl.text = cfg.branch.isEmpty ? 'main' : cfg.branch;
    _pathCtrl.text = cfg.jsonPath;
    setState(() => _loading = false);
  }

  Future<void> _save() async {
    final cfg = GithubConfig(
      owner: _ownerCtrl.text.trim(),
      repo: _repoCtrl.text.trim(),
      branch: _branchCtrl.text.trim().isEmpty ? 'main' : _branchCtrl.text.trim(),
      jsonPath: _pathCtrl.text.trim(),
    );
    await _settingsService.saveConfig(cfg);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Đã lưu cấu hình GitHub.')));
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final previewUrl =
        'https://raw.githubusercontent.com/${_ownerCtrl.text}/${_repoCtrl.text}/${_branchCtrl.text}/${_pathCtrl.text}';

    return Scaffold(
      appBar: AppBar(title: const Text('Cấu hình GitHub')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Trỏ tới file JSON cumulative (final_j1_2plus...json) trong repo '
            'GitHub của bạn. App sẽ tự tải file này mỗi khi bấm "Đồng bộ" hoặc '
            '"Sinh vé" để lấy dữ liệu retirement mới nhất.',
            style: TextStyle(fontSize: 13, color: Colors.grey),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _ownerCtrl,
            decoration: const InputDecoration(
              labelText: 'GitHub owner',
              hintText: 'vd: thuantn005',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _repoCtrl,
            decoration: const InputDecoration(
              labelText: 'Repo',
              hintText: 'vd: lotto-scan',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _branchCtrl,
            decoration: const InputDecoration(
              labelText: 'Branch',
              hintText: 'vd: main',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _pathCtrl,
            decoration: const InputDecoration(
              labelText: 'Đường dẫn file JSON trong repo',
              hintText: 'vd: results/final_j1_2plus.json',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 16),
          if (_ownerCtrl.text.isNotEmpty &&
              _repoCtrl.text.isNotEmpty &&
              _pathCtrl.text.isNotEmpty) ...[
            const Text('URL sẽ tải:',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
            const SizedBox(height: 4),
            SelectableText(previewUrl,
                style: const TextStyle(fontSize: 12, color: Colors.blue)),
          ],
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save),
            label: const Text('Lưu cấu hình'),
          ),
        ],
      ),
    );
  }
}
