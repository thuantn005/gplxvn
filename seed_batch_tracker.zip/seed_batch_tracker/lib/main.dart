import 'package:flutter/material.dart';

import 'screens/home_screen.dart';

void main() {
  runApp(const SeedBatchTrackerApp());
}

class SeedBatchTrackerApp extends StatelessWidget {
  const SeedBatchTrackerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Seed Batch Tracker (cá nhân)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
