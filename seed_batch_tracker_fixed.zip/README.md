# Seed Batch Tracker (dùng cá nhân)

Công cụ theo dõi thủ công quy tắc bạn đặt ra:
- Mỗi **batch** = toàn bộ tập seed trúng J1 **đúng 1 lần**, tại 1 kỳ cụ thể.
- Khi **bất kỳ 1 seed nào** trong batch trúng J1 **lần 2**, **toàn bộ batch** bị đánh dấu "Đã loại".

App **không tự scan** (không chạy lại thuật toán quét seed) — dữ liệu batch/seed
đều lấy từ pipeline C++/GitHub Actions hiện tại của bạn, import thủ công vào app.

App **CÓ tự sinh vé**: với mỗi batch (hoặc gộp tất cả batch active), nhập kỳ
mục tiêu → app tính `ticket(seed, kỳ)` cho **toàn bộ seed thuộc batch đó**
(seed lấy từ dữ liệu GitHub, không sinh seed ngẫu nhiên mới trên máy).
Công thức sinh vé (`lib/services/ticket_formula.dart`) port chính xác từ
`scan_j1.cpp` (SplitMix64 + colex unranking), dùng BigInt để đảm bảo đúng số
học 64-bit.

**Tự động đồng bộ GitHub**: mỗi lần bấm "Sinh vé" (ở màn 1 batch hoặc màn
"tất cả batch"), app sẽ TỰ ĐỘNG tải file JSON cumulative mới nhất từ GitHub
(`SettingsService` lưu owner/repo/branch/path, `GithubService` tải qua
`raw.githubusercontent.com`), chạy lại retirement check trên toàn bộ batch,
rồi mới lấy seed của các batch còn active để tính vé — đảm bảo không bao giờ
vô tình dùng seed của 1 batch vừa bị loại (trúng lần 2) mà không hay biết.
Cũng có nút "Đồng bộ GitHub" riêng trên trang chính để đồng bộ thủ công bất
cứ lúc nào, không cần sinh vé.

Cấu hình GitHub: bấm icon ⚙️ (Cài đặt) trên trang chính, nhập:
- **owner**: vd `thuantn005`
- **repo**: vd `lotto-scan`
- **branch**: vd `main`
- **Đường dẫn file JSON**: vd `results/final_j1_2plus.json` (đường dẫn tới
  file cumulative trong repo — chỉnh theo đúng path thật trong repo của bạn)

⚠️ Lưu ý quan trọng: đây là công cụ theo dõi thống kê cá nhân, **không phải công cụ
dự đoán**. Việc 1 seed từng trúng 1 lần không làm tăng xác suất nó trúng kỳ tiếp theo.
Không dùng app này để tư vấn hay chia sẻ "gợi ý mua vé" cho người khác.

## Quyền cần thiết (Android)

Vì app tải file từ GitHub qua Internet, cần thêm quyền vào
`android/app/src/main/AndroidManifest.xml` (trong thẻ `<manifest>`, trước
`<application>`):

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

## Build APK tự động trên GitHub (không cần cài Flutter, không cần làm gì thủ công)

Project này **chỉ chứa code Dart** (`lib/`, `pubspec.yaml`) — không có sẵn
khung Android. Nhưng bạn KHÔNG cần tự tạo khung đó: workflow
`.github/workflows/build_apk.yml` sẽ tự động làm việc này ngay trong lúc
build trên GitHub.

### Cách dùng — chỉ cần up 1 file zip, KHÔNG cần tự giải nén

1. Tạo 1 repo mới trên GitHub (vd `seed-batch-tracker`).
2. **Lần đầu tiên duy nhất**: cần đưa file workflow vào đúng vị trí
   `.github/workflows/build_apk.yml` trong repo, vì GitHub Actions chỉ nhận
   diện được workflow khi nó nằm thật ở đường dẫn đó (không thể để trong
   zip rồi tự đăng ký được) — 2 cách:
   - **Cách dễ nhất**: vào repo trên GitHub → **Add file → Upload files**
     → kéo thả **cả file `seed_batch_tracker.zip` gốc lẫn thư mục `.github`**
     đã giải nén cùng lúc vào ô upload (trình duyệt GitHub hỗ trợ kéo thả
     nguyên thư mục, tự giữ đúng đường dẫn `.github/workflows/build_apk.yml`).
   - Hoặc dùng GitHub Codespaces / git: copy riêng thư mục `.github` vào
     repo trước, rồi up file zip sau.
3. Từ lần thứ 2 trở đi: mỗi khi bạn có bản code mới, chỉ cần **up đè file
   `.zip`** lên repo (Add file → Upload files → chọn file zip mới) —
   KHÔNG cần giải nén tay, KHÔNG cần kéo lại `.github` nữa (đã có sẵn từ
   trước). Workflow tự động:
   - Tìm file `.zip` bất kỳ ở gốc repo
   - Tự giải nén, tìm đúng thư mục chứa `pubspec.yaml` bên trong (dù zip
     có bọc thêm 1 lớp thư mục con hay không)
   - Copy toàn bộ ra gốc repo rồi build tiếp như bình thường
4. Vào tab **Actions** trên repo → workflow "Build APK" tự chạy khi có
   push mới. Đợi ~5-10 phút → vào lần chạy đó → mục **Artifacts** → tải
   file `.apk` về, chuyển vào điện thoại Android cài (cần bật "Cài từ
   nguồn không xác định" trong Settings nếu máy hỏi).

Workflow sẽ tự động:
- Tìm & giải nén file `.zip` (nếu có) ngay trong lúc build
- Tạo khung Android (Gradle, AndroidManifest...) bằng Flutter SDK
- Ghim version Gradle 8.6 / AGP 8.3.0 / Kotlin 1.9.24 (giống app Ôn Thi GPLX)
- Thêm quyền Internet vào AndroidManifest (app cần gọi GitHub API)
- `flutter pub get` + `flutter build apk --release`
- Đóng gói APK thành artifact để tải về

Muốn tự động tạo hẳn 1 **GitHub Release** kèm APK (gọn hơn, khỏi vào tab
Actions mỗi lần): sau khi push/up file, gắn thêm tag (qua GitHub Codespaces
hoặc git):
```bash
git tag v1.0.0
git push --tags
```

## Build thủ công (nếu bạn có sẵn Flutter local)

```bash
cd seed_batch_tracker
flutter pub get
flutter run          # chạy trên máy/emulator đang kết nối
# hoặc build APK cài trực tiếp:
flutter build apk --release
```

APK sau khi build nằm ở: `build/app/outputs/flutter-apk/app-release.apk`

## Định dạng file batch (JSON — đúng format scanner C++ xuất ra)

Mỗi file `.json` trong thư mục GitHub bạn cấu hình = 1 batch (kết quả scan
`EXACT_ONLY=1 MIN_LOG=1` cho 1 kỳ cụ thể). Đúng format thật scanner
`scan_j1.cpp` xuất ra (file `..._j1_1plus.json`):

```json
{
  "status": "completed",
  "scan_start": 494593816501,
  "scan_end": 498488256000,
  "scanned": 3894439500,
  "found": 1022,
  "results": [
    {
      "seed": 494594670382,
      "j1_count": 1,
      "jackpot1_hits": [
        {"draw_id": 816, "draw_date": "2026-08-10",
         "numbers": [2, 8, 22, 23, 30], "special": 12}
      ]
    },
    { "seed": 494594697097, "j1_count": 1, "jackpot1_hits": [ ... ] },
    ...
  ]
}
```

App lấy kỳ/kết quả (`kyId`, `kyDate`, `kyNumbers`, `kySpecial`) từ
`results[0].jackpot1_hits[0]`, và toàn bộ `results[i].seed` làm tập seed
của batch.

**Không cần check retirement trong app**: pipeline GitHub Actions của bạn
tự chịu trách nhiệm xóa file `.json` của batch nào đã hết hạn (seed trong
đó trúng lần 2) trước khi publish lên thư mục. App chỉ đơn giản đồng bộ
đúng những gì đang có trong thư mục — file nào biến mất thì batch đó cũng
tự biến mất khỏi app.

## Cấu trúc project

```
lib/
  models/batch.dart                  - model dữ liệu 1 batch
  services/import_service.dart       - parse file batch .json
  services/storage_service.dart      - lưu local (JSON file trong app documents)
  services/settings_service.dart     - lưu cấu hình GitHub (owner/repo/branch/thư mục)
  services/github_service.dart       - liệt kê + tải file .json từ GitHub
  services/sync_service.dart         - đồng bộ danh sách batch từ thư mục GitHub
  services/ticket_formula.dart       - port công thức ticket(seed,draw_id) từ scan_j1.cpp
  screens/home_screen.dart               - danh sách batch + đồng bộ
  screens/settings_screen.dart           - cấu hình GitHub
  screens/batch_detail_screen.dart       - chi tiết + tra cứu seed trong batch
  screens/batch_tickets_screen.dart      - sinh vé từ 1 batch (auto-sync trước khi sinh)
  screens/all_batches_tickets_screen.dart - sinh vé gộp tất cả batch active (auto-sync trước)
  main.dart
```

Dữ liệu lưu hoàn toàn local trên máy (file `batches.json` trong thư mục
documents riêng của app) — không đồng bộ mạng, không gửi đi đâu.
