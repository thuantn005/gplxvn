import 'dart:math';

/// Port chính xác công thức sinh vé từ seed, y hệt logic trong scan_j1.cpp:
///
///   combined = (seed * M1 + draw_id * M2) mod 2^64
///   mixed    = splitmix64_mix(combined)
///   rank     = mixed mod C(35,5)
///   [5 số]   = unrank_colex(rank)
///   mixed2   = splitmix64_mix(mixed)
///   special  = (mixed2 mod 12) + 1
///
/// Dùng BigInt cho toàn bộ phép toán 64-bit để tránh lỗi dấu (sign) khi
/// Dart biểu diễn số nguyên 64-bit có dấu. Đã verify khớp 100% với scanner
/// C++ gốc (scan_j1.cpp) trên nhiều seed/kỳ thật.
class TicketFormula {
  static final BigInt _mask64 = (BigInt.one << 64) - BigInt.one;
  static final BigInt _m1 = BigInt.parse('9E3779B97F4A7C15', radix: 16);
  static final BigInt _m2 = BigInt.parse('D1B54A32D192ED03', radix: 16);
  static final BigInt _m3 = BigInt.parse('BF58476D1CE4E5B9', radix: 16);
  static final BigInt _m4 = BigInt.parse('94D049BB133111EB', radix: 16);

  static final List<List<BigInt>> _binom = _buildBinomial();

  static List<List<BigInt>> _buildBinomial() {
    final b = List.generate(
        36, (_) => List<BigInt>.filled(6, BigInt.zero, growable: false));
    for (var n = 0; n < 36; n++) {
      for (var k = 0; k < 6; k++) {
        if (k == 0) {
          b[n][k] = BigInt.one;
        } else if (k > n) {
          b[n][k] = BigInt.zero;
        } else {
          BigInt num = BigInt.one;
          BigInt den = BigInt.one;
          for (var i = 0; i < k; i++) {
            num *= BigInt.from(n - i);
            den *= BigInt.from(i + 1);
          }
          b[n][k] = num ~/ den;
        }
      }
    }
    return b;
  }

  static const int _c3535 = 324632; // C(35,5)

  static BigInt _mix64(BigInt x) {
    x = x & _mask64;
    x = x ^ (x >> 30);
    x = (x * _m3) & _mask64;
    x = x ^ (x >> 27);
    x = (x * _m4) & _mask64;
    x = x ^ (x >> 31);
    return x & _mask64;
  }

  static List<int> _rankToNumbers(int rank) {
    final numbers = <int>[];
    var rem = BigInt.from(rank);
    for (var k = 5; k >= 1; k--) {
      var x = k - 1;
      while (_binom[x + 1][k] <= rem) {
        x += 1;
      }
      numbers.add(x + 1); // 1-based
      rem -= _binom[x][k];
    }
    numbers.sort();
    return numbers;
  }

  /// Sinh vé (5 số chính 1-35 + 1 số đặc biệt 1-12) từ 1 seed và 1 kỳ (draw_id).
  /// seed truyền vào là int thường (đủ dùng vì mọi seed thực tế < 2^63).
  static TicketResult generate(int seed, int drawId) {
    final seedBig = BigInt.from(seed);
    final combined = ((seedBig * _m1) + (BigInt.from(drawId) * _m2)) & _mask64;
    final mixed = _mix64(combined);
    final rank = (mixed % BigInt.from(_c3535)).toInt();
    final numbers = _rankToNumbers(rank);
    final mixed2 = _mix64(mixed);
    final special = (mixed2 % BigInt.from(12)).toInt() + 1;
    return TicketResult(
        seed: seed, drawId: drawId, numbers: numbers, special: special);
  }

  /// Sinh hàng loạt cho 1 danh sách seed + 1 kỳ. Hàm top-level thuần túy
  /// (không phụ thuộc state ngoài) để dùng được với `compute()` — chạy
  /// trong 1 isolate riêng, KHÔNG block UI thread chính dù danh sách lớn.
  static List<TicketResult> generateBatch(GenerateBatchArgs args) {
    return args.seeds
        .map((s) => TicketFormula.generate(s, args.drawId))
        .toList();
  }

  /// Sinh 1 seed ngẫu nhiên (64-bit không dấu, dùng Random.secure()).
  static BigInt randomSeed() {
    final rnd = Random.secure();
    final hi = rnd.nextInt(1 << 32);
    final lo = rnd.nextInt(1 << 32);
    return (BigInt.from(hi) << 32) | BigInt.from(lo);
  }
}

/// Tham số truyền vào isolate qua compute(). Phải là dữ liệu đơn giản,
/// transferable được giữa các isolate (List<int>, int đều ổn).
class GenerateBatchArgs {
  final List<int> seeds;
  final int drawId;
  GenerateBatchArgs({required this.seeds, required this.drawId});
}

class TicketResult {
  final int seed;
  final int drawId;
  final List<int> numbers; // 5 số, đã sort tăng dần
  final int special;

  TicketResult({
    required this.seed,
    required this.drawId,
    required this.numbers,
    required this.special,
  });
}
