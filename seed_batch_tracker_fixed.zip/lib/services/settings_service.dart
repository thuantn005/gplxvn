import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// Cấu hình trỏ tới 1 FILE JSON DUY NHẤT trên GitHub (không còn là thư mục
/// nhiều file nữa). File này là kết quả gộp (l1_merged/merged_seed*.json)
/// chứa TẤT CẢ các kỳ trong 1 file, mỗi kỳ là 1 phần tử trong mảng "draws".
///
/// Tải qua raw.githubusercontent.com (KHÔNG qua GitHub API liệt kê thư mục
/// nữa) — chỉ 1 request HTTP duy nhất mỗi lần đồng bộ, không còn bị giới
/// hạn 60 request/giờ của GitHub API khi trước có 850 file phải liệt kê +
/// tải riêng lẻ.
class GithubConfig {
  final String owner; // vd: thuantn005
  final String repo; // vd: lotto-scan
  final String branch; // vd: main
  final String filePath; // vd: l1_merged/merged_seed682305800400.json

  GithubConfig({
    required this.owner,
    required this.repo,
    required this.branch,
    required this.filePath,
  });

  /// URL raw để tải trực tiếp nội dung file (1 request duy nhất).
  String get rawFileUrl {
    final path = filePath.trim();
    return 'https://raw.githubusercontent.com/$owner/$repo/$branch/$path';
  }

  bool get isValid =>
      owner.isNotEmpty && repo.isNotEmpty && branch.isNotEmpty && filePath.isNotEmpty;

  Map<String, dynamic> toJson() => {
        'owner': owner,
        'repo': repo,
        'branch': branch,
        'filePath': filePath,
      };

  factory GithubConfig.fromJson(Map<String, dynamic> json) => GithubConfig(
        owner: json['owner'] as String? ?? '',
        repo: json['repo'] as String? ?? '',
        branch: json['branch'] as String? ?? 'main',
        // Tuong thich nguoc: neu config cu con luu 'folderPath' (thu muc l1),
        // tu dong chuyen sang duong dan file l1_merged moi.
        filePath: json['filePath'] as String? ??
            (json['folderPath'] == 'l1'
                ? 'l1_merged/merged_seed682305800400.json'
                : ''),
      );

  factory GithubConfig.empty() => GithubConfig(
        owner: 'thuantn005',
        repo: 'lotto-scan',
        branch: 'main',
        filePath: 'l1_merged/merged_seed682305800400.json',
      );
}

class SettingsService {
  static const _fileName = 'github_config.json';

  Future<File> _getFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$_fileName');
  }

  Future<GithubConfig> loadConfig() async {
    try {
      final file = await _getFile();
      if (!await file.exists()) return GithubConfig.empty();
      final content = await file.readAsString();
      if (content.trim().isEmpty) return GithubConfig.empty();
      final cfg = GithubConfig.fromJson(jsonDecode(content) as Map<String, dynamic>);
      return cfg.isValid ? cfg : GithubConfig.empty();
    } catch (e) {
      return GithubConfig.empty();
    }
  }

  Future<void> saveConfig(GithubConfig config) async {
    final file = await _getFile();
    await file.writeAsString(jsonEncode(config.toJson()));
  }
}
