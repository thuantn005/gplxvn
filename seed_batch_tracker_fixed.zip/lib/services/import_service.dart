import 'dart:convert';
import 'dart:io';

import '../models/batch.dart';

class ImportService {
  /// Parse file GỘP MỚI (1 file DUY NHẤT chứa TẤT CẢ các kỳ, do
  /// scan_per_draw.cpp xuất ra):
  /// {
  ///   "seed_start": 682305800400,
  ///   "seed_end": 683863576199,
  ///   "total_draws": 850,
  ///   "total_found": 12345,
  ///   "draws": [
  ///     {"draw_id": 1, "draw_date": "2025-06-29", "found": 400, "seeds": [...]},
  ///     {"draw_id": 2, "draw_date": "2025-06-29", "found": 395, "seeds": [...]},
  ///     ...
  ///   ]
  /// }
  ///
  /// Trả về 1 Batch cho MỖI kỳ trong mảng "draws". Kỳ nào có "seeds" rỗng
  /// (đã bị loại bỏ hết vì thăng hạng sang l2, hoặc chưa có seed nào trúng)
  /// sẽ bị bỏ qua, không tạo Batch rỗng.
  static List<Batch> parseMergedFileContent(String content) {
    late final Map<String, dynamic> data;
    try {
      data = jsonDecode(content) as Map<String, dynamic>;
    } catch (e) {
      throw FormatException('File không phải JSON hợp lệ: $e');
    }

    final drawsRaw = data['draws'] as List?;
    if (drawsRaw == null) {
      throw const FormatException(
          'File JSON không đúng định dạng: thiếu mảng "draws" (format gộp mới)');
    }

    final batches = <Batch>[];
    for (final item in drawsRaw) {
      final map = item as Map<String, dynamic>;
      final kyId = map['draw_id'] as int?;
      final kyDate = map['draw_date'] as String?;
      final seedsRaw = map['seeds'] as List?;
      if (kyId == null || kyDate == null) continue;
      if (seedsRaw == null || seedsRaw.isEmpty) continue; // bo qua ky rong

      batches.add(Batch(
        kyId: kyId,
        kyDate: kyDate,
        kyNumbers: null,
        kySpecial: null,
        seeds: seedsRaw.map((e) => e as int).toSet(),
        importedAt: DateTime.now(),
      ));
    }

    if (batches.isEmpty) {
      throw const FormatException(
          'File gộp không chứa kỳ nào có seed (tất cả đều rỗng hoặc đã thăng hạng)');
    }
    return batches;
  }

  /// Parse 1 file JSON batch ĐƠN LẺ (định dạng cũ, mỗi file = 1 kỳ).
  /// Hỗ trợ 2 format cũ để tương thích ngược (import tay file cũ nếu còn):
  ///
  /// FORMAT CŨ NHẤT (scanner đời đầu, EXACT_ONLY=1 cho 1 kỳ cụ thể):
  /// {
  ///   "status": "completed", "found": 1022,
  ///   "results": [{"seed":..., "j1_count":..., "jackpot1_hits":[...]}]
  /// }
  ///
  /// FORMAT CŨ (scan_per_draw.cpp bản 850-file, mỗi file = 1 kỳ):
  /// {
  ///   "draw_id": 848, "draw_date": "2026-08-26",
  ///   "seed_start": ..., "seed_end": ..., "found": 8047,
  ///   "seeds": [...]
  /// }
  static Batch parseNewBatchContent(String content) {
    late final Map<String, dynamic> data;
    try {
      data = jsonDecode(content) as Map<String, dynamic>;
    } catch (e) {
      throw FormatException('File không phải JSON hợp lệ: $e');
    }

    // FORMAT CU (850-file): co "seeds" la mang so nguyen truc tiep + "draw_id" o goc
    if (data.containsKey('seeds') && data['draw_id'] != null) {
      final kyId = data['draw_id'] as int;
      final kyDate = data['draw_date'] as String? ?? '';
      final seedsRaw = data['seeds'] as List?;
      if (seedsRaw == null || seedsRaw.isEmpty) {
        throw const FormatException('File JSON không có "seeds" hoặc rỗng');
      }
      final seeds = seedsRaw.map((e) => e as int).toSet();

      return Batch(
        kyId: kyId,
        kyDate: kyDate,
        kyNumbers: null,
        kySpecial: null,
        seeds: seeds,
        importedAt: DateTime.now(),
      );
    }

    // FORMAT CU NHAT: "results" -> moi phan tu co "jackpot1_hits"
    final results = data['results'] as List<dynamic>?;
    if (results == null || results.isEmpty) {
      throw const FormatException(
          'File JSON không đúng định dạng: thiếu "seeds" (format cũ) '
          'lẫn "results" (format cũ nhất) lẫn "draws" (format gộp mới)');
    }

    final first = results.first as Map<String, dynamic>;
    final firstHits = first['jackpot1_hits'] as List<dynamic>?;
    if (firstHits == null || firstHits.isEmpty) {
      throw const FormatException(
          'Không tìm thấy "jackpot1_hits" trong phần tử đầu tiên');
    }
    final firstHit = firstHits.first as Map<String, dynamic>;

    final kyId = firstHit['draw_id'] as int;
    final kyDate = firstHit['draw_date'] as String;
    final kyNumbers =
        (firstHit['numbers'] as List).map((e) => e as int).toList();
    final kySpecial = firstHit['special'] as int;

    final seeds = <int>{};
    for (final r in results) {
      final map = r as Map<String, dynamic>;
      final seed = map['seed'] as int;
      seeds.add(seed);
    }

    if (seeds.isEmpty) {
      throw const FormatException('Không tìm thấy seed nào trong file');
    }

    return Batch(
      kyId: kyId,
      kyDate: kyDate,
      kyNumbers: kyNumbers,
      kySpecial: kySpecial,
      seeds: seeds,
      importedAt: DateTime.now(),
    );
  }

  /// Wrapper đọc từ file trên máy (chọn thủ công qua file_picker). Tự động
  /// nhận diện: nếu file có "draws" ở gốc -> format gộp mới (trả về Batch
  /// đầu tiên tìm được kèm cảnh báo, khuyên dùng đồng bộ GitHub thay vì
  /// import tay cho format này); ngược lại parse như 1 batch đơn lẻ.
  static Future<Batch> parseNewBatchFile(File file) async {
    final content = await file.readAsString();
    return parseNewBatchContent(content);
  }

  /// Wrapper đọc file gộp (nhiều kỳ) từ máy qua file_picker.
  static Future<List<Batch>> parseMergedFile(File file) async {
    final content = await file.readAsString();
    return parseMergedFileContent(content);
  }
}
