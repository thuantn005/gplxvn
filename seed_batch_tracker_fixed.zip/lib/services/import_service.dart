import 'dart:convert';
import 'dart:io';

import '../models/batch.dart';

class ImportService {
  /// Parse 1 file JSON batch. Hỗ trợ 2 format:
  ///
  /// FORMAT CŨ (scanner đời đầu, EXACT_ONLY=1 cho 1 kỳ cụ thể):
  /// {
  ///   "status": "completed",
  ///   "found": 1022,
  ///   "results": [
  ///     {
  ///       "seed": 494594670382,
  ///       "j1_count": 1,
  ///       "jackpot1_hits": [
  ///         {"draw_id": 816, "draw_date": "2026-08-10",
  ///          "numbers": [2,8,22,23,30], "special": 12}
  ///       ]
  ///     },
  ///     ...
  ///   ]
  /// }
  ///
  /// FORMAT MỚI (scan_v2.cpp, mỗi file = 1 batch của 1 kỳ):
  /// {
  ///   "draw_id": 848,
  ///   "draw_date": "2026-08-26",
  ///   "seed_start": 31155516001,
  ///   "seed_end": 62311032000,
  ///   "found": 8047,
  ///   "seeds": [31160596007, 31163433078, ...]
  /// }
  /// (format mới không mang theo 5 số + đặc biệt thật của kỳ, nên
  /// kyNumbers/kySpecial sẽ là null với batch loại này)
  static Batch parseNewBatchContent(String content) {
    late final Map<String, dynamic> data;
    try {
      data = jsonDecode(content) as Map<String, dynamic>;
    } catch (e) {
      throw FormatException('File không phải JSON hợp lệ: $e');
    }

    // FORMAT MỚI: có "seeds" là mảng số nguyên trực tiếp + "draw_id" ở gốc
    if (data.containsKey('seeds') && data['draw_id'] != null) {
      final kyId = data['draw_id'] as int;
      final kyDate = data['draw_date'] as String? ?? '';
      final seedsRaw = data['seeds'] as List?;
      if (seedsRaw == null || seedsRaw.isEmpty) {
        throw const FormatException('File JSON không có "seeds" hoặc rỗng');
      }
      final seeds = seedsRaw.map((e) => e as int).toSet();

      return Batch(
        kyId: kyId,
        kyDate: kyDate,
        kyNumbers: null,
        kySpecial: null,
        seeds: seeds,
        importedAt: DateTime.now(),
      );
    }

    // FORMAT CŨ: "results" -> mỗi phần tử có "jackpot1_hits"
    final results = data['results'] as List<dynamic>?;
    if (results == null || results.isEmpty) {
      throw const FormatException(
          'File JSON không đúng định dạng: thiếu "seeds" (format mới) '
          'lẫn "results" (format cũ)');
    }

    final first = results.first as Map<String, dynamic>;
    final firstHits = first['jackpot1_hits'] as List<dynamic>?;
    if (firstHits == null || firstHits.isEmpty) {
      throw const FormatException(
          'Không tìm thấy "jackpot1_hits" trong phần tử đầu tiên');
    }
    final firstHit = firstHits.first as Map<String, dynamic>;

    final kyId = firstHit['draw_id'] as int;
    final kyDate = firstHit['draw_date'] as String;
    final kyNumbers =
        (firstHit['numbers'] as List).map((e) => e as int).toList();
    final kySpecial = firstHit['special'] as int;

    final seeds = <int>{};
    for (final r in results) {
      final map = r as Map<String, dynamic>;
      final seed = map['seed'] as int;
      seeds.add(seed);
    }

    if (seeds.isEmpty) {
      throw const FormatException('Không tìm thấy seed nào trong file');
    }

    return Batch(
      kyId: kyId,
      kyDate: kyDate,
      kyNumbers: kyNumbers,
      kySpecial: kySpecial,
      seeds: seeds,
      importedAt: DateTime.now(),
    );
  }

  /// Wrapper đọc từ file trên máy (chọn thủ công qua file_picker) - vẫn giữ
  /// để phòng khi cần import tay 1 batch ngoài luồng đồng bộ GitHub.
  static Future<Batch> parseNewBatchFile(File file) async {
    final content = await file.readAsString();
    return parseNewBatchContent(content);
  }
}
