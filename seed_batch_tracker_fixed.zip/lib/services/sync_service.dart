import '../models/batch.dart';
import 'github_service.dart';
import 'import_service.dart';
import 'settings_service.dart';
import 'storage_service.dart';

class GithubNotConfiguredException implements Exception {
  final String message;
  GithubNotConfiguredException([this.message = 'Chưa cấu hình GitHub.']);
  @override
  String toString() => message;
}

/// Đồng bộ: tải 1 FILE JSON DUY NHẤT (l1_merged/merged_seed*.json) qua
/// raw.githubusercontent.com — không còn liệt kê thư mục qua GitHub API
/// (vốn giới hạn 60 request/giờ, không chịu nổi 850 file như trước).
///
/// File gộp chứa TẤT CẢ các kỳ trong 1 lần tải. Kỳ nào có mặt trong file
/// (còn seed) -> active; kỳ nào từng có ở local nhưng seeds đã rỗng hoặc
/// biến mất khỏi file (do thăng hạng sang l2, seed hết hạn) -> gỡ khỏi
/// danh sách local, mirror đúng 100% theo GitHub.
class SyncService {
  final _settings = SettingsService();
  final _github = GithubService();
  final _storage = StorageService();

  Future<SyncOutcome> syncNow() async {
    final cfg = await _settings.loadConfig();
    if (!cfg.isValid) {
      throw GithubNotConfiguredException(
          'Chưa cấu hình GitHub (owner/repo/đường dẫn file). Vào mục Cài đặt để thiết lập.');
    }

    final localBatches = await _storage.loadBatches();
    final localByKy = {for (final b in localBatches) b.kyId: b};

    List<Batch> remoteBatches;
    try {
      final content = await _github.fetchRaw(cfg.rawFileUrl);
      remoteBatches = ImportService.parseMergedFileContent(content);
    } catch (e) {
      throw Exception('Không tải/đọc được file gộp trên GitHub: $e');
    }

    final newBatches = <Batch>[];
    final seenKyIds = <int>{};
    for (final b in remoteBatches) {
      seenKyIds.add(b.kyId);
      if (!localByKy.containsKey(b.kyId)) {
        newBatches.add(b);
      }
    }

    // Batch nào tung co o local nhung gio khong con trong file remote nua
    // (da thang hang sang l2, hoac bi loai) -> coi la da mat, go khoi danh sach.
    final removedBatches =
        localBatches.where((b) => !seenKyIds.contains(b.kyId)).toList();

    await _storage.saveBatches(remoteBatches);

    return SyncOutcome(
      allBatches: remoteBatches,
      newBatches: newBatches,
      removedBatches: removedBatches,
      parseErrors: const [],
    );
  }
}

class SyncOutcome {
  final List<Batch> allBatches;
  final List<Batch> newBatches;
  final List<Batch> removedBatches;
  final List<String> parseErrors;

  SyncOutcome({
    required this.allBatches,
    required this.newBatches,
    required this.removedBatches,
    this.parseErrors = const [],
  });

  List<Batch> get activeBatches => allBatches; // tất cả batch trong list đều active
}
