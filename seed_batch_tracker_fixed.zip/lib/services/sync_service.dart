import '../models/batch.dart';
import 'github_service.dart';
import 'import_service.dart';
import 'settings_service.dart';
import 'storage_service.dart';

class GithubNotConfiguredException implements Exception {
  final String message;
  GithubNotConfiguredException([this.message = 'Chưa cấu hình GitHub.']);
  @override
  String toString() => message;
}

/// Đồng bộ: liệt kê toàn bộ file .json trong thư mục GitHub đã cấu hình,
/// mỗi file = 1 batch ĐANG ACTIVE (pipeline trên GitHub đã tự loại các
/// batch hết hạn trước khi publish, nên app KHÔNG cần tự check retirement
/// nữa — chỉ cần đồng bộ danh sách theo đúng những gì đang có trên GitHub).
///
/// Batch nào có trên máy nhưng không còn file tương ứng trên GitHub sẽ được
/// coi là đã bị loại phía server và tự động gỡ khỏi danh sách local.
class SyncService {
  final _settings = SettingsService();
  final _github = GithubService();
  final _storage = StorageService();

  Future<SyncOutcome> syncNow() async {
    final cfg = await _settings.loadConfig();
    if (!cfg.isValid) {
      throw GithubNotConfiguredException(
          'Chưa cấu hình GitHub (owner/repo/thư mục). Vào mục Cài đặt để thiết lập.');
    }

    final remoteFiles = await _github.listJsonFiles(cfg.apiListUrl);

    final localBatches = await _storage.loadBatches();
    final localByKy = {for (final b in localBatches) b.kyId: b};

    final newBatches = <Batch>[];
    final resultBatches = <Batch>[];
    final seenKyIds = <int>{};
    final parseErrors = <String>[];

    for (final f in remoteFiles) {
      try {
        final content = await _github.fetchRaw(f.downloadUrl);
        final batch = ImportService.parseNewBatchContent(content);

        if (seenKyIds.contains(batch.kyId)) continue; // trùng, bỏ qua
        seenKyIds.add(batch.kyId);

        if (!localByKy.containsKey(batch.kyId)) {
          newBatches.add(batch);
        }
        resultBatches.add(batch);
      } catch (e) {
        // Ghi lại lỗi để báo cho người dùng, nhưng không làm hỏng cả lần sync
        parseErrors.add('${f.name}: $e');
        continue;
      }
    }

    // Batch nào từng có ở local nhưng giờ không còn file trên GitHub nữa
    // (hoặc không parse được) -> coi là đã bị loại phía server, gỡ khỏi
    // danh sách. App luôn mirror đúng 100% theo GitHub, kể cả khi toàn bộ
    // file remote lỗi parse (list rỗng thì local cũng rỗng).
    final removedBatches = localBatches
        .where((b) => !seenKyIds.contains(b.kyId))
        .toList();

    await _storage.saveBatches(resultBatches);

    return SyncOutcome(
      allBatches: resultBatches,
      newBatches: newBatches,
      removedBatches: removedBatches,
      parseErrors: parseErrors,
    );
  }
}

class SyncOutcome {
  final List<Batch> allBatches;
  final List<Batch> newBatches;
  final List<Batch> removedBatches;
  final List<String> parseErrors;

  SyncOutcome({
    required this.allBatches,
    required this.newBatches,
    required this.removedBatches,
    this.parseErrors = const [],
  });

  List<Batch> get activeBatches => allBatches; // tất cả batch trong list đều active
}
