import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../models/batch.dart';

/// Lưu/đọc danh sách batch ra 1 file JSON local (batches.json)
/// trong thư mục documents riêng của app - dữ liệu chỉ tồn tại trên máy bạn,
/// không đồng bộ lên đâu cả.
class StorageService {
  static const _fileName = 'batches.json';

  Future<File> _getFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$_fileName');
  }

  Future<List<Batch>> loadBatches() async {
    try {
      final file = await _getFile();
      if (!await file.exists()) return [];
      final content = await file.readAsString();
      if (content.trim().isEmpty) return [];
      final list = jsonDecode(content) as List<dynamic>;
      return list
          .map((e) => Batch.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      // Nếu file lỗi/hỏng, không làm crash app - trả về rỗng.
      return [];
    }
  }

  Future<void> saveBatches(List<Batch> batches) async {
    final file = await _getFile();
    final data = batches.map((b) => b.toJson()).toList();
    await file.writeAsString(jsonEncode(data));
  }
}
