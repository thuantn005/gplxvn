import 'dart:convert';

import 'package:http/http.dart' as http;

class GithubFileInfo {
  final String name;
  final String downloadUrl;
  GithubFileInfo({required this.name, required this.downloadUrl});
}

/// Tải dữ liệu thô từ GitHub: liệt kê file trong 1 thư mục (qua GitHub API)
/// và tải nội dung từng file (qua raw.githubusercontent.com).
class GithubService {
  Future<String> fetchRaw(String url) async {
    final resp = await http
        .get(Uri.parse(url), headers: {'Cache-Control': 'no-cache'})
        .timeout(const Duration(seconds: 30));
    if (resp.statusCode != 200) {
      throw Exception('GitHub trả về lỗi ${resp.statusCode} khi tải $url');
    }
    return resp.body;
  }

  /// Liệt kê các file .json trong 1 thư mục của repo (mỗi file .json = 1
  /// batch — đúng format thật scanner C++ xuất ra, kết quả EXACT_ONLY cho
  /// 1 kỳ cụ thể). Pipeline trên GitHub tự loại batch hết hạn trước khi
  /// publish, nên app không cần tự check retirement.
  Future<List<GithubFileInfo>> listJsonFiles(String apiListUrl) async {
    final resp = await http
        .get(Uri.parse(apiListUrl), headers: {'Accept': 'application/vnd.github+json'})
        .timeout(const Duration(seconds: 30));
    if (resp.statusCode != 200) {
      throw Exception(
          'GitHub API trả về lỗi ${resp.statusCode} khi liệt kê thư mục.');
    }
    final list = jsonDecode(resp.body) as List<dynamic>;
    final files = <GithubFileInfo>[];
    for (final item in list) {
      final map = item as Map<String, dynamic>;
      final type = map['type'] as String?;
      final name = map['name'] as String? ?? '';
      final downloadUrl = map['download_url'] as String?;
      if (type == 'file' && name.toLowerCase().endsWith('.json') && downloadUrl != null) {
        files.add(GithubFileInfo(name: name, downloadUrl: downloadUrl));
      }
    }
    return files;
  }
}
