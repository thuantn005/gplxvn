import 'package:http/http.dart' as http;

/// Tải dữ liệu thô trực tiếp từ raw.githubusercontent.com. Không còn dùng
/// GitHub Contents API để liệt kê thư mục nữa (từ khi chuyển sang kiến trúc
/// 1 file JSON gộp duy nhất) — nên không còn bị giới hạn 60 request/giờ.
class GithubService {
  Future<String> fetchRaw(String url) async {
    final resp = await http
        .get(Uri.parse(url), headers: {'Cache-Control': 'no-cache'})
        .timeout(const Duration(seconds: 60));
    if (resp.statusCode != 200) {
      throw Exception('GitHub trả về lỗi ${resp.statusCode} khi tải $url');
    }
    return resp.body;
  }
}
