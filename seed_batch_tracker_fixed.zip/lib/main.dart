import 'package:flutter/material.dart';

import 'screens/all_batches_tickets_screen.dart';
import 'theme/lucky_theme.dart';

void main() {
  runApp(const SeedBatchTrackerApp());
}

class SeedBatchTrackerApp extends StatelessWidget {
  const SeedBatchTrackerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vé may mắn',
      debugShowCheckedModeBanner: false,
      theme: buildLuckyTheme(),
      home: const AllBatchesTicketsScreen(),
    );
  }
}
