/// Model đại diện cho 1 "batch": toàn bộ tập seed mà lần trúng J1
/// đầu tiên rơi vào đúng 1 kỳ cụ thể.
///
/// Danh sách batch được đồng bộ trực tiếp từ thư mục GitHub (mỗi file .json
/// trong thư mục = 1 batch đang active). Pipeline trên GitHub đã tự loại
/// bỏ batch hết hạn (seed nào trúng lần 2) trước khi publish, nên app
/// KHÔNG tự check/theo dõi retirement nữa — batch nào còn trong danh sách
/// tức là đang active.
///
/// LƯU Ý: file batch do scan_v2.cpp xuất ra (format mới) KHÔNG chứa 5 số
/// chính + số đặc biệt thật của kỳ trúng, nên 2 trường này có thể null.
class Batch {
  final int kyId; // kỳ mà batch này được tạo ra (lần trúng J1 đầu tiên)
  final String kyDate;
  final List<int>? kyNumbers; // 5 số chính của kỳ đó (null nếu file không có)
  final int? kySpecial; // số đặc biệt của kỳ đó (null nếu file không có)
  final Set<int> seeds; // toàn bộ seed thuộc batch này
  final DateTime importedAt;

  Batch({
    required this.kyId,
    required this.kyDate,
    this.kyNumbers,
    this.kySpecial,
    required this.seeds,
    required this.importedAt,
  });

  int get seedCount => seeds.length;

  Map<String, dynamic> toJson() => {
        'kyId': kyId,
        'kyDate': kyDate,
        'kyNumbers': kyNumbers,
        'kySpecial': kySpecial,
        'seeds': seeds.toList(),
        'importedAt': importedAt.toIso8601String(),
      };

  factory Batch.fromJson(Map<String, dynamic> json) => Batch(
        kyId: json['kyId'] as int,
        kyDate: json['kyDate'] as String,
        kyNumbers: (json['kyNumbers'] as List?)
            ?.map((e) => e as int)
            .toList(),
        kySpecial: json['kySpecial'] as int?,
        seeds: (json['seeds'] as List).map((e) => e as int).toSet(),
        importedAt: DateTime.parse(json['importedAt'] as String),
      );
}
