import 'package:flutter/material.dart';

import '../services/settings_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _settingsService = SettingsService();
  final _ownerCtrl = TextEditingController();
  final _repoCtrl = TextEditingController();
  final _branchCtrl = TextEditingController(text: 'main');
  final _folderCtrl = TextEditingController();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await _settingsService.loadConfig();
    _ownerCtrl.text = cfg.owner;
    _repoCtrl.text = cfg.repo;
    _branchCtrl.text = cfg.branch.isEmpty ? 'main' : cfg.branch;
    _folderCtrl.text = cfg.folderPath;
    setState(() => _loading = false);
  }

  Future<void> _save() async {
    final cfg = GithubConfig(
      owner: _ownerCtrl.text.trim(),
      repo: _repoCtrl.text.trim(),
      branch: _branchCtrl.text.trim().isEmpty ? 'main' : _branchCtrl.text.trim(),
      folderPath: _folderCtrl.text.trim(),
    );
    await _settingsService.saveConfig(cfg);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Đã lưu cấu hình GitHub.')));
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final folder = _folderCtrl.text.trim();
    final cleanFolder = folder.isEmpty ? '' : '/$folder';
    final previewUrl =
        'https://api.github.com/repos/${_ownerCtrl.text}/${_repoCtrl.text}/contents$cleanFolder?ref=${_branchCtrl.text}';

    return Scaffold(
      appBar: AppBar(title: const Text('Cấu hình GitHub')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Trỏ tới 1 THƯ MỤC trên GitHub (không phải 1 file cụ thể). Thư '
            'mục này chứa nhiều file .json, mỗi file = 1 batch (kết quả '
            'scan EXACT_ONLY cho 1 kỳ). App sẽ tự liệt kê và đồng bộ toàn '
            'bộ file .json trong đó mỗi khi bấm "Đồng bộ GitHub" hoặc '
            '"Sinh vé".',
            style: TextStyle(fontSize: 13, color: Colors.grey),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _ownerCtrl,
            decoration: const InputDecoration(
              labelText: 'GitHub owner',
              hintText: 'vd: thuantn005',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _repoCtrl,
            decoration: const InputDecoration(
              labelText: 'Repo',
              hintText: 'vd: lotto-scan',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _branchCtrl,
            decoration: const InputDecoration(
              labelText: 'Branch',
              hintText: 'vd: main',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _folderCtrl,
            decoration: const InputDecoration(
              labelText: 'Đường dẫn thư mục trong repo',
              hintText: 'vd: results  (để trống nếu ở gốc repo)',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 16),
          if (_ownerCtrl.text.isNotEmpty && _repoCtrl.text.isNotEmpty) ...[
            const Text('URL sẽ gọi (GitHub API liệt kê thư mục):',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
            const SizedBox(height: 4),
            SelectableText(previewUrl,
                style: const TextStyle(fontSize: 12, color: Colors.blue)),
          ],
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save),
            label: const Text('Lưu cấu hình'),
          ),
        ],
      ),
    );
  }
}
