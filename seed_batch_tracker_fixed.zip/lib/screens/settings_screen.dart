import 'package:flutter/material.dart';

import '../services/settings_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _settingsService = SettingsService();
  final _ownerCtrl = TextEditingController();
  final _repoCtrl = TextEditingController();
  final _branchCtrl = TextEditingController(text: 'main');
  final _fileCtrl = TextEditingController();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await _settingsService.loadConfig();
    _ownerCtrl.text = cfg.owner;
    _repoCtrl.text = cfg.repo;
    _branchCtrl.text = cfg.branch.isEmpty ? 'main' : cfg.branch;
    _fileCtrl.text = cfg.filePath;
    setState(() => _loading = false);
  }

  Future<void> _save() async {
    final cfg = GithubConfig(
      owner: _ownerCtrl.text.trim(),
      repo: _repoCtrl.text.trim(),
      branch: _branchCtrl.text.trim().isEmpty ? 'main' : _branchCtrl.text.trim(),
      filePath: _fileCtrl.text.trim(),
    );
    await _settingsService.saveConfig(cfg);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Đã lưu cấu hình GitHub.')));
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final filePath = _fileCtrl.text.trim();
    final previewUrl =
        'https://raw.githubusercontent.com/${_ownerCtrl.text}/${_repoCtrl.text}/${_branchCtrl.text}/$filePath';

    return Scaffold(
      appBar: AppBar(title: const Text('Cấu hình GitHub')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Trỏ tới 1 FILE JSON DUY NHẤT trên GitHub (không phải thư mục '
            'nữa). File này gộp sẵn TẤT CẢ các kỳ trong 1 lần tải, nên chỉ '
            'tốn đúng 1 request mỗi khi bấm "Đồng bộ GitHub" — không còn bị '
            'giới hạn 60 request/giờ như trước.',
            style: TextStyle(fontSize: 13, color: Colors.grey),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _ownerCtrl,
            decoration: const InputDecoration(
              labelText: 'GitHub owner',
              hintText: 'vd: thuantn005',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _repoCtrl,
            decoration: const InputDecoration(
              labelText: 'Repo',
              hintText: 'vd: lotto-scan',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _branchCtrl,
            decoration: const InputDecoration(
              labelText: 'Branch',
              hintText: 'vd: main',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _fileCtrl,
            decoration: const InputDecoration(
              labelText: 'Đường dẫn file JSON gộp trong repo',
              hintText: 'vd: l1_merged/merged_seed682305800400.json',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 16),
          if (_ownerCtrl.text.isNotEmpty &&
              _repoCtrl.text.isNotEmpty &&
              filePath.isNotEmpty) ...[
            const Text('URL sẽ gọi (tải trực tiếp, không qua GitHub API):',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
            const SizedBox(height: 4),
            SelectableText(previewUrl,
                style: const TextStyle(fontSize: 12, color: Colors.blue)),
          ],
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save),
            label: const Text('Lưu cấu hình'),
          ),
        ],
      ),
    );
  }
}
