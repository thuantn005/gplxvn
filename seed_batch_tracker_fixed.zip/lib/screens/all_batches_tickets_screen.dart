import 'dart:math';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../models/batch.dart';
import '../services/sync_service.dart';
import '../services/ticket_formula.dart';
import '../theme/lucky_theme.dart';
import 'home_screen.dart';
import 'settings_screen.dart';

/// Sinh MỘT SỐ ÍT vé (1-5) từ pool gộp seed của TẤT CẢ batch đang active.
/// Mỗi lần bấm "Sinh vé": app TỰ ĐỘNG tải file mới nhất từ GitHub, chạy lại
/// retirement check trên toàn bộ batch, rồi mới chọn ngẫu nhiên seed trong
/// pool (chỉ từ batch còn active) để tính vé.
class AllBatchesTicketsScreen extends StatefulWidget {
  const AllBatchesTicketsScreen({super.key});

  @override
  State<AllBatchesTicketsScreen> createState() =>
      _AllBatchesTicketsScreenState();
}

class _AllBatchesTicketsScreenState extends State<AllBatchesTicketsScreen> {
  final _drawIdController = TextEditingController();
  final _sync = SyncService();
  int _ticketCount = 3; // 1-5
  List<_TicketWithSource>? _tickets;
  bool _computing = false;
  String? _syncInfo;
  int? _lastDrawId;
  List<Batch> _activeBatches = [];

  Future<void> _generate() async {
    final drawId = int.tryParse(_drawIdController.text.trim());
    if (drawId == null) {
      _showMessage('Nhập số kỳ hợp lệ (vd: 846)');
      return;
    }

    setState(() {
      _computing = true;
      _syncInfo = 'Đang tải dữ liệu mới nhất từ GitHub...';
      _tickets = null;
    });

    try {
      final outcome = await _sync.syncNow();
      _activeBatches = outcome.activeBatches;

      // Gộp toàn bộ seed từ các batch active thành 1 pool (kèm nguồn batch),
      // rồi chọn ngẫu nhiên tối đa _ticketCount seed - KHÔNG sinh hết pool.
      final pool = <_SeedWithSource>[];
      for (final batch in _activeBatches) {
        for (final seed in batch.seeds) {
          pool.add(_SeedWithSource(seed: seed, sourceKyId: batch.kyId));
        }
      }
      pool.shuffle(Random.secure());
      final picked = pool.take(_ticketCount).toList();

      final results = picked
          .map((p) => _TicketWithSource(
                ticket: TicketFormula.generate(p.seed, drawId),
                sourceKyId: p.sourceKyId,
              ))
          .toList();

      final removedCount = outcome.removedBatches.length;
      final newCount = outcome.newBatches.length;

      setState(() {
        _tickets = results;
        _lastDrawId = drawId;
        _computing = false;
        _syncInfo =
            'Đã đồng bộ GitHub xong. ${_activeBatches.length} batch active, ${pool.length} seed trong pool.'
            '${newCount > 0 ? ' Mới: $newCount batch.' : ''}'
            '${removedCount > 0 ? ' Đã gỡ: $removedCount batch.' : ''}';
      });
    } on GithubNotConfiguredException catch (e) {
      setState(() {
        _computing = false;
        _syncInfo = null;
      });
      _showMessage(e.message);
      final ok = await Navigator.push<bool>(
        context,
        MaterialPageRoute(builder: (_) => const SettingsScreen()),
      );
      if (ok == true) _generate();
    } catch (e) {
      setState(() {
        _computing = false;
        _syncInfo = null;
      });
      _showMessage('Lỗi đồng bộ: $e');
    }
  }

  void _showMessage(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 26,
              height: 26,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: LuckyColors.gold,
                border: Border.all(color: LuckyColors.ivory, width: 1.5),
              ),
              child: const Icon(Icons.confirmation_number_outlined,
                  size: 15, color: LuckyColors.luckyRed),
            ),
            const SizedBox(width: 10),
            const Text('Vé may mắn'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.list_alt),
            tooltip: 'Quản lý batch',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const HomeScreen()),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: 'Cấu hình GitHub',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
            decoration: BoxDecoration(
              color: LuckyColors.luckyRed,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(24),
                bottomRight: Radius.circular(24),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: TextField(
                        controller: _drawIdController,
                        keyboardType: TextInputType.number,
                        style: const TextStyle(color: LuckyColors.ink),
                        decoration: const InputDecoration(
                          labelText: 'Kỳ muốn sinh vé (vd: 846)',
                          labelStyle: TextStyle(color: LuckyColors.muted),
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      flex: 1,
                      child: DropdownButtonFormField<int>(
                        value: _ticketCount,
                        style: const TextStyle(color: LuckyColors.ink),
                        decoration: const InputDecoration(
                          labelText: 'Số vé',
                          labelStyle: TextStyle(color: LuckyColors.muted),
                          border: OutlineInputBorder(),
                        ),
                        items: [1, 2, 3, 4, 5]
                            .map((n) => DropdownMenuItem(
                                value: n, child: Text('$n')))
                            .toList(),
                        onChanged: (v) {
                          if (v != null) setState(() => _ticketCount = v);
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _computing ? null : _generate,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: LuckyColors.gold,
                      foregroundColor: LuckyColors.ink,
                    ),
                    icon: _computing
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: LuckyColors.ink),
                          )
                        : const Icon(Icons.auto_awesome),
                    label: Text(
                      _computing ? 'Đang bốc số...' : 'Bốc $_ticketCount vé',
                      style: GoogleFonts.baloo2(fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
                if (_syncInfo != null) ...[
                  const SizedBox(height: 10),
                  Text(_syncInfo!,
                      style: TextStyle(
                          fontSize: 12, color: LuckyColors.ivory.withOpacity(0.85))),
                ],
              ],
            ),
          ),
          if (_tickets != null && _tickets!.isNotEmpty && _lastDrawId != null)
            Container(
              width: double.infinity,
              color: LuckyColors.gold.withOpacity(0.15),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Text(
                'Kỳ $_lastDrawId  •  ${_tickets!.length} vé  •  ticket(seed, kỳ)',
                style: GoogleFonts.baloo2(
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                    color: LuckyColors.luckyRed),
              ),
            ),
          Expanded(
            child: _tickets == null
                ? Center(
                    child: Text(
                      'Nhập số kỳ rồi bấm "Bốc vé" để xem kết quả.',
                      style: TextStyle(color: LuckyColors.muted),
                    ),
                  )
                : _tickets!.isEmpty
                    ? Center(
                        child: Text('Không có vé nào để hiển thị.',
                            style: TextStyle(color: LuckyColors.muted)))
                    : ListView.builder(
                        padding: const EdgeInsets.only(top: 8, bottom: 90),
                        itemCount: _tickets!.length,
                        itemBuilder: (context, i) {
                          final item = _tickets![i];
                          return _LuckyTicketCard(
                              index: i, item: item);
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

/// Thẻ vé kiểu tem vé số / lì xì: viền đứt phân cách phần đầu (ribbon đỏ)
/// và phần thân (5 số dạng đồng xu vàng + số đặc biệt dạng con dấu đỏ).
class _LuckyTicketCard extends StatelessWidget {
  final int index;
  final _TicketWithSource item;
  const _LuckyTicketCard({required this.index, required this.item});

  @override
  Widget build(BuildContext context) {
    final t = item.ticket;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: LuckyColors.cardIvory,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: LuckyColors.gold.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
            color: LuckyColors.ink.withOpacity(0.06),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Ribbon đầu vé
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: const BoxDecoration(
              color: LuckyColors.luckyRed,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Vé #${index + 1}  •  Kỳ ${t.drawId}',
                  style: GoogleFonts.baloo2(
                    color: LuckyColors.ivory,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
                Text(
                  'batch kỳ ${item.sourceKyId}',
                  style: TextStyle(
                    color: LuckyColors.ivory.withOpacity(0.75),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          // Đường xé vé (perforation)
          const _PerforationDivider(),
          // Thân vé: 5 số đồng xu + số đặc biệt con dấu
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            child: Row(
              children: [
                Expanded(
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: t.numbers
                        .map((n) => _NumberCoin(number: n))
                        .toList(),
                  ),
                ),
                const SizedBox(width: 10),
                _SpecialStamp(number: t.special),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
            child: SelectableText(
              'seed: ${t.seed}',
              style: TextStyle(fontSize: 10.5, color: LuckyColors.muted),
            ),
          ),
        ],
      ),
    );
  }
}

/// Đường viền đứt mô phỏng mép xé của vé số/lì xì.
class _PerforationDivider extends StatelessWidget {
  const _PerforationDivider();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 1,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final dashCount = (constraints.maxWidth / 8).floor();
          return Row(
            children: List.generate(dashCount, (i) {
              return Expanded(
                child: Container(
                  height: 1,
                  margin: const EdgeInsets.symmetric(horizontal: 1.5),
                  color: LuckyColors.gold.withOpacity(0.6),
                ),
              );
            }),
          );
        },
      ),
    );
  }
}

/// 1 số chính của vé, hiển thị như đồng xu vàng.
class _NumberCoin extends StatelessWidget {
  final int number;
  const _NumberCoin({required this.number});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFE9C158), LuckyColors.gold],
        ),
        border: Border.all(color: LuckyColors.luckyRed.withOpacity(0.25)),
      ),
      alignment: Alignment.center,
      child: Text(
        number.toString().padLeft(2, '0'),
        style: const TextStyle(
          fontFamily: 'monospace',
          fontWeight: FontWeight.bold,
          fontSize: 13,
          color: LuckyColors.ink,
        ),
      ),
    );
  }
}

/// Số đặc biệt, hiển thị như con dấu đỏ đóng lên vé.
class _SpecialStamp extends StatelessWidget {
  final int number;
  const _SpecialStamp({required this.number});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 46,
      height: 46,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: LuckyColors.luckyRed,
        border: Border.all(color: LuckyColors.gold, width: 2),
      ),
      alignment: Alignment.center,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'ĐB',
            style: TextStyle(
              fontSize: 8,
              color: LuckyColors.ivory.withOpacity(0.8),
            ),
          ),
          Text(
            number.toString().padLeft(2, '0'),
            style: const TextStyle(
              fontFamily: 'monospace',
              fontWeight: FontWeight.bold,
              fontSize: 14,
              color: LuckyColors.ivory,
            ),
          ),
        ],
      ),
    );
  }
}

class _SeedWithSource {
  final int seed;
  final int sourceKyId;
  _SeedWithSource({required this.seed, required this.sourceKyId});
}

class _TicketWithSource {
  final TicketResult ticket;
  final int sourceKyId;
  _TicketWithSource({required this.ticket, required this.sourceKyId});
}
