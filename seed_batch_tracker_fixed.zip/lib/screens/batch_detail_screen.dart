import 'package:flutter/material.dart';

import '../models/batch.dart';
import 'batch_tickets_screen.dart';

class BatchDetailScreen extends StatefulWidget {
  final Batch batch;
  const BatchDetailScreen({super.key, required this.batch});

  @override
  State<BatchDetailScreen> createState() => _BatchDetailScreenState();
}

class _BatchDetailScreenState extends State<BatchDetailScreen> {
  final _searchController = TextEditingController();
  bool? _found;

  void _searchSeed() {
    final text = _searchController.text.trim();
    final v = int.tryParse(text);
    if (v == null) {
      setState(() => _found = null);
      return;
    }
    setState(() => _found = widget.batch.seeds.contains(v));
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.batch;
    return Scaffold(
      appBar: AppBar(
        title: Text('Batch kỳ ${b.kyId}'),
        actions: [
          IconButton(
              icon: const Icon(Icons.confirmation_number),
              tooltip: 'Sinh vé từ seed trong batch',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => BatchTicketsScreen(batch: b),
                  ),
                );
              },
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _InfoRow('Kỳ', '${b.kyId} (${b.kyDate})'),
          _InfoRow(
            'Kết quả',
            (b.kyNumbers != null && b.kySpecial != null)
                ? '${b.kyNumbers!.join(", ")} — ĐB ${b.kySpecial}'
                : 'Không có dữ liệu (file batch không mang kết quả kỳ)',
          ),
          _InfoRow('Số seed', '${b.seedCount}'),
          _InfoRow('Trạng thái', 'Đang active'),
          _InfoRow('Import lúc', b.importedAt.toLocal().toString()),
          const Divider(height: 32),
          Text('Tra cứu seed trong batch',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    hintText: 'Nhập seed để kiểm tra...',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: _searchSeed,
                child: const Text('Tìm'),
              ),
            ],
          ),
          if (_found != null) ...[
            const SizedBox(height: 12),
            Text(
              _found!
                  ? '✅ Seed này CÓ trong batch.'
                  : '❌ Seed này KHÔNG có trong batch.',
              style: TextStyle(
                color: _found! ? Colors.green : Colors.red,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(label,
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}
