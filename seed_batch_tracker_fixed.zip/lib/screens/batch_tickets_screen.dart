import 'dart:math';

import 'package:flutter/material.dart';

import '../models/batch.dart';
import '../services/sync_service.dart';
import '../services/ticket_formula.dart';
import 'settings_screen.dart';

/// Sinh MỘT SỐ ÍT vé (1-5) từ seed trong 1 batch (chọn ngẫu nhiên trong pool).
/// Mỗi lần bấm "Sinh vé": app TỰ ĐỘNG đồng bộ danh sách batch mới nhất từ
/// GitHub (bỏ qua batch nào không còn tồn tại), rồi mới chọn ngẫu nhiên
/// seed trong pool để tính vé.
class BatchTicketsScreen extends StatefulWidget {
  final Batch batch;
  const BatchTicketsScreen({super.key, required this.batch});

  @override
  State<BatchTicketsScreen> createState() => _BatchTicketsScreenState();
}

class _BatchTicketsScreenState extends State<BatchTicketsScreen> {
  final _drawIdController = TextEditingController();
  final _sync = SyncService();
  int _ticketCount = 3; // 1-5
  List<TicketResult>? _tickets;
  bool _computing = false;
  String? _syncInfo;
  int? _lastDrawId;
  late Batch _currentBatch;

  @override
  void initState() {
    super.initState();
    _currentBatch = widget.batch;
  }

  Future<void> _generate() async {
    final drawId = int.tryParse(_drawIdController.text.trim());
    if (drawId == null) {
      _showMessage('Nhập số kỳ hợp lệ (vd: 846)');
      return;
    }

    setState(() {
      _computing = true;
      _syncInfo = 'Đang tải dữ liệu mới nhất từ GitHub...';
      _tickets = null;
    });

    try {
      final outcome = await _sync.syncNow();
      final fresh = outcome.allBatches
          .where((b) => b.kyId == _currentBatch.kyId)
          .toList();

      if (fresh.isEmpty) {
        setState(() {
          _computing = false;
          _syncInfo = null;
        });
        _showMessage('Batch kỳ ${_currentBatch.kyId} không còn trong dữ liệu.');
        return;
      }

      _currentBatch = fresh.first;

      // Chọn ngẫu nhiên tối đa _ticketCount seed từ pool của batch.
      final pool = _currentBatch.seeds.toList();
      pool.shuffle(Random.secure());
      final picked = pool.take(_ticketCount).toList();

      final results =
          picked.map((s) => TicketFormula.generate(s, drawId)).toList();

      setState(() {
        _tickets = results;
        _lastDrawId = drawId;
        _computing = false;
        _syncInfo =
            'Đã đồng bộ GitHub xong. Batch đang active (${_currentBatch.seedCount} seed trong pool).';
      });
    } on GithubNotConfiguredException catch (e) {
      setState(() {
        _computing = false;
        _syncInfo = null;
      });
      _showMessage(e.message);
      final ok = await Navigator.push<bool>(
        context,
        MaterialPageRoute(builder: (_) => const SettingsScreen()),
      );
      if (ok == true) _generate();
    } catch (e) {
      setState(() {
        _computing = false;
        _syncInfo = null;
      });
      _showMessage('Lỗi đồng bộ: $e');
    }
  }

  void _showMessage(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sinh vé — batch kỳ ${_currentBatch.kyId}')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Nguồn seed: batch kỳ ${_currentBatch.kyId} (${_currentBatch.seedCount} seed trong pool). '
                  'Mỗi lần sinh vé sẽ tự động đồng bộ GitHub trước, rồi chọn '
                  'ngẫu nhiên seed trong pool để tính vé.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: TextField(
                        controller: _drawIdController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'Kỳ muốn sinh vé (vd: 846)',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      flex: 1,
                      child: DropdownButtonFormField<int>(
                        value: _ticketCount,
                        decoration: const InputDecoration(
                          labelText: 'Số vé',
                          border: OutlineInputBorder(),
                        ),
                        items: [1, 2, 3, 4, 5]
                            .map((n) => DropdownMenuItem(
                                value: n, child: Text('$n')))
                            .toList(),
                        onChanged: (v) {
                          if (v != null) setState(() => _ticketCount = v);
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _computing ? null : _generate,
                    child: _computing
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Text('Sinh $_ticketCount vé'),
                  ),
                ),
                if (_syncInfo != null) ...[
                  const SizedBox(height: 8),
                  Text(_syncInfo!,
                      style: const TextStyle(fontSize: 12, color: Colors.orange)),
                ],
              ],
            ),
          ),
          const Divider(height: 1),
          if (_tickets != null && _tickets!.isNotEmpty && _lastDrawId != null)
            Container(
              width: double.infinity,
              color: Colors.indigo.withOpacity(0.08),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Text(
                'Dự đoán cho KỲ $_lastDrawId  •  công thức: ticket(seed, $_lastDrawId)  •  ${_tickets!.length} vé',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              ),
            ),
          Expanded(
            child: _tickets == null
                ? const Center(
                    child: Text('Nhập số kỳ rồi bấm "Sinh vé" để xem kết quả.'),
                  )
                : _tickets!.isEmpty
                    ? const Center(child: Text('Không có vé nào để hiển thị.'))
                    : ListView.builder(
                        itemCount: _tickets!.length,
                        itemBuilder: (context, i) {
                          final t = _tickets![i];
                          return Card(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 4),
                            child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Vé #${i + 1}  •  Kỳ ${t.drawId}',
                                        style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12,
                                            color: Colors.indigo),
                                      ),
                                      Chip(
                                        label: Text('ĐB ${t.special}'),
                                        visualDensity: VisualDensity.compact,
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    t.numbers
                                        .map((n) => n.toString().padLeft(2, '0'))
                                        .join('  '),
                                    style: const TextStyle(
                                        fontFamily: 'monospace',
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 4),
                                  SelectableText(
                                    'seed: ${t.seed}',
                                    style: const TextStyle(
                                        fontSize: 11, color: Colors.grey),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
