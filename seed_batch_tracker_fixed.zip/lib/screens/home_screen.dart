import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../models/batch.dart';
import '../services/import_service.dart';
import '../services/storage_service.dart';
import '../services/sync_service.dart';
import 'batch_detail_screen.dart';
import 'all_batches_tickets_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _storage = StorageService();
  final _sync = SyncService();
  List<Batch> _batches = [];
  bool _loading = true;
  bool _syncing = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final batches = await _storage.loadBatches();
    batches.sort((a, b) => b.kyId.compareTo(a.kyId));
    setState(() {
      _batches = batches;
      _loading = false;
    });
  }

  Future<void> _importNewBatch() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['json'],
    );
    if (result == null || result.files.single.path == null) return;

    try {
      final file = File(result.files.single.path!);
      final batch = await ImportService.parseNewBatchFile(file);

      if (_batches.any((b) => b.kyId == batch.kyId)) {
        _showMessage('Đã có batch cho kỳ ${batch.kyId} rồi, bỏ qua.');
        return;
      }

      setState(() => _batches.add(batch));
      await _storage.saveBatches(_batches);
      _showMessage(
          'Đã thêm batch kỳ ${batch.kyId} (${batch.seedCount} seed).');
      _load();
    } catch (e) {
      _showMessage('Lỗi khi đọc file: $e');
    }
  }

  /// Tom tat danh sach ky thanh chuoi ngan, tranh SnackBar qua dai khi
  /// dong bo lan dau co the co toi 850 ky cung luc.
  String _summarizeKy(List<Batch> batches) {
    const maxShow = 5;
    final ids = batches.map((b) => b.kyId).toList()..sort();
    if (ids.length <= maxShow) return ids.map((k) => 'kỳ $k').join(', ');
    final shown = ids.take(maxShow).map((k) => 'kỳ $k').join(', ');
    return '$shown và ${ids.length - maxShow} kỳ khác';
  }

  /// Đồng bộ thủ công (bấm nút trên trang chính) - tải danh sách batch mới
  /// nhất từ GitHub (mỗi file .json trong thư mục = 1 batch đang active),
  /// thay thế toàn bộ danh sách local. KHÔNG tự check retirement nữa —
  /// pipeline trên GitHub đã tự loại batch hết hạn trước khi publish rồi.
  Future<void> _syncFromGithub() async {
    setState(() => _syncing = true);
    try {
      final outcome = await _sync.syncNow();
      await _load();
      final parts = <String>[];
      parts.add('${outcome.allBatches.length} batch đang active trên GitHub.');
      if (outcome.newBatches.isNotEmpty) {
        parts.add('Mới: ${_summarizeKy(outcome.newBatches)}.');
      }
      if (outcome.removedBatches.isNotEmpty) {
        parts.add('Đã gỡ: ${_summarizeKy(outcome.removedBatches)}.');
      }
      if (outcome.parseErrors.isNotEmpty) {
        parts.add('⚠️ ${outcome.parseErrors.length} file lỗi format, đã bỏ qua.');
      }
      _showMessage('Đồng bộ xong. ${parts.join(' ')}');
    } on GithubNotConfiguredException catch (e) {
      _showMessage(e.message);
      final ok = await Navigator.push<bool>(
        context,
        MaterialPageRoute(builder: (_) => const SettingsScreen()),
      );
      if (ok == true) _syncFromGithub();
    } catch (e) {
      _showMessage('Lỗi đồng bộ GitHub: $e');
    } finally {
      if (mounted) setState(() => _syncing = false);
    }
  }

  void _showMessage(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _deleteBatch(Batch batch) async {
    setState(() => _batches.removeWhere((b) => b.kyId == batch.kyId));
    await _storage.saveBatches(_batches);
  }

  @override
  Widget build(BuildContext context) {
    final active = _batches;


    return Scaffold(
      appBar: AppBar(
        title: const Text('Seed Batch Tracker'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: 'Cấu hình GitHub',
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const SettingsScreen()));
            },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _batches.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Chưa có batch nào.\nBấm nút + để import batch mới từ file .json (kết quả scan EXACT_ONLY cho 1 kỳ).',
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              : ListView(
                  children: [
                    if (active.isNotEmpty) ...[
                      _SectionHeader('Batch đang active (${active.length})'),
                      ...active.map((b) => _BatchTile(
                            batch: b,
                            onTap: () => _openDetail(b),
                            onDelete: () => _deleteBatch(b),
                          )),
                    ],
                  ],
                ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          if (active.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: FloatingActionButton.extended(
                heroTag: 'allTickets',
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AllBatchesTicketsScreen(),
                    ),
                  );
                },
                icon: const Icon(Icons.confirmation_number),
                label: const Text('Sinh vé tất cả batch'),
                backgroundColor: Colors.indigo,
              ),
            ),
          FloatingActionButton.extended(
            heroTag: 'sync',
            onPressed: _syncing ? null : _syncFromGithub,
            icon: _syncing
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white),
                  )
                : const Icon(Icons.cloud_sync),
            label: Text(_syncing ? 'Đang đồng bộ...' : 'Đồng bộ GitHub'),
            backgroundColor: Colors.orange,
          ),
          const SizedBox(height: 12),
          FloatingActionButton.extended(
            heroTag: 'import',
            onPressed: _importNewBatch,
            icon: const Icon(Icons.add),
            label: const Text('Batch mới (file .json)'),
          ),
        ],
      ),
    );
  }

  void _openDetail(Batch batch) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => BatchDetailScreen(batch: batch)),
    ).then((_) => _load());
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        title,
        style: Theme.of(context)
            .textTheme
            .titleMedium
            ?.copyWith(fontWeight: FontWeight.bold),
      ),
    );
  }
}

class _BatchTile extends StatelessWidget {
  final Batch batch;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const _BatchTile({
    required this.batch,
    required this.onTap,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: ValueKey(batch.kyId),
      direction: DismissDirection.endToStart,
      background: Container(
        color: Colors.red,
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      onDismissed: (_) => onDelete(),
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(
          backgroundColor: Colors.green,
          child: Text(
            '${batch.kyId}',
            style: const TextStyle(fontSize: 11, color: Colors.white),
          ),
        ),
        title: Text('Kỳ ${batch.kyId} — ${batch.kyDate}'),
        subtitle: Text('${batch.seedCount} seed đang theo dõi'),
        trailing: const Icon(Icons.play_circle_fill, color: Colors.green),
      ),
    );
  }
}
