import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Token thiết kế cho chủ đề "may mắn" (lì xì đỏ + vàng kim, gợi cảm giác
/// vé số/tem xổ số truyền thống VN) — dùng xuyên suốt app.
class LuckyColors {
  static const luckyRed = Color(0xFFA61C1C); // đỏ may mắn (primary)
  static const gold = Color(0xFFD4A017); // vàng kim (accent)
  static const ivory = Color(0xFFFFF7E8); // nền ngà ấm
  static const ink = Color(0xFF2B1710); // mực đậm (text chính)
  static const jade = Color(0xFF1F6E4A); // xanh ngọc (trạng thái active)
  static const muted = Color(0xFF8A7A68); // xám trầm (text phụ)
  static const cardIvory = Color(0xFFFFFDF7); // nền thẻ, sáng hơn ivory nền
}

ThemeData buildLuckyTheme() {
  final base = ColorScheme.fromSeed(
    seedColor: LuckyColors.luckyRed,
    brightness: Brightness.light,
  ).copyWith(
    primary: LuckyColors.luckyRed,
    secondary: LuckyColors.gold,
    surface: LuckyColors.cardIvory,
    onPrimary: LuckyColors.ivory,
    onSecondary: LuckyColors.ink,
    onSurface: LuckyColors.ink,
  );

  final headlineFont = GoogleFonts.baloo2TextTheme();

  return ThemeData(
    useMaterial3: true,
    colorScheme: base,
    scaffoldBackgroundColor: LuckyColors.ivory,
    textTheme: headlineFont.apply(
      bodyColor: LuckyColors.ink,
      displayColor: LuckyColors.ink,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: LuckyColors.luckyRed,
      foregroundColor: LuckyColors.ivory,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: GoogleFonts.baloo2(
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: LuckyColors.ivory,
      ),
    ),
    cardTheme: CardTheme(
      color: LuckyColors.cardIvory,
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: LuckyColors.gold.withOpacity(0.35)),
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: LuckyColors.luckyRed,
        foregroundColor: LuckyColors.ivory,
        padding: const EdgeInsets.symmetric(vertical: 14),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        textStyle: GoogleFonts.baloo2(
          fontSize: 16,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: LuckyColors.luckyRed,
      foregroundColor: LuckyColors.ivory,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: LuckyColors.cardIvory,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: LuckyColors.gold.withOpacity(0.5)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: LuckyColors.luckyRed, width: 2),
      ),
    ),
  );
}
