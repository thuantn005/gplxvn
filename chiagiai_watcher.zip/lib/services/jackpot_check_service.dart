import 'jackpot_repository.dart';
import 'jackpot_storage_service.dart';
import 'notification_service.dart';
import 'share_draw_machine.dart';

/// 1 lần kiểm tra: cào dữ liệu → chạy máy trạng thái chia giải → bắn thông
/// báo. Port lõi từ `WatchWorker.kt`, giản lược phần vá lỗ hổng lịch sử qua
/// history.json (app này đã có nguồn CSV lịch sử riêng qua l1_merged, không
/// cần nguồn vá thứ hai).
class JackpotCheckService {
  static final _storage = JackpotStorageService();

  /// Trả về true nếu lần kiểm tra coi là thành công (có dữ liệu dùng được),
  /// dùng làm tín hiệu retry cho WorkManager.
  static Future<bool> runCheck() async {
    final knownDrawBefore = await _storage.lastDrawId;

    Snapshot? snap;
    try {
      snap = await JackpotRepository.scrape();
    } catch (e) {
      await _storage.setLastStatus('Lỗi cào: $e');
      return false;
    }

    final state = await _storage.loadState();
    final history = await _storage.jackpotHistory();
    final events = ShareDrawMachine.check(
      state: state,
      jackpotVnd: snap.jackpotVnd,
      lastDrawId: snap.latestDraw?.drawId ?? snap.jackpotDrawId,
      lastDrawDate: snap.latestDraw?.drawDate,
      recentJackpots: history,
    );
    await _storage.saveState(state);

    final newDraw = snap.latestDraw;
    final gotNewDraw = newDraw != null && newDraw.drawId != knownDrawBefore;
    final allEvents = [...events];

    if (gotNewDraw && knownDrawBefore != null) {
      allEvents.add(ShareDrawEvent(
        kind: EventKind.newDraw,
        title: '🎲 Kết quả kỳ #${newDraw.drawId}',
        message: '${newDraw.pretty()}\nĐộc Đắc: ${ShareDrawMachine.fmt(snap.jackpotVnd)}',
      ));
    }

    if (newDraw != null) await _storage.setLastDrawId(newDraw.drawId);
    if (snap.jackpotVnd != null) {
      await _storage.pushJackpot(snap.jackpotVnd!);
      await _storage.setLastJackpot(snap.jackpotVnd!);
    }
    await _storage.setPrizeTiers(snap.prizeTiers);

    var id = 4000;
    for (final e in allEvents) {
      if (await _storage.isEnabled(e.kind)) {
        await NotificationService.show(e, id++);
      }
    }

    final ok = snap.jackpotVnd != null || newDraw != null;
    await _storage.setLastDrawText(
      newDraw != null ? '#${newDraw.drawId} — ${newDraw.pretty()}' : '⚠️ Không đọc được dãy số',
    );
    await _storage.setLastSource(
      [
        if (snap.jackpotSource != null) 'pot: ${snap.jackpotSource}',
        if (snap.drawSource != null) 'số: ${snap.drawSource}',
      ].join(' · ').isEmpty
          ? 'không nguồn nào trả lời'
          : [
              if (snap.jackpotSource != null) 'pot: ${snap.jackpotSource}',
              if (snap.drawSource != null) 'số: ${snap.drawSource}',
            ].join(' · '),
    );
    final now = DateTime.now();
    await _storage.setLastStatus(
      ok ? 'Cập nhật ${_fmtTime(now)}' : 'Không lấy được gì lúc ${_fmtTime(now)}',
    );

    return ok;
  }

  static String _fmtTime(DateTime t) {
    final h = t.hour.toString().padLeft(2, '0');
    final m = t.minute.toString().padLeft(2, '0');
    final d = t.day.toString().padLeft(2, '0');
    final mo = t.month.toString().padLeft(2, '0');
    return '$h:$m $d/$mo/${t.year}';
  }
}
