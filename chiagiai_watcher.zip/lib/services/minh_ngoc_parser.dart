import '../models/draw.dart';

/// Parser CHUYÊN DỤNG cho trang https://xosominhngoc.net.vn/lotto535.
///
/// Trang này (đã xác nhận thực tế qua ảnh chụp màn hình + fetch trực tiếp
/// ngày 29/08/2026) có cấu trúc RẤT ỔN ĐỊNH và gọn: đủ cả kỳ + 6 số + giá
/// trị Độc Đắc + bảng đầy đủ 7 bậc giải, TRONG 1 TRANG DUY NHẤT — không cần
/// gộp nhiều nguồn như cách cào trang vietlott.vn chính thức.
///
/// Cấu trúc văn bản sau khi bóc thẻ HTML (thứ tự cố định):
///   "Kỳ QSMT: #000852 Thứ sáu, Ngày: 28/08/2026 21:00"
///   "11 17 28 29 34 09"
///   "Giá trị giải Độc Đắc"
///   "7.046.272.500"
///   "Số lượng trúng giải kỳ này"
///   "Giải Trùng SL Giá trị"
///   "Giải Độc Đắc 5 số & ĐB 0 7.046.272.500"
///   "Giải Nhất 5 số 0 10.000.000"
///   ... (7 dòng cố định, luôn đúng thứ tự này)
class MinhNgocParser {
  static final _tags = RegExp(
    r'<script[\s\S]*?</script>|<style[\s\S]*?</style>|<[^>]+>',
    caseSensitive: false,
  );
  static final _kyHeader =
      RegExp(r'Kỳ QSMT:\s*#(\d{3,6}).*?Ngày:\s*(\d{2})/(\d{2})/(\d{4})\s*(\d{2}:\d{2})');
  static final _jackpotLabel = RegExp(r'Giá trị giải Độc Đắc');
  static final _tableLabel = RegExp(r'Số lượng trúng giải kỳ này');
  static final _money = RegExp(r'([\d]{1,3}(?:\.\d{3})+|\d+)');

  /// (tên bậc giải, luật trùng) — thứ tự và nội dung CỐ ĐỊNH trên trang này.
  static const _tierDefs = [
    ('Giải Độc Đắc', '5 số & ĐB'),
    ('Giải Nhất', '5 số'),
    ('Giải Nhì', '4 số & ĐB'),
    ('Giải Ba', '4 số'),
    ('Giải Tư', '3 Số & ĐB'),
    ('Giải Năm', '3 Số'),
    ('Giải Khuyến Khích', 'ĐB'),
  ];

  static String _clean(String html) {
    return _tags.replaceAll(html, ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  static int? _toInt(String s) {
    final digits = s.replaceAll('.', '');
    return int.tryParse(digits);
  }

  /// Trả về null nếu BẤT KỲ phần nào không đọc chắc chắn được — không có
  /// kết quả một phần, vì dữ liệu một phần dễ gây hiểu nhầm hơn là không có.
  static Snapshot? parse(String html) {
    final text = _clean(html);

    final kyMatch = _kyHeader.firstMatch(text);
    if (kyMatch == null) return null;

    final drawId = kyMatch.group(1)!.padLeft(5, '0');
    final drawDate = '${kyMatch.group(4)}-${kyMatch.group(3)}-${kyMatch.group(2)}';

    final jackpotLabelMatch = _jackpotLabel.firstMatch(text);
    if (jackpotLabelMatch == null) return null;

    // Day so nam GIUA het ky va nhan "Gia tri giai Doc Dac".
    final numbersWindow = text.substring(kyMatch.end, jackpotLabelMatch.start);
    final numberTokens = RegExp(r'\b\d{1,2}\b').allMatches(numbersWindow).map((m) => m.group(0)!).toList();
    if (numberTokens.length < 6) return null;
    final last6 = numberTokens.sublist(numberTokens.length - 6);
    final main = last6.sublist(0, 5).map(int.parse).toList()..sort();
    final special = int.parse(last6[5]);
    if (main.toSet().length != 5 || main.any((n) => n < 1 || n > 35)) return null;
    if (special < 1 || special > 12) return null;

    final draw = Draw(drawId: drawId, drawDate: drawDate, numbers: main, special: special);

    // Gia tri Doc Dac: so tien dau tien SAU nhan, TRUOC bang.
    final tableLabelMatch = _tableLabel.firstMatch(text);
    final jackpotWindowEnd = tableLabelMatch?.start ?? text.length;
    if (jackpotWindowEnd <= jackpotLabelMatch.end) return null;
    final jackpotWindow = text.substring(jackpotLabelMatch.end, jackpotWindowEnd);
    final jackpotMatch = _money.firstMatch(jackpotWindow);
    if (jackpotMatch == null) return null;
    final jackpotVnd = _toInt(jackpotMatch.group(0)!);
    if (jackpotVnd == null || jackpotVnd < 1000000) return null;

    // Bang 7 bac giai — parse tung dong theo dung thu tu co dinh.
    final tiers = <PrizeTier>[];
    if (tableLabelMatch != null) {
      var cursor = tableLabelMatch.end;
      for (final (name, rule) in _tierDefs) {
        final nameIdx = text.indexOf(name, cursor);
        if (nameIdx < 0) break;
        final ruleIdx = text.indexOf(rule, nameIdx + name.length);
        if (ruleIdx < 0) break;
        final afterRule = text.substring(ruleIdx + rule.length);
        final nums = _money.allMatches(afterRule).take(2).toList();
        if (nums.length < 2) break;
        final count = _toInt(nums[0].group(0)!);
        final value = _toInt(nums[1].group(0)!);
        if (count == null || value == null) break;
        tiers.add(PrizeTier(name: name, rule: rule, count: count, valueVnd: value));
        cursor = ruleIdx + rule.length + nums[1].end;
      }
    }

    return Snapshot(
      jackpotVnd: jackpotVnd,
      jackpotDrawId: drawId,
      latestDraw: draw,
      draws: [draw],
      jackpotSource: 'xosominhngoc.net.vn',
      drawSource: 'xosominhngoc.net.vn',
      prizeTiers: tiers.length == _tierDefs.length ? tiers : const [],
    );
  }
}
