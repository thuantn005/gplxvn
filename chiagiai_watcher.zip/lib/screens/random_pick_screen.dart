import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/github_seed_source.dart';
import '../services/jackpot_storage_service.dart';
import '../services/ticket_formula.dart';
import '../theme/app_theme.dart';

class SeedTicket {
  final int seed;
  final List<int> numbers;
  final int special;
  SeedTicket({required this.seed, required this.numbers, required this.special});

  String pretty() {
    final main = numbers.map((n) => n.toString().padLeft(2, '0')).join(' ');
    return '$main + ĐB ${special.toString().padLeft(2, '0')}';
  }
}

/// Sinh vé bằng công thức (`TicketFormula`) áp lên các SEED ĐANG CÓ SẴN
/// trong `l1_merged` trên GitHub (repo `lotto-scan`) — không gõ tay, không
/// tự bịa seed mới. App CHỌN NGẪU NHIÊN trong danh sách đó (không ưu tiên
/// seed nào), rồi tính vé cho KỲ TIẾP THEO (kỳ chưa xảy ra).
class RandomPickScreen extends StatefulWidget {
  const RandomPickScreen({super.key});

  @override
  State<RandomPickScreen> createState() => _RandomPickScreenState();
}

class _RandomPickScreenState extends State<RandomPickScreen> {
  final _rng = Random.secure();
  final _storage = JackpotStorageService();

  List<int> _seedPool = [];
  final List<SeedTicket> _tickets = [];
  int _lineCount = 1;
  int? _nextDrawId;

  bool _loadingPool = true;
  String? _poolError;

  @override
  void initState() {
    super.initState();
    _loadPool();
    _loadNextDrawId();
  }

  Future<void> _loadNextDrawId() async {
    final lastId = await _storage.lastDrawId;
    if (!mounted) return;
    setState(() {
      _nextDrawId = lastId != null ? int.tryParse(lastId)! + 1 : null;
    });
  }

  Future<void> _loadPool({bool forceRefresh = false}) async {
    setState(() {
      _loadingPool = true;
      _poolError = null;
    });
    try {
      final seeds = await GithubSeedSource.fetchSeeds(forceRefresh: forceRefresh);
      if (!mounted) return;
      setState(() {
        _seedPool = seeds;
        _loadingPool = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _poolError = '$e';
        _loadingPool = false;
      });
    }
  }

  void _generate() {
    if (_seedPool.isEmpty || _nextDrawId == null) return;
    final drawId = _nextDrawId!;
    final picked = <int>{};
    final tickets = <SeedTicket>[];
    // Chon ngau nhien N seed KHONG TRUNG tu danh sach dang co, ap dung cong
    // thuc cho kỳ tiếp theo.
    var guard = 0;
    while (tickets.length < _lineCount && guard < _lineCount * 50) {
      guard++;
      final seed = _seedPool[_rng.nextInt(_seedPool.length)];
      if (picked.contains(seed)) continue;
      picked.add(seed);
      final (numbers, special) = TicketFormula.generate(seed, drawId);
      tickets.add(SeedTicket(seed: seed, numbers: numbers, special: special));
    }
    setState(() {
      _tickets
        ..clear()
        ..addAll(tickets);
    });
  }

  void _copyAll() {
    if (_tickets.isEmpty) return;
    final text = _tickets
        .asMap()
        .entries
        .map((e) => 'Vé ${e.key + 1} (seed ${e.value.seed}): ${e.value.pretty()}')
        .join('\n');
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Đã sao chép vào bộ nhớ tạm')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sinh Số Từ Seed'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Tải lại danh sách seed từ GitHub',
            onPressed: () => _loadPool(forceRefresh: true),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.gold.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.gold.withOpacity(0.5)),
            ),
            child: const Row(
              children: [
                Icon(Icons.info_outline, size: 18, color: AppColors.luckyRed),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Vé được sinh bằng công thức toán áp lên seed lấy ngẫu nhiên '
                    'từ danh sách đang theo dõi trên GitHub — không phải seed nào '
                    'cũng có khả năng trúng cao hơn. Với kỳ CHƯA xảy ra, kết quả '
                    'luôn phân bố đều bất kể chọn seed nào.',
                    style: TextStyle(fontSize: 11.5, color: AppColors.ink),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _buildPoolStatus(),
          const SizedBox(height: 14),
          Row(
            children: [
              const Text('Số vé:', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(width: 12),
              Expanded(
                child: Slider(
                  value: _lineCount.toDouble(),
                  min: 1,
                  max: 10,
                  divisions: 9,
                  activeColor: AppColors.luckyRed,
                  label: '$_lineCount',
                  onChanged: (v) => setState(() => _lineCount = v.round()),
                ),
              ),
              SizedBox(width: 24, child: Text('$_lineCount', textAlign: TextAlign.right)),
            ],
          ),
          const SizedBox(height: 6),
          Center(
            child: ElevatedButton.icon(
              onPressed: (_seedPool.isEmpty || _nextDrawId == null) ? null : _generate,
              icon: const Icon(Icons.casino),
              label: const Text('Sinh Số'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.luckyRed,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                textStyle: GoogleFonts.baloo2(fontSize: 16, fontWeight: FontWeight.w700),
              ),
            ),
          ),
          if (_tickets.isNotEmpty) ...[
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Kết quả (${_tickets.length} vé) — kỳ #${_nextDrawId ?? "?"}',
                    style: GoogleFonts.baloo2(fontWeight: FontWeight.w700, fontSize: 14)),
                TextButton.icon(
                  onPressed: _copyAll,
                  icon: const Icon(Icons.copy, size: 16),
                  label: const Text('Sao chép'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            for (int i = 0; i < _tickets.length; i++) _ticketCard(i, _tickets[i]),
          ],
        ],
      ),
    );
  }

  Widget _buildPoolStatus() {
    if (_loadingPool) {
      return const Row(
        children: [
          SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
          SizedBox(width: 8),
          Text('Đang tải danh sách seed từ GitHub...', style: TextStyle(fontSize: 12)),
        ],
      );
    }
    if (_poolError != null) {
      return Row(
        children: [
          const Icon(Icons.error_outline, size: 16, color: AppColors.luckyRed),
          const SizedBox(width: 6),
          Expanded(
            child: Text('Lỗi tải seed: $_poolError',
                style: const TextStyle(fontSize: 11.5, color: AppColors.luckyRed)),
          ),
        ],
      );
    }
    return Text(
      'Đang có ${_seedPool.length} seed'
      '${_nextDrawId != null ? " · sinh vé cho kỳ #$_nextDrawId" : " · chưa rõ kỳ tiếp theo (mở tab Chia Giải để cập nhật)"}',
      style: const TextStyle(fontSize: 12, color: AppColors.muted),
    );
  }

  Widget _ticketCard(int index, SeedTicket t) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.cardIvory,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.gold.withOpacity(0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 26,
                height: 26,
                alignment: Alignment.center,
                decoration: const BoxDecoration(color: AppColors.luckyRed, shape: BoxShape.circle),
                child: Text('${index + 1}',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final n in t.numbers) _ball(n, AppColors.jade),
                    _ball(t.special, const Color(0xFFE07B1A)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text('seed: ${t.seed}', style: TextStyle(fontSize: 10, color: AppColors.muted)),
        ],
      ),
    );
  }

  Widget _ball(int n, Color color) {
    return Container(
      width: 32,
      height: 32,
      alignment: Alignment.center,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color),
      child: Text(
        n.toString().padLeft(2, '0'),
        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12),
      ),
    );
  }
}
