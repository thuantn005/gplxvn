# San Chia Giai 535 - build hoan toan moi

App Flutter 4 tab, doc du lieu THANG tu repo cong khai `thuantn005/lotto-scan`
tren GitHub (khong can backend rieng):

1. **Ket qua** - `data/full_results.json`
2. **Thang hang** - `l2_merged/promoted_seed*.json`
3. **Du doan** - `predict/next_draw_predict*.txt`
4. **Doan dung** - `j1_535/*` (chi co khi da tung co model doan TRUNG TUYET DOI)

Toan bo build APK chay TREN GITHUB ACTIONS - khong can Flutter/Android SDK
o may local, dung nhu cach ban dang lam voi repo `lotto-scan`.

## Cach dua code nay len repo `gplxvn`

1. Nen TOAN BO noi dung thu muc nay (khong boc trong 1 thu muc con - `lib/`,
   `pubspec.yaml`, `.github/` phai nam THANG o goc file .zip).
2. Vao https://github.com/thuantn005/gplxvn -> "Add file" -> "Upload files"
   -> keo file .zip vao -> Commit.
3. `Auto-unzip.yml` se tu giai nen va commit thang vao `main`.
4. `Build APK (San Chia Giai 535)` (`build_apk.yml`) se tu chay tiep theo:
   - Neu repo chua co `android/` (build lan dau) -> tu chay `flutter create`
     de sinh khung Android chuan (khong tu tay viet Gradle, tranh sai sot).
   - `flutter pub get` + `flutter build apk --release`.
   - Upload APK vao **Artifacts** cua Actions run, VA tao 1 **Release**
     kem file APK de tai truc tiep tu tab Releases.

Lan dau chay se hoi lau hon (phai `flutter create` + tai dependency lan
dau), cac lan sau nhanh hon.

## Cau hinh Firebase (FCM) - de nhan thong bao ky moi

App da viet san `PushService` khop DUNG hop dong cua `send_fcm_push.py`
trong repo `lotto-scan` (topic `chiagiai_updates`, tin nhan data-only).
De FCM hoat dong that (khong bat buoc de app chay - thieu FCM thi 3 tab
con lai van dung binh thuong, chi la khong nhan duoc thong bao day):

1. Tao 1 Firebase Project (neu chua co) tai https://console.firebase.google.com
2. Them 1 Android app trong project do voi **package name dung
   `com.thuantn005.gplxvn`** (khop voi `--org com.thuantn005` trong
   `build_apk.yml` buoc `flutter create`).
3. Tai file `google-services.json` (Project settings > General > phan
   "Your apps").
4. Vao repo `gplxvn` -> Settings -> Secrets and variables -> Actions ->
   New repository secret:
   - Ten: `GOOGLE_SERVICES_JSON`
   - Gia tri: dan NGUYEN VAN noi dung file `google-services.json`.
5. Chay lai workflow "Build APK" (workflow_dispatch hoac push code moi) -
   buoc "Cau hinh Google Services" se tu ghi file va bat plugin Gradle.

Ben phia server (repo `lotto-scan`) da co san `send_fcm_push.py` gui tin
toi topic `chiagiai_updates` - khong can sua gi them, app se tu subscribe
topic nay khi khoi dong.

## Neu build APK bi loi o buoc Gradle (Google Services)

Template Flutter (Kotlin DSL Gradle) co the doi cau truc giua cac phien
ban - neu buoc "Cau hinh Google Services" cham `sed` khong dung cho
(build log se bao loi ro o buoc `flutter build apk`), mo
`android/app/build.gradle.kts` va `android/settings.gradle.kts` de kiem
tra thu cong dong `id("com.google.gms.google-services")` da duoc them
dung cho theo huong dan chinh thuc:
https://firebase.google.com/docs/android/setup

## Gioi han hien tai (co the cai thien sau)

- Tab "Thang hang" va "Du doan" goi `api.github.com/.../contents` de liet
  ke file dong - API nay gioi han ~60 request/gio khong dang nhap theo IP.
  Du dung cho 1 nguoi dung ca nhan; neu sau nay chia se app cho nhieu
  nguoi dung chung thi nen doi sang 1 file `manifest.json` duoc chinh
  pipeline Python ghi san danh sach ten file, tranh phu thuoc gioi han nay.
- Chua co ma nguon Android/iOS san (`android/`, `ios/`) trong goi nay -
  workflow tu sinh o lan build dau tien (xem giai thich o tren).
