import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

import 'services/push_service.dart';
import 'services/notification_service.dart';
import 'screens/results_screen.dart';
import 'screens/promoted_screen.dart';
import 'screens/predict_screen.dart';
import 'screens/correct_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // FCM/Firebase can that bai neu chua cau hinh google-services.json (xem
  // README.md) - khong de loi nay chan app khoi chay, chi log ra.
  try {
    await Firebase.initializeApp();
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
    await NotificationService.instance.init();
    await PushService.instance.init();
  } catch (e) {
    debugPrint('Bo qua khoi tao Firebase/FCM (chua cau hinh?): $e');
  }

  runApp(const GplxvnApp());
}

class GplxvnApp extends StatelessWidget {
  const GplxvnApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'San Chia Giai 535',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
      ),
      home: const HomeShell(),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  static const _screens = [
    ResultsScreen(),
    PromotedScreen(),
    PredictScreen(),
    CorrectScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.list_alt), label: 'Ket qua'),
          NavigationDestination(icon: Icon(Icons.trending_up), label: 'Thang hang'),
          NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'Du doan'),
          NavigationDestination(icon: Icon(Icons.emoji_events), label: 'Doan dung'),
        ],
      ),
    );
  }
}
