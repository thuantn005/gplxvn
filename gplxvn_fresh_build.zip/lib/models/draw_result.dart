/// Khop dung format cua data/full_results.json trong repo lotto-scan
/// (xem scrape_full_result_json.py). Giu nguyen ten field tieng Anh cho
/// khop 1-1 voi JSON, khong doi nghia.
class PrizeTier {
  final String tier;
  final String match;
  final int count;
  final int value;

  PrizeTier({
    required this.tier,
    required this.match,
    required this.count,
    required this.value,
  });

  factory PrizeTier.fromJson(Map<String, dynamic> j) => PrizeTier(
        tier: j['tier']?.toString() ?? '',
        match: j['match']?.toString() ?? '',
        count: (j['count'] as num?)?.toInt() ?? 0,
        value: (j['value'] as num?)?.toInt() ?? 0,
      );
}

class DrawResult {
  final String drawId;
  final String drawDate;
  final String drawTime;
  final List<int> numbers;
  final int specialNumber;
  final int jackpotValue;
  final List<PrizeTier> prizes;

  DrawResult({
    required this.drawId,
    required this.drawDate,
    required this.drawTime,
    required this.numbers,
    required this.specialNumber,
    required this.jackpotValue,
    required this.prizes,
  });

  factory DrawResult.fromJson(Map<String, dynamic> j) => DrawResult(
        drawId: j['draw_id']?.toString() ?? '',
        drawDate: j['draw_date']?.toString() ?? '',
        drawTime: j['draw_time']?.toString() ?? '',
        numbers: (j['numbers'] as List? ?? [])
            .map((e) => (e as num).toInt())
            .toList(),
        specialNumber: (j['special_number'] as num?)?.toInt() ?? 0,
        jackpotValue: (j['jackpot_value'] as num?)?.toInt() ?? 0,
        prizes: (j['prizes'] as List? ?? [])
            .map((e) => PrizeTier.fromJson(e as Map<String, dynamic>))
            .toList(),
      );

  String get numbersDisplay =>
      numbers.map((n) => n.toString().padLeft(2, '0')).join(' - ');

  String get specialDisplay => specialNumber.toString().padLeft(2, '0');
}
