/// 1 file .txt/.json lay tho tu GitHub (predict/*.txt hoac j1_535/*.json)
/// - khong parse sau, chi hien thi noi dung + ten file cho de nhan biet.
class RepoFile {
  final String name;
  final String content;

  RepoFile({required this.name, required this.content});

  /// Suy ra nhan chien luoc de hien thi than thien tu ten file
  /// next_draw_predict_ai2.txt -> "AI 2", next_draw_predict.txt -> "Seed goc" ...
  String get strategyLabel {
    final n = name
        .replaceAll('next_draw_predict', '')
        .replaceAll('.txt', '')
        .replaceAll('_', ' ')
        .trim();
    if (n.isEmpty) return 'Seed (chien luoc goc)';
    switch (n) {
      case 'ml':
        return 'Machine Learning';
      case 'ai':
        return 'AI (model 1)';
      case 'ai2':
        return 'AI (model 2)';
      case 'ai3':
        return 'AI (model 3)';
      case 'app':
        return 'Mo phong App (Sinh So Tu Seed)';
      case 'random':
        return 'Ngau nhien (doi chung)';
      case 'seed':
        return 'Seed manh nhat';
      default:
        return n;
    }
  }
}
