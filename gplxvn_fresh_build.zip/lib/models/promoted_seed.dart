/// Khop dung format cua l2_merged/promoted_seed{X}.json (xem
/// check_l1_merged.py trong repo lotto-scan). Moi phan tu "promoted" la
/// 1 seed da trung J1 >= 2 lan trong lich su.
class SeedHit {
  final String drawId;
  final String drawDate;

  SeedHit({required this.drawId, required this.drawDate});

  factory SeedHit.fromJson(Map<String, dynamic> j) => SeedHit(
        drawId: j['draw_id']?.toString() ?? '',
        drawDate: j['draw_date']?.toString() ?? '',
      );
}

class PromotedSeed {
  final String seed;
  final int j1Count;
  final List<SeedHit> hits;
  final String modelFile; // ten file l2_merged/... goc, de nhom hien thi

  PromotedSeed({
    required this.seed,
    required this.j1Count,
    required this.hits,
    required this.modelFile,
  });

  factory PromotedSeed.fromJson(Map<String, dynamic> j, String modelFile) =>
      PromotedSeed(
        seed: j['seed']?.toString() ?? '',
        j1Count: (j['j1_count'] as num?)?.toInt() ?? 0,
        hits: (j['hits'] as List? ?? [])
            .map((e) => SeedHit.fromJson(e as Map<String, dynamic>))
            .toList(),
        modelFile: modelFile,
      );
}
