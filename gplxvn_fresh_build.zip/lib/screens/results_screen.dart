import 'package:flutter/material.dart';
import '../models/draw_result.dart';
import '../services/github_data_service.dart';

class ResultsScreen extends StatefulWidget {
  const ResultsScreen({super.key});

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  final _service = GithubDataService();
  late Future<List<DrawResult>> _future;

  @override
  void initState() {
    super.initState();
    _future = _service.fetchResults(lastN: 50);
  }

  Future<void> _refresh() async {
    setState(() {
      _future = _service.fetchResults(lastN: 50);
    });
    await _future;
  }

  String _fmtVnd(int v) {
    final s = v.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return '${buf.toString()} d';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ket qua')),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: FutureBuilder<List<DrawResult>>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return _ErrorView(message: '${snapshot.error}', onRetry: _refresh);
            }
            final draws = snapshot.data ?? [];
            if (draws.isEmpty) {
              return const Center(child: Text('Chua co ky quay nao'));
            }
            return ListView.builder(
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: draws.length,
              itemBuilder: (context, i) {
                final d = draws[i];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: ListTile(
                    title: Text('Ky ${d.drawId} - ${d.drawDate} ${d.drawTime}'),
                    subtitle: Text(
                      '${d.numbersDisplay}  +  DB ${d.specialDisplay}\n'
                      'Jackpot: ${_fmtVnd(d.jackpotValue)}',
                    ),
                    isThreeLine: true,
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorView({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Loi tai du lieu:\n$message', textAlign: TextAlign.center),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: onRetry, child: const Text('Thu lai')),
        ],
      ),
    );
  }
}
