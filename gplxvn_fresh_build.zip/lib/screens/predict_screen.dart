import 'package:flutter/material.dart';
import '../models/prediction_file.dart';
import '../services/github_data_service.dart';

class PredictScreen extends StatefulWidget {
  const PredictScreen({super.key});

  @override
  State<PredictScreen> createState() => _PredictScreenState();
}

class _PredictScreenState extends State<PredictScreen> {
  final _service = GithubDataService();
  late Future<List<RepoFile>> _future;

  @override
  void initState() {
    super.initState();
    _future = _service.fetchPredictions();
  }

  Future<void> _refresh() async {
    setState(() {
      _future = _service.fetchPredictions();
    });
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Du doan ky toi')),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: FutureBuilder<List<RepoFile>>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      children: [
                        Text('Loi tai du lieu:\n${snapshot.error}',
                            textAlign: TextAlign.center),
                        const SizedBox(height: 12),
                        ElevatedButton(onPressed: _refresh, child: const Text('Thu lai')),
                      ],
                    ),
                  ),
                ],
              );
            }
            final files = snapshot.data ?? [];
            if (files.isEmpty) {
              return const Center(child: Text('Chua co file du doan nao'));
            }
            return ListView.builder(
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: files.length,
              itemBuilder: (context, i) {
                final f = files[i];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: ExpansionTile(
                    title: Text(f.strategyLabel),
                    subtitle: Text(f.name),
                    childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: SelectableText(
                          f.content,
                          style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
