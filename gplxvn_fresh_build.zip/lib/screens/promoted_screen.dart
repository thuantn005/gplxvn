import 'package:flutter/material.dart';
import '../models/promoted_seed.dart';
import '../services/github_data_service.dart';

class PromotedScreen extends StatefulWidget {
  const PromotedScreen({super.key});

  @override
  State<PromotedScreen> createState() => _PromotedScreenState();
}

class _PromotedScreenState extends State<PromotedScreen> {
  final _service = GithubDataService();
  late Future<List<PromotedSeed>> _future;

  @override
  void initState() {
    super.initState();
    _future = _service.fetchPromotedSeeds();
  }

  Future<void> _refresh() async {
    setState(() {
      _future = _service.fetchPromotedSeeds();
    });
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Thang hang (seed manh)')),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: FutureBuilder<List<PromotedSeed>>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      children: [
                        Text('Loi tai du lieu:\n${snapshot.error}',
                            textAlign: TextAlign.center),
                        const SizedBox(height: 12),
                        ElevatedButton(onPressed: _refresh, child: const Text('Thu lai')),
                      ],
                    ),
                  ),
                ],
              );
            }
            final seeds = snapshot.data ?? [];
            if (seeds.isEmpty) {
              return ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: const [
                  Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Chua co seed nao thang hang (chua tung trung J1 >= 2 lan).',
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              );
            }
            return ListView.builder(
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: seeds.length,
              itemBuilder: (context, i) {
                final s = seeds[i];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: ListTile(
                    title: Text('Seed ${s.seed}'),
                    subtitle: Text(
                      'Trung J1: ${s.j1Count} lan | ${s.modelFile}\n'
                      '${s.hits.map((h) => "ky ${h.drawId} (${h.drawDate})").join(", ")}',
                    ),
                    isThreeLine: true,
                    trailing: CircleAvatar(child: Text('${s.j1Count}')),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
