import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Boc goi flutter_local_notifications - can vi tin FCM gui di la DATA-ONLY
/// (xem send_fcm_push.py: co y KHONG kem key "notification" de app tu
/// quyet dinh co hien thong bao hay khong), nen Android se KHONG tu hien
/// gi ca neu khong tu tao thong bao qua service nay.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  bool _initialized = false;

  static const AndroidNotificationChannel _channel = AndroidNotificationChannel(
    'chiagiai_updates_channel',
    'Cap nhat Ket qua & Du doan',
    description: 'Thong bao ky quay moi, thang hang, va du doan trung J1',
    importance: Importance.high,
  );

  Future<void> init() async {
    if (_initialized) return;
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await _plugin.initialize(initSettings);
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(_channel);
    _initialized = true;
  }

  Future<void> show({required String title, required String body}) async {
    await init();
    await _plugin.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          _channel.id,
          _channel.name,
          channelDescription: _channel.description,
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
    );
  }
}
