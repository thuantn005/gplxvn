import 'dart:convert';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'notification_service.dart';

/// Khop DUNG hop dong cua send_fcm_push.py trong repo lotto-scan:
///   - topic mac dinh: "chiagiai_updates"
///   - tin nhan LUON la DATA-ONLY (khong co key "notification"), gom:
///       data['type'] == 'wake_check'         -> data['latest_draw'] = JSON ky moi nhat
///       data['type'] == '<event_type khac>'  -> data['event_payload'] = JSON tuy event
///         (vi du event-type "j1_prediction_hit" khi co model doan trung J1,
///         xem check_prediction_result.py)
/// App TU QUYET DINH co hien thong bao hay khong (server chi "danh thuc").
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await _handleData(message.data);
}

class PushService {
  PushService._();
  static final PushService instance = PushService._();

  static const String topic = 'chiagiai_updates';

  String? _lastSeenDrawId;

  Future<void> init() async {
    final messaging = FirebaseMessaging.instance;
    await messaging.requestPermission(alert: true, badge: true, sound: true);
    await messaging.subscribeToTopic(topic);

    FirebaseMessaging.onMessage.listen((message) {
      _handleData(message.data);
    });
    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      _handleData(message.data);
    });
  }
}

Future<void> _handleData(Map<String, dynamic> data) async {
  final type = data['type'] as String?;
  if (type == 'wake_check') {
    final raw = data['latest_draw'] as String?;
    if (raw == null) return;
    try {
      final draw = jsonDecode(raw) as Map<String, dynamic>;
      final drawId = draw['draw_id']?.toString() ?? '';
      final numbers = (draw['numbers'] as List? ?? []).join('-');
      final special = draw['special_number']?.toString() ?? '';
      await NotificationService.instance.show(
        title: 'Ky quay $drawId co ket qua',
        body: 'So: $numbers | Dac biet: $special',
      );
    } catch (_) {
      // Payload loi/thieu - bo qua, khong hien thong bao sai.
    }
  } else if (type != null) {
    // Cac event khac (vd j1_prediction_hit): hien thong bao chung, khong
    // co gang parse chi tiet event_payload vi cau truc co the thay doi
    // theo tung loai event trong tuong lai.
    await NotificationService.instance.show(
      title: 'San Chia Giai 535',
      body: switch (type) {
        'j1_prediction_hit' => 'Co model vua doan TRUNG TUYET DOI 1 ky! Mo tab "Doan dung" de xem.',
        _ => 'Co cap nhat moi, mo app de xem chi tiet.',
      },
    );
  }
}
