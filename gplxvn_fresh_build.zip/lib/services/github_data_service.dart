import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/draw_result.dart';
import '../models/promoted_seed.dart';
import '../models/prediction_file.dart';

/// Doc du lieu THANG tu repo cong khai thuantn005/lotto-scan tren GitHub -
/// app khong can backend rieng, moi thu vua duoc pipeline Python cua repo
/// do ghi ra la app doc thay duoc luon (qua raw.githubusercontent.com va
/// api.github.com/.../contents cho danh sach thu muc dong).
///
/// LUU Y GIOI HAN: api.github.com khong dang nhap gioi han ~60 request/gio
/// theo IP. Voi 4 tab nhu app nay (moi tab may lan goi khi mo/refresh) thi
/// du dung binh thuong 1 nguoi dung, nhung neu sau nay muon nhieu nguoi
/// dung chung 1 app thi nen doi sang 1 file "manifest.json" duoc chinh
/// pipeline Python ghi san danh sach ten file (khong can goi contents API
/// nua, chi can raw.githubusercontent.com khong gioi han nghiem theo IP).
class GithubDataService {
  static const String owner = 'thuantn005';
  static const String repo = 'lotto-scan';
  static const String branch = 'main';

  static const String rawBase =
      'https://raw.githubusercontent.com/$owner/$repo/$branch';
  static const String apiBase =
      'https://api.github.com/repos/$owner/$repo/contents';

  Future<List<Map<String, dynamic>>> _listDir(String path) async {
    final res = await http
        .get(Uri.parse('$apiBase/$path?ref=$branch'))
        .timeout(const Duration(seconds: 20));
    if (res.statusCode == 404) return [];
    if (res.statusCode != 200) {
      throw Exception('Khong lay duoc danh sach $path (HTTP ${res.statusCode})');
    }
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    if (data is! List) return [];
    return data.cast<Map<String, dynamic>>();
  }

  Future<String> _fetchRaw(String path) async {
    final res = await http
        .get(Uri.parse('$rawBase/$path'))
        .timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) {
      throw Exception('Khong tai duoc $path (HTTP ${res.statusCode})');
    }
    return utf8.decode(res.bodyBytes);
  }

  // ---------------------------------------------------------------------
  // Tab 1: Ket qua (data/full_results.json)
  // ---------------------------------------------------------------------
  Future<List<DrawResult>> fetchResults({int? lastN}) async {
    final text = await _fetchRaw('data/full_results.json');
    final list = (jsonDecode(text) as List).cast<Map<String, dynamic>>();
    final draws = list.map((e) => DrawResult.fromJson(e)).toList();
    // Ky moi nhat o CUOI file theo dung thu tu scrape_full_result_json.py
    // ghi ra -> dao nguoc de hien thi moi nhat len dau.
    final reversed = draws.reversed.toList();
    if (lastN != null && reversed.length > lastN) {
      return reversed.sublist(0, lastN);
    }
    return reversed;
  }

  // ---------------------------------------------------------------------
  // Tab 2: Thang hang (l2_merged/promoted_seed*.json)
  // ---------------------------------------------------------------------
  Future<List<PromotedSeed>> fetchPromotedSeeds() async {
    final files = await _listDir('l2_merged');
    final jsonFiles = files.where((f) =>
        f['type'] == 'file' &&
        (f['name'] as String).startsWith('promoted_seed') &&
        (f['name'] as String).endsWith('.json'));

    final List<PromotedSeed> out = [];
    for (final f in jsonFiles) {
      final name = f['name'] as String;
      try {
        final text = await _fetchRaw('l2_merged/$name');
        final data = jsonDecode(text) as Map<String, dynamic>;
        final promoted = (data['promoted'] as List? ?? [])
            .map((e) => PromotedSeed.fromJson(e as Map<String, dynamic>, name))
            .toList();
        out.addAll(promoted);
      } catch (_) {
        // 1 file loi khong lam hong ca danh sach - bo qua, tiep tuc file khac.
        continue;
      }
    }
    // Seed trung nhieu lan nhat len dau.
    out.sort((a, b) => b.j1Count.compareTo(a.j1Count));
    return out;
  }

  // ---------------------------------------------------------------------
  // Tab 3: Du doan (predict/next_draw_predict*.txt)
  // ---------------------------------------------------------------------
  Future<List<RepoFile>> fetchPredictions() async {
    final files = await _listDir('predict');
    final txtFiles = files.where((f) =>
        f['type'] == 'file' &&
        (f['name'] as String).startsWith('next_draw_predict') &&
        (f['name'] as String).endsWith('.txt'));

    final List<RepoFile> out = [];
    for (final f in txtFiles) {
      final name = f['name'] as String;
      try {
        final content = await _fetchRaw('predict/$name');
        out.add(RepoFile(name: name, content: content));
      } catch (_) {
        continue;
      }
    }
    // File "goc" (next_draw_predict.txt, khong hau to) len dau tien.
    out.sort((a, b) {
      if (a.name == 'next_draw_predict.txt') return -1;
      if (b.name == 'next_draw_predict.txt') return 1;
      return a.name.compareTo(b.name);
    });
    return out;
  }

  // ---------------------------------------------------------------------
  // Tab 4: Doan dung (j1_535/*) - chi co file khi co model doan TRUNG
  // TUYET DOI (5 so + dac biet). Thu muc co the KHONG TON TAI (404) neu
  // chua bao gio xay ra - _listDir tra ve [] trong truong hop do.
  // ---------------------------------------------------------------------
  Future<List<RepoFile>> fetchCorrectGuesses() async {
    final files = await _listDir('j1_535');
    final List<RepoFile> out = [];
    for (final f in files) {
      if (f['type'] != 'file') continue;
      final name = f['name'] as String;
      try {
        final content = await _fetchRaw('j1_535/$name');
        out.add(RepoFile(name: name, content: content));
      } catch (_) {
        continue;
      }
    }
    out.sort((a, b) => b.name.compareTo(a.name)); // moi nhat len dau (ten co draw_id)
    return out;
  }
}
