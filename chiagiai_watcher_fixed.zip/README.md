# Săn Chia Giải

App cá nhân theo dõi kỳ quay Vietlott Lotto 5/35: hiển thị kỳ mới nhất, giá
trị Độc Đắc, và **báo khi xác định được kỳ CHIA GIẢI** (Độc Đắc vượt 12 tỷ
không ai trúng → kỳ 21:00 ngày liền kề chia cho các giải thấp hơn).

## App KHÔNG làm gì

- Không dự đoán số sẽ ra
- Không đảm bảo hay gợi ý khả năng trúng thưởng
- Không hỗ trợ mua vé/đặt cược trong app

Chỉ đơn thuần đọc dữ liệu công khai từ vietlott.vn, đối chiếu đúng thể lệ
chia giải chính thức, và báo lại cho người dùng.

## Cấu trúc

- `lib/services/draw_parser.dart`, `jackpot_parser.dart`,
  `winner_counts_parser.dart` — bóc tách dữ liệu từ HTML trang kết quả.
- `lib/services/share_draw_machine.dart` — máy trạng thái xác định kỳ chia
  giải theo đúng thể lệ (ngưỡng 12 tỷ, ngày liền kề).
- `lib/services/jackpot_repository.dart` — gọi mạng, có nguồn dự phòng
  (tắt mặc định).
- `lib/services/background_service.dart` — chạy nền định kỳ (WorkManager),
  chu kỳ 3 tiếng, khớp 2 kỳ quay/ngày (13:00 và 21:00).
- `lib/services/notification_service.dart` — thông báo local.

## Build

Đẩy code lên nhánh `main` của repo GitHub — workflow
`.github/workflows/build_apk.yml` tự build APK, tải về từ tab **Actions**.

Muốn tạo bản Release có gắn version, gắn tag rồi push:

```bash
git tag v1.0.0
git push --tags
```
