/// 1 kỳ quay Lotto 5/35 đọc được từ trang kết quả (port từ DrawParser.kt).
class Draw {
  final String drawId; // vd "00852", luon 5 chu so
  final String drawDate; // yyyy-MM-dd
  final List<int> numbers; // 5 so chinh 1..35, da sap xep tang dan
  final int? special; // so dac biet 1..12

  Draw({
    required this.drawId,
    required this.drawDate,
    required this.numbers,
    this.special,
  });

  String pretty() {
    final main = numbers.map((n) => n.toString().padLeft(2, '0')).join(' ');
    if (special != null) {
      return '$main + ĐB ${special.toString().padLeft(2, '0')}';
    }
    return main;
  }
}

/// 1 bậc giải trong bảng "Số lượng trúng giải kỳ này".
class PrizeTier {
  final String name; // "Giải Độc Đắc", "Giải Nhất", ...
  final String rule; // "5 số & ĐB", "5 số", ...
  final int count; // SL nguoi trung
  final int valueVnd; // gia tri 1 giai

  PrizeTier({
    required this.name,
    required this.rule,
    required this.count,
    required this.valueVnd,
  });
}

/// Kết quả 1 lần cào: pot + kỳ mới nhất + nguồn nào đã trả lời
/// (port từ Repository.kt Snapshot).
class Snapshot {
  final int? jackpotVnd;
  final String? jackpotDrawId;
  final Draw? latestDraw;
  final List<Draw> draws; // MOI ky doc duoc, tang dan
  final String? jackpotSource;
  final String? drawSource;
  final List<PrizeTier> prizeTiers; // rong neu nguon khong co bang nay
  final List<String> errors;

  Snapshot({
    this.jackpotVnd,
    this.jackpotDrawId,
    this.latestDraw,
    this.draws = const [],
    this.jackpotSource,
    this.drawSource,
    this.prizeTiers = const [],
    this.errors = const [],
  });
}

/// Số người trúng mỗi bậc giải 1 kỳ (port từ WinnerCounts.kt).
class WinnerCounts {
  final String drawId;
  final int jackpot;
  final int first;
  final int second;
  final int third;
  final int fourth; // 3 so chinh + DB
  final int fifth; // 3 so chinh, khong DB
  final int kk;

  WinnerCounts({
    required this.drawId,
    this.jackpot = -1,
    this.first = -1,
    this.second = -1,
    this.third = -1,
    this.fourth = -1,
    this.fifth = -1,
    this.kk = -1,
  });

  bool get hasCore => fourth >= 0 && fifth >= 0;
}
