import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const luckyRed = Color(0xFFA61C1C);
  static const gold = Color(0xFFD4A017);
  static const ivory = Color(0xFFFFF7E8);
  static const ink = Color(0xFF2B1710);
  static const jade = Color(0xFF1F6E4A);
  static const muted = Color(0xFF8A7A68);
  static const cardIvory = Color(0xFFFFFDF7);
}

ThemeData buildAppTheme() {
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.luckyRed,
      primary: AppColors.luckyRed,
      secondary: AppColors.gold,
      surface: AppColors.ivory,
    ),
    scaffoldBackgroundColor: AppColors.ivory,
    fontFamily: GoogleFonts.notoSans().fontFamily,
  );
  return base.copyWith(
    appBarTheme: AppBarTheme(
      backgroundColor: AppColors.luckyRed,
      foregroundColor: Colors.white,
      titleTextStyle: GoogleFonts.baloo2(
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: Colors.white,
      ),
      elevation: 0,
    ),
  );
}
