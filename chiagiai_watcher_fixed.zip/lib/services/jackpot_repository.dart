import 'dart:io';
import 'package:http/http.dart' as http;

import '../models/draw.dart';
import 'draw_parser.dart';
import 'jackpot_parser.dart';
import 'minh_ngoc_parser.dart';
import 'vietlott_tier_parser.dart';

export '../models/draw.dart' show Snapshot, Draw, PrizeTier;

/// Nguồn dữ liệu — PORT từ `Sources.kt` (app native Android đã kiểm chứng
/// thực tế nhiều tháng).
///
/// WAF của vietlott.vn chặn IP datacenter, nên GitHub Actions luôn nhận 403
/// và pipeline trên server phải sống bằng nguồn bên thứ ba. Điện thoại chạy
/// IP dân cư/di động — loại IP mà WAF cho qua — nên app đọc thẳng nguồn gốc
/// được, khác hẳn hoàn cảnh của CI. Đây là lý do đổi lại vietlott.vn thành
/// nguồn CHÍNH thay vì xosominhngoc.
class JackpotSources {
  /// Trang chính thức — nguồn duy nhất theo mặc định.
  static const official = [
    'https://vietlott.vn/vi/trung-thuong/ket-qua-trung-thuong/535',
    'https://vietlott.vn/vi/choi/lotto535/gioi-thieu-san-pham-535',
  ];

  /// Nguồn dự phòng, MẶC ĐỊNH TẮT. Chỉ bật khi mạng của người dùng không
  /// vào được vietlott.vn — bật trong Cài đặt, không phải sửa code.
  static const mirrors = [
    'https://xosominhngoc.net.vn/kqxs-lotto-535',
    'https://www.minhchinh.com/xo-so-dien-toan-lotto-535.html',
  ];

  static const userAgent = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36';
  static const acceptLanguage = 'vi-VN,vi;q=0.9';
}

/// Cào + parse dữ liệu Lotto 5/35.
///
/// PORT từ `Repository.kt`: thử lần lượt các nguồn trong danh sách, dừng
/// ngay khi đã có ĐỦ (kỳ quay + giá trị Độc Đắc). Không còn nguồn thứ hai
/// để đối chiếu chéo (trừ khi bật mirror), nên nguyên tắc giữ nguyên: dữ
/// liệu nào không chắc thì KHÔNG trả về.
class JackpotRepository {
  static const _timeout = Duration(seconds: 20);

  static Future<(String, int)> _fetch(String url) async {
    // Header đầy đủ để giống request trình duyệt thật — thiếu các header
    // này (Accept-Encoding, Sec-Fetch-*, Referer, DNT) là dấu hiệu rõ của
    // bot đối với các hệ chặn theo pattern header, kể cả khi User-Agent đã
    // giả trình duyệt. Referer bám theo origin của chính URL đang gọi, vì
    // Referer trỏ sai domain cũng là một dấu hiệu bot.
    final origin = Uri.parse(url).origin;
    final resp = await http.get(
      Uri.parse(url),
      headers: {
        'User-Agent': JackpotSources.userAgent,
        'Accept-Language': JackpotSources.acceptLanguage,
        'Accept':
            'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Referer': '$origin/',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Upgrade-Insecure-Requests': '1',
      },
    ).timeout(_timeout);
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw HttpException('HTTP ${resp.statusCode}');
    }
    return (resp.body, resp.statusCode);
  }

  static String _host(String url) {
    try {
      return Uri.parse(url).host;
    } catch (_) {
      return url;
    }
  }

  /// [allowMirrors] bật nguồn dự phòng khi mạng không vào được vietlott.vn
  /// (đọc từ Cài đặt — mặc định TẮT, giống app gốc).
  static Future<Snapshot> scrape({bool allowMirrors = false}) async {
    final errors = <String>[];

    int? jackpotVnd;
    String? jackpotDrawId;
    String? jackpotSource;
    Draw? latestDraw;
    List<Draw> draws = const [];
    String? drawSource;
    List<PrizeTier> prizeTiers = const [];

    final urls = allowMirrors
        ? [...JackpotSources.official, ...JackpotSources.mirrors]
        : JackpotSources.official;

    for (final url in urls) {
      if (jackpotVnd != null && latestDraw != null) break;
      final host = _host(url);
      String html;
      try {
        final (body, _) = await _fetch(url);
        html = body;
      } catch (e) {
        errors.add('$host: $e');
        continue;
      }

      // xosominhngoc.net.vn dùng parser CHUYÊN DỤNG (đọc kèm bảng 7 bậc
      // giải trong đúng 1 lần) — chính xác hơn cặp parser tổng quát bên
      // dưới vốn dành cho vietlott.vn. Các nguồn khác (vietlott.vn chính
      // thức, minhchinh.com mirror) dùng cặp parser tổng quát.
      if (host.contains('xosominhngoc')) {
        final (snap, reason) = MinhNgocParser.parseVerbose(html);
        if (snap != null) {
          if (latestDraw == null && snap.latestDraw != null) {
            latestDraw = snap.latestDraw;
            draws = snap.draws;
            drawSource = host;
          }
          if (jackpotVnd == null && snap.jackpotVnd != null) {
            jackpotVnd = snap.jackpotVnd;
            jackpotDrawId = snap.jackpotDrawId;
            jackpotSource = host;
          }
          if (prizeTiers.isEmpty) prizeTiers = snap.prizeTiers;
        } else {
          errors.add('$host: HTTP 200, ${html.length} bytes — $reason');
        }
        continue;
      }

      if (latestDraw == null) {
        final found = DrawParser.parseAll(html);
        if (found.isNotEmpty) {
          draws = found;
          latestDraw = found.last;
          drawSource = host;
        } else {
          // Nói rõ là KHÔNG ĐỌC ĐƯỢC, chứ không im lặng bỏ qua — im lặng
          // khiến số cũ nằm lại trên màn hình như thể mới.
          errors.add('$host: tải được trang nhưng không đọc chắc chắn được dãy số');
        }
      }

      if (jackpotVnd == null) {
        final r = JackpotParser.extract(html, latestDraw?.drawId);
        if (r.amountVnd != null) {
          jackpotVnd = r.amountVnd;
          jackpotDrawId = r.drawId;
          jackpotSource = host;
        }
      }

      // Bảng 7 bậc giải (Số lượng giải / Giá trị giải) — chỉ trang có bảng
      // "trung-thuong" mới có (trang "gioi-thieu-san-pham" không có), nên
      // parse() tự trả về rỗng và không ghi đè nếu trang không có bảng.
      if (prizeTiers.isEmpty) {
        final tiers = VietlottTierParser.parse(html);
        if (tiers.isNotEmpty) prizeTiers = tiers;
      }
    }

    if (jackpotVnd == null && latestDraw == null && errors.isEmpty) {
      errors.add('vietlott.vn: không trả về dữ liệu dùng được');
    }

    return Snapshot(
      jackpotVnd: jackpotVnd,
      jackpotDrawId: jackpotDrawId,
      latestDraw: latestDraw,
      draws: draws,
      jackpotSource: jackpotSource,
      drawSource: drawSource,
      prizeTiers: prizeTiers,
      errors: errors,
    );
  }
}
