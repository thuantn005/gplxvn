import 'dart:io';
import 'package:http/http.dart' as http;

import '../models/draw.dart';
import 'minh_ngoc_parser.dart';

export '../models/draw.dart' show Snapshot, Draw, PrizeTier;

/// CHỈ 1 nguồn duy nhất — xosominhngoc.net.vn/kqxs-lotto-535. vietlott.vn
/// chính thức đã bị bỏ vì server chặn request (xem lịch sử trò chuyện —
/// "Nguồn: không nguồn nào trả lời"), nên đổi hẳn sang nguồn này, không còn
/// nguồn phụ/dự phòng nào khác.
class JackpotSources {
  static const minhNgocLotto535 = 'https://xosominhngoc.net.vn/kqxs-lotto-535';

  static const userAgent = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36';
  static const acceptLanguage = 'vi-VN,vi;q=0.9';
}

/// Cào + parse dữ liệu Lotto 5/35 — CHỈ 1 nguồn:
/// xosominhngoc.net.vn/kqxs-lotto-535. Trả về ĐẦY ĐỦ: 5 số chính + số đặc
/// biệt, giá trị Độc Đắc, và bảng 7 bậc giải — trong đúng 1 lần gọi mạng.
///
/// Nguyên tắc giữ nguyên: dữ liệu nào không chắc thì KHÔNG trả về.
class JackpotRepository {
  static const _timeout = Duration(seconds: 20);

  static Future<String> _fetch(String url) async {
    final resp = await http.get(
      Uri.parse(url),
      headers: {
        'User-Agent': JackpotSources.userAgent,
        'Accept-Language': JackpotSources.acceptLanguage,
        'Accept': 'text/html,application/json;q=0.9,*/*;q=0.8',
      },
    ).timeout(_timeout);
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw HttpException('HTTP ${resp.statusCode}');
    }
    return resp.body;
  }

  static Future<Snapshot> scrape() async {
    final errors = <String>[];

    try {
      final html = await _fetch(JackpotSources.minhNgocLotto535);
      final snap = MinhNgocParser.parse(html);
      if (snap != null) return snap;
      errors.add('xosominhngoc.net.vn: tải được trang nhưng không đọc chắc chắn được dữ liệu');
    } catch (e) {
      errors.add('xosominhngoc.net.vn: $e');
    }

    return Snapshot(errors: errors);
  }
}
