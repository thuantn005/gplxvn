/// Công thức sinh vé từ seed — PORT NGUYÊN VĂN từ `scan_v2.cpp` (đã kiểm
/// chứng khớp 100% với dữ liệu thật trong dự án `lotto-scan`):
///
///   ticket(seed, draw_id) = unrank_colex(splitmix64_mix(seed*M1 + draw_id*M2) mod C(35,5))
///   special = splitmix64_mix(mixed) mod 12 + 1
///
/// LƯU Ý QUAN TRỌNG: đây là hàm BĂM (hash) xác định thuần túy — với 1 cặp
/// (seed, draw_id) cho trước luôn ra đúng 1 kết quả duy nhất, và với seed
/// bất kỳ (không chọn theo lịch sử trúng thưởng), phân bố kết quả trải đều
/// trên mọi tổ hợp — về mặt thống kê KHÔNG khác gì random thuần. App CHỈ
/// dùng công thức này như 1 cách sinh số có thể tái lập (nhập lại đúng seed
/// sẽ ra đúng vé cũ), KHÔNG dùng seed đã biết từng trùng lịch sử — làm vậy
/// mới không tạo ảo giác về khả năng trúng thưởng cao hơn.
class TicketFormula {
  static const int _c = 324632; // C(35,5)
  static const int _m1 = 0x9E3779B97F4A7C15;
  static const int _m2 = 0xD1B54A32D192ED03;
  static const int _m3 = 0xBF58476D1CE4E5B9;
  static const int _m4 = 0x94D049BB133111EB;

  static final List<List<int>> _binom = _buildBinom();

  static List<List<int>> _buildBinom() {
    final b = List.generate(36, (_) => List.filled(6, 0));
    for (int n = 0; n <= 35; n++) {
      for (int k = 0; k <= 5; k++) {
        if (k == 0) {
          b[n][k] = 1;
          continue;
        }
        if (k > n) {
          b[n][k] = 0;
          continue;
        }
        int num = 1, den = 1;
        for (int i = 0; i < k; i++) {
          num *= (n - i);
          den *= (i + 1);
        }
        b[n][k] = num ~/ den;
      }
    }
    return b;
  }

  /// SplitMix64 avalanche mix — dùng `>>>` (unsigned shift) để khớp đúng
  /// ngữ nghĩa uint64 bên C++, tránh lỗi dấu (sign) khi Dart dùng int 64-bit
  /// có dấu ở tầng thấp.
  static int _mix64(int x) {
    x ^= x >>> 30;
    x *= _m3;
    x ^= x >>> 27;
    x *= _m4;
    x ^= x >>> 31;
    return x;
  }

  static int _rankToMask(int r) {
    int mask = 0, rem = r;
    for (int k = 5; k >= 1; k--) {
      int x = k - 1;
      while (_binom[x + 1][k] <= rem) {
        x++;
      }
      mask |= (1 << x);
      rem -= _binom[x][k];
    }
    return mask;
  }

  /// Sinh 1 vé từ (seed, draw_id). Trả về (5 số chính đã sắp xếp, số ĐB).
  static (List<int>, int) generate(int seed, int drawId) {
    final combined = seed * _m1 + drawId * _m2;
    final mixed = _mix64(combined);
    final rank = mixed % _c;
    final mask = _rankToMask(rank);
    final numbers = <int>[];
    for (int i = 0; i < 35; i++) {
      if ((mask >> i) & 1 == 1) numbers.add(i + 1);
    }
    final mixed2 = _mix64(mixed);
    final special = (mixed2 % 12) + 1;
    return (numbers, special);
  }
}
