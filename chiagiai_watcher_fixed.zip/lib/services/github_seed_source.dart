import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

/// Tải danh sách seed đang được theo dõi từ `l1_merged/merged_seed*.json`
/// trên GitHub (repo `lotto-scan`) — CÙNG file dữ liệu mà app
/// `seed_batch_tracker` dùng. Không tạo seed mới, không tự đoán/lọc seed
/// nào "tốt hơn" — chỉ lấy lại đúng danh sách đang có sẵn để khỏi phải gõ
/// tay.
///
/// LƯU Ý: những seed này từng trùng J1 ở MỘT kỳ trong quá khứ (theo cách
/// quét brute-force), điều này KHÔNG có nghĩa vé sinh từ seed đó có khả
/// năng trúng cao hơn vé sinh từ số bất kỳ — công thức sinh vé là hàm băm,
/// với kỳ quay MỚI (chưa xảy ra), phân bố kết quả vẫn trải đều như nhau
/// dù seed là gì.
class GithubSeedSource {
  static const _rawUrl =
      'https://raw.githubusercontent.com/thuantn005/lotto-scan/main/l1_merged/merged_seed682305800400.json';

  static List<int>? _cache;

  /// Trả về danh sách seed DUY NHẤT (đã loại trùng), gộp từ mọi kỳ trong
  /// file. [forceRefresh] = true để bỏ cache, tải lại từ GitHub.
  static Future<List<int>> fetchSeeds({bool forceRefresh = false}) async {
    if (!forceRefresh && _cache != null) return _cache!;

    final resp = await http
        .get(Uri.parse(_rawUrl), headers: {'Cache-Control': 'no-cache'})
        .timeout(const Duration(seconds: 30));
    if (resp.statusCode != 200) {
      throw HttpException('GitHub trả về lỗi ${resp.statusCode}');
    }

    final data = jsonDecode(resp.body) as Map<String, dynamic>;
    final drawsRaw = data['draws'] as List?;
    if (drawsRaw == null) {
      throw const FormatException('File không có mảng "draws"');
    }

    final seedSet = <int>{};
    for (final item in drawsRaw) {
      final map = item as Map<String, dynamic>;
      final seeds = map['seeds'] as List?;
      if (seeds == null) continue;
      for (final s in seeds) {
        seedSet.add(s as int);
      }
    }

    if (seedSet.isEmpty) {
      throw const FormatException('Không có seed nào trong file (đã rỗng?)');
    }

    _cache = seedSet.toList();
    return _cache!;
  }
}
