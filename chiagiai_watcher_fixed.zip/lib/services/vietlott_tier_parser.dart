import '../models/draw.dart';

/// Bóc bảng 7 bậc giải (Số lượng giải / Giá trị giải) từ trang kết quả
/// CHÍNH THỨC vietlott.vn — trước đây trang này chỉ được đọc kỳ quay +
/// Độc Đắc (draw_parser.dart, jackpot_parser.dart), còn bảng 7 bậc giải
/// luôn để trống vì chưa có parser riêng.
///
/// Cấu trúc thật đã xác nhận (30/08/2026), sau khi bóc hết thẻ HTML:
///   "... Giải thưởng  Kết quả  Số lượng giải  Giá trị giải (đồng)
///    Giải Độc Đắc  O O O O O + O  0  7.398.537.500
///    Giải Nhất  O O O O O  0  10.000.000
///    ...
///    Giải Khuyến Khích  OO + O
///    O + O
///    O  16.801  10.000
///    Các lần quay trước ..."
///
/// LƯU Ý QUAN TRỌNG: cột "Kết quả" của "Giải Khuyến Khích" trải ra NHIỀU
/// DÒNG (nhiều tổ hợp trúng), nên KHÔNG được bóc theo từng dòng văn bản —
/// phải neo theo TÊN BẬC GIẢI rồi lấy 2 số cuối cùng trong toàn bộ cửa sổ
/// văn bản giữa 2 tên bậc giải liên tiếp (giống cách minh_ngoc_parser.dart
/// đã xử lý cho nguồn dự phòng).
class VietlottTierParser {
  static const _tierNames = [
    'Giải Độc Đắc',
    'Giải Nhất',
    'Giải Nhì',
    'Giải Ba',
    'Giải Tư',
    'Giải Năm',
    'Giải Khuyến Khích',
  ];

  // Neo vào đúng dòng tiêu đề bảng để bỏ qua chữ "Giải Độc Đắc" xuất hiện
  // TRƯỚC bảng (ở khối hiển thị to giá trị Độc Đắc riêng, không phải hàng
  // trong bảng) — nếu không neo ở đây, vòng lặp bên dưới sẽ bắt nhầm vị trí
  // đó làm điểm bắt đầu của hàng "Giải Độc Đắc".
  static final _tableHeader =
      RegExp(r'Giải\s*thưởng\s*Kết\s*quả\s*Số\s*lượng\s*giải\s*Giá\s*trị\s*giải');

  static final _money = RegExp(r'([\d]{1,3}(?:\.\d{3})+|\d+)');

  // Sau hàng CUỐI CÙNG (Giải Khuyến Khích) không còn tên bậc giải nào để
  // chặn cửa sổ tìm kiếm lại — nếu không giới hạn, các con số trong đoạn
  // "Điều kiện lĩnh thưởng" phía dưới (vd "12 tỷ đồng", "điều 8") có thể bị
  // đọc nhầm thành Số lượng giải/Giá trị giải. Chặn tại mốc nào xuất hiện
  // sớm nhất trong số các mốc biết chắc nằm NGAY SAU bảng.
  static final _afterTableMarkers = [
    RegExp(r'Các\s*lần\s*quay\s*trước'),
    RegExp(r'Điều\s*kiện\s*lĩnh\s*thưởng'),
    RegExp(r'Cách\s*tính\s*giá\s*trị'),
  ];
  static const _lastTierFallbackWindow = 300;

  static String _decodeEntities(String s) {
    return s
        .replaceAll(RegExp(r'&nbsp;', caseSensitive: false), ' ')
        .replaceAllMapped(
          RegExp(r'&#(\d+);'),
          (m) => String.fromCharCode(int.parse(m.group(1)!)),
        )
        .replaceAllMapped(
          RegExp(r'&#x([0-9a-fA-F]+);'),
          (m) => String.fromCharCode(int.parse(m.group(1)!, radix: 16)),
        )
        .replaceAll(RegExp(r'&amp;', caseSensitive: false), '&')
        .replaceAll(RegExp(r'&lt;', caseSensitive: false), '<')
        .replaceAll(RegExp(r'&gt;', caseSensitive: false), '>')
        .replaceAll(RegExp(r'&quot;', caseSensitive: false), '"')
        .replaceAll(RegExp(r'&#0?39;|&apos;', caseSensitive: false), "'");
  }

  static String _clean(String html) {
    return _decodeEntities(html
            .replaceAll(RegExp(r'<script[\s\S]*?</script>', caseSensitive: false), ' ')
            .replaceAll(RegExp(r'<style[\s\S]*?</style>', caseSensitive: false), ' ')
            .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n')
            .replaceAll(RegExp(r'<[^>]+>'), ' '))
        .replaceAll(RegExp(r'[ \t]+'), ' ')
        .replaceAll(RegExp(r'\n\s*\n+'), '\n')
        .trim();
  }

  static int? _toInt(String s) => int.tryParse(s.replaceAll('.', ''));

  /// Trả về danh sách rỗng nếu không đọc chắc chắn được ĐỦ cả 7 bậc giải —
  /// thà không hiện bảng còn hơn hiện bảng thiếu/sai hàng.
  static List<PrizeTier> parse(String html) {
    final text = _clean(html);

    final headerMatch = _tableHeader.firstMatch(text);
    if (headerMatch == null) return const [];
    final searchStart = headerMatch.end;

    final positions = <int>[];
    var searchFrom = searchStart;
    for (final name in _tierNames) {
      final idx = text.indexOf(name, searchFrom);
      positions.add(idx);
      if (idx >= 0) searchFrom = idx + name.length;
    }

    final tiers = <PrizeTier>[];
    for (var i = 0; i < _tierNames.length; i++) {
      final start = positions[i];
      if (start < 0) break;
      final contentStart = start + _tierNames[i].length;

      var contentEnd = text.length;
      var foundNext = false;
      for (var j = i + 1; j < positions.length; j++) {
        if (positions[j] >= 0) {
          contentEnd = positions[j];
          foundNext = true;
          break;
        }
      }
      if (!foundNext) {
        // Hàng cuối cùng (Giải Khuyến Khích): chặn tại mốc biết chắc nằm
        // ngay sau bảng, sớm nhất trong các mốc ứng viên; nếu không thấy
        // mốc nào thì chặn cứng theo số ký tự để an toàn.
        var boundary = (contentStart + _lastTierFallbackWindow).clamp(0, text.length);
        for (final marker in _afterTableMarkers) {
          final m = marker.firstMatch(text.substring(contentStart));
          if (m != null) {
            final abs = contentStart + m.start;
            if (abs < boundary) boundary = abs;
          }
        }
        contentEnd = boundary;
      }

      if (contentEnd <= contentStart) break;
      final window = text.substring(contentStart, contentEnd);
      final nums = _money.allMatches(window).toList();
      if (nums.length < 2) break;
      final count = _toInt(nums[nums.length - 2].group(0)!);
      final value = _toInt(nums[nums.length - 1].group(0)!);
      if (count == null || value == null) break;
      tiers.add(PrizeTier(name: _tierNames[i], rule: '', count: count, valueVnd: value));
    }

    return tiers.length == _tierNames.length ? tiers : const [];
  }
}
