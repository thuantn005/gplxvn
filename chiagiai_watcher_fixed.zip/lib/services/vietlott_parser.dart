import '../models/draw.dart';

/// Parser CHUYÊN DỤNG cho trang chính thức
/// https://vietlott.vn/vi/trung-thuong/ket-qua-trung-thuong/535 — nguồn dữ
/// liệu DUY NHẤT của app.
///
/// Đã xác nhận thực tế qua nội dung trang thật (29/08/2026):
///   - 5 số chính viết LIỀN không cách + "|" + số đặc biệt: "0226273234|08"
///   - Cột "Kết quả" trong bảng bậc giải chỉ là ký hiệu O/+ — nên nhận diện
///     dòng theo TÊN bậc giải, bỏ qua cột O/+ (không phải số, regex tiền tệ
///     tự động bỏ qua).
class VietlottParser {
  static final _tags = RegExp(
    r'<script[\s\S]*?</script>|<style[\s\S]*?</style>|<[^>]+>',
    caseSensitive: false,
  );
  static final _kyHeader =
      RegExp(r'Kỳ quay thưởng\s*#(\d{2,6})\s*ngày\s*(\d{2})/(\d{2})/(\d{4})');
  static final _numbers = RegExp(r'(\d{10})\|(\d{2})');
  static final _tableHeader = RegExp(r'Giải thưởng\s*Kết quả\s*Số lượng giải');
  static final _money = RegExp(r'([\d]{1,3}(?:\.\d{3})+|\d+)');

  static const _tierNames = [
    'Giải Độc Đắc',
    'Giải Nhất',
    'Giải Nhì',
    'Giải Ba',
    'Giải Tư',
    'Giải Năm',
    'Giải Khuyến Khích',
  ];

  static String _clean(String html) {
    // Giu lai xuong dong don (mot so bang tren trang nay dua vao xuong dong
    // de tach dong), nhung gop khoang trang thua trong cung 1 dong.
    return html
        .replaceAll(RegExp(r'<script[\s\S]*?</script>', caseSensitive: false), ' ')
        .replaceAll(RegExp(r'<style[\s\S]*?</style>', caseSensitive: false), ' ')
        .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'<[^>]+>'), ' ')
        .replaceAll(RegExp(r'[ \t]+'), ' ')
        .replaceAll(RegExp(r'\n\s*\n+'), '\n')
        .trim();
  }

  static int? _toInt(String s) => int.tryParse(s.replaceAll('.', ''));

  /// Trả về null nếu bất kỳ phần nào không đọc chắc chắn được.
  static Snapshot? parse(String html) {
    final text = _clean(html);

    final kyMatch = _kyHeader.firstMatch(text);
    if (kyMatch == null) return null;
    final drawId = kyMatch.group(1)!.padLeft(5, '0');
    final drawDate = '${kyMatch.group(4)}-${kyMatch.group(3)}-${kyMatch.group(2)}';

    final numMatch = _numbers.firstMatch(text.substring(kyMatch.end));
    if (numMatch == null) return null;
    final digits = numMatch.group(1)!;
    final main = <int>[];
    for (int i = 0; i < 10; i += 2) {
      main.add(int.parse(digits.substring(i, i + 2)));
    }
    main.sort();
    if (main.toSet().length != 5 || main.any((n) => n < 1 || n > 35)) return null;
    final special = int.parse(numMatch.group(2)!);
    if (special < 1 || special > 12) return null;

    final draw = Draw(drawId: drawId, drawDate: drawDate, numbers: main, special: special);

    final tableMatch = _tableHeader.firstMatch(text);
    if (tableMatch == null) return null;

    // Gia tri Doc Dac tom tat: nam TRUOC bang, la lan xuat hien "Giải Độc
    // Đắc" GAN bang nhat (tranh nham voi cac nhan "Giải Độc Đắc" khac o dau
    // trang, vd tieu de).
    final beforeTable = text.substring(0, tableMatch.start);
    final jackpotLabelIdx = beforeTable.lastIndexOf('Giải Độc Đắc');
    if (jackpotLabelIdx < 0) return null;
    final jackpotMatch = _money.firstMatch(beforeTable.substring(jackpotLabelIdx));
    if (jackpotMatch == null) return null;
    final jackpotVnd = _toInt(jackpotMatch.group(0)!);
    if (jackpotVnd == null || jackpotVnd < 1000000) return null;

    // Bang 7 bac giai: nhan dien theo TEN, lay 2 con so tien te tiep theo
    // (SL, gia tri) - cot "Kết quả" chi la O/+ nen khong lam nhieu regex so.
    final tiers = <PrizeTier>[];
    final afterTable = text.substring(tableMatch.end);
    var cursor = 0;
    for (final name in _tierNames) {
      final idx = afterTable.indexOf(name, cursor);
      if (idx < 0) break;
      final afterName = afterTable.substring(idx + name.length);
      final nums = _money.allMatches(afterName).take(2).toList();
      if (nums.length < 2) break;
      final count = _toInt(nums[0].group(0)!);
      final value = _toInt(nums[1].group(0)!);
      if (count == null || value == null) break;
      // Khong co cot "rule" dang chu tren trang nay (chi co O/+), de rong.
      tiers.add(PrizeTier(name: name, rule: '', count: count, valueVnd: value));
      cursor = idx + name.length + nums[1].end;
    }

    return Snapshot(
      jackpotVnd: jackpotVnd,
      jackpotDrawId: drawId,
      latestDraw: draw,
      draws: [draw],
      jackpotSource: 'vietlott.vn',
      drawSource: 'vietlott.vn',
      prizeTiers: tiers.length == _tierNames.length ? tiers : const [],
    );
  }
}
