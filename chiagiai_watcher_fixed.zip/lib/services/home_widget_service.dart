import 'package:home_widget/home_widget.dart';

/// Đẩy dữ liệu mới nhất sang Widget màn hình chính Android (không hỗ trợ
/// iOS trong project này — pubspec.yaml đã đặt `ios: false` cho
/// flutter_launcher_icons, tức app chỉ build Android).
///
/// Tên provider "JackpotWidgetProvider" phải KHỚP CHÍNH XÁC với tên class
/// Kotlin trong android/app/src/main/kotlin/jp/devjlog/vn/JackpotWidgetProvider.kt
/// — file đó được ghi ra bởi bước "Thêm Home Screen Widget" trong
/// build_apk.yml (vì thư mục android/ không được lưu sẵn trong repo, CI tự
/// sinh lại mỗi lần build).
class HomeWidgetService {
  static const _androidProviderName = 'JackpotWidgetProvider';

  static String _thousands(int v) {
    final s = v.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  static String _nextDrawText() {
    final now = DateTime.now();
    final today13 = DateTime(now.year, now.month, now.day, 13, 0);
    final today21 = DateTime(now.year, now.month, now.day, 21, 0);
    if (now.isBefore(today13)) return '13:00 hôm nay';
    if (now.isBefore(today21)) return '21:00 hôm nay';
    return '13:00 ngày mai';
  }

  static Future<void> push({int? jackpotVnd, String? drawId}) async {
    try {
      await HomeWidget.saveWidgetData<String>(
        'widget_jackpot',
        jackpotVnd != null ? '${_thousands(jackpotVnd)} VNĐ' : '—',
      );
      await HomeWidget.saveWidgetData<String>(
        'widget_draw_label',
        drawId != null ? 'Kỳ #$drawId' : 'Săn Chia Giải 535',
      );
      await HomeWidget.saveWidgetData<String>('widget_next_draw', 'Kỳ tới: ${_nextDrawText()}');
      await HomeWidget.updateWidget(androidName: _androidProviderName);
    } catch (_) {
      // Máy không hỗ trợ widget, chưa gắn widget nào, hoặc lỗi ghi dữ liệu
      // — bỏ qua êm, không ảnh hưởng luồng kiểm tra chính của app.
    }
  }
}
