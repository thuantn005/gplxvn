import 'package:workmanager/workmanager.dart';

import 'jackpot_check_service.dart';
import 'jackpot_storage_service.dart';

const String kJackpotCheckTask = 'jackpot_check_task';

// 2 kỳ quay/ngày cố định lúc 13:00 và 21:00 — kiểm tra bám SÁT NGAY giờ
// quay (không chờ 10 phút như trước) để có kết quả nhanh nhất có thể, thay
// vì chỉ dựa vào chu kỳ 3 tiếng cứng (có thể lệch tới gần 3 tiếng).
const String kAnchorTask1310 = 'jackpot_check_anchor_1310'; // ten task giu nguyen de tuong thich nguoc, gio chay dung 13:00
const String kAnchorTask2110 = 'jackpot_check_anchor_2110'; // ten task giu nguyen, gio chay dung 21:00
const _anchorHour1 = 13, _anchorMinute1 = 0;
const _anchorHour2 = 21, _anchorMinute2 = 0;

// Neu vua kiem tra dung luc ma trang nguon CHUA KIP cap nhat ket qua moi
// (van la ky truoc), thu lai vai lan cach nhau vai phut thay vi bo cuoc
// cho toi ngay hom sau — day la phan quan trong nhat de "co ket qua nhanh
// nhat" vi thoi diem trang nguon thuc su cap nhat co the lech vai phut so
// voi 13:00/21:00 dung boong.
const _maxQuickRetries = 5;
const _quickRetryGap = Duration(minutes: 2);

Duration _delayUntilNext(int hour, int minute) {
  final now = DateTime.now();
  var next = DateTime(now.year, now.month, now.day, hour, minute);
  if (!next.isAfter(now)) next = next.add(const Duration(days: 1));
  return next.difference(now);
}

/// Điểm vào cho isolate nền — BẮT BUỘC là top-level function hoặc static,
/// đánh dấu @pragma để Flutter không tree-shake mất khi build release.
@pragma('vm:entry-point')
void backgroundCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task == kAnchorTask1310 || task == kAnchorTask2110) {
      final storage = JackpotStorageService();
      final drawIdBefore = await storage.lastDrawId;
      final ok = await JackpotCheckService.runCheck();
      final drawIdAfter = await storage.lastDrawId;
      final gotNewDraw = drawIdAfter != null && drawIdAfter != drawIdBefore;

      // 2 task bám giờ quay là ONE-OFF (WorkManager không hỗ trợ periodic
      // "vào đúng giờ trong ngày", chỉ hỗ trợ chu kỳ cố định từ lúc đăng
      // ký) — nên sau khi chạy xong, tự đăng ký lại chính nó.
      final retryCount = (inputData?['retryCount'] as int?) ?? 0;
      if (!gotNewDraw && retryCount < _maxQuickRetries) {
        // Chưa có kết quả mới -> thử lại sớm (2 phút sau) thay vì đợi cả
        // ngày, để bắt kết quả NGAY khi nguồn cập nhật xong.
        await Workmanager().registerOneOffTask(
          task,
          task,
          initialDelay: _quickRetryGap,
          inputData: {'retryCount': retryCount + 1},
          constraints: Constraints(networkType: NetworkType.connected),
        );
      } else {
        // Đã có kết quả mới (hoặc đã thử đủ số lần mà vẫn chưa có) -> hẹn
        // lại đúng giờ quay của ngày hôm sau.
        await Workmanager().registerOneOffTask(
          task,
          task,
          initialDelay: const Duration(hours: 24),
          constraints: Constraints(networkType: NetworkType.connected),
        );
      }
      return ok;
    }
    if (task == kJackpotCheckTask) {
      return JackpotCheckService.runCheck();
    }
    return true;
  });
}

/// Đăng ký kiểm tra nền:
///  - 2 task bám giờ quay (đúng 13h00 / 21h00, tự thử lại mỗi 2 phút nếu
///    nguồn chưa cập nhật) — ưu tiên chính, cho kết quả nhanh nhất có thể.
///  - 1 task định kỳ 3 tiếng/lần — lớp dự phòng, phòng khi 2 task bám giờ
///    bị lỡ (máy tắt nguồn đúng lúc, WorkManager bị hệ thống trì hoãn...).
class JackpotBackgroundService {
  static Future<void> initialize() async {
    await Workmanager().initialize(backgroundCallbackDispatcher);

    await Workmanager().registerPeriodicTask(
      kJackpotCheckTask,
      kJackpotCheckTask,
      frequency: const Duration(hours: 3),
      constraints: Constraints(networkType: NetworkType.connected),
      // Khong truyen existingWorkPolicy: mac dinh cua package da la KEEP
      // (giu nguyen task dinh ky da co, khong tao trung). Bo qua de tranh
      // phu thuoc ten enum co the doi giua cac phien ban package
      // (ExistingWorkPolicy vs ExistingPeriodicWorkPolicy).
    );

    // Chỉ gieo lần đầu tiên app khởi động (đánh dấu bằng cờ trong storage,
    // KHÔNG dùng Workmanager().isScheduledByUniqueName vì API đó chỉ có ở
    // bản workmanager rất mới (0.9.x, kèm nhiều breaking change khác) —
    // bản đang dùng ở đây (^0.5.2) chưa có method này). Nếu gieo lại mỗi
    // lần mở app, initialDelay sẽ bị tính lại từ "bây giờ" mỗi lần, đẩy
    // lùi giờ chạy thật ra xa hơn dự kiến.
    final storage = JackpotStorageService();
    if (!await storage.anchorTasksSeeded) {
      await Workmanager().registerOneOffTask(
        kAnchorTask1310,
        kAnchorTask1310,
        initialDelay: _delayUntilNext(_anchorHour1, _anchorMinute1),
        constraints: Constraints(networkType: NetworkType.connected),
      );
      await Workmanager().registerOneOffTask(
        kAnchorTask2110,
        kAnchorTask2110,
        initialDelay: _delayUntilNext(_anchorHour2, _anchorMinute2),
        constraints: Constraints(networkType: NetworkType.connected),
      );
      await storage.setAnchorTasksSeeded(true);
    }
  }

  /// Kiểm tra ngay (bấm tay trên app), chạy trực tiếp trên UI isolate,
  /// không qua WorkManager.
  static Future<bool> checkNow() => JackpotCheckService.runCheck();
}
