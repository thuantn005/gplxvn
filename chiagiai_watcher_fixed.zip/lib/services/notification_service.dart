import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'share_draw_machine.dart';

/// Hiện thông báo local — port từ `Notifier.kt`. 2 kênh: khẩn (chia giải) và
/// thông tin (kết quả kỳ mới, huỷ/hoàn tất, lỗi tra cứu).
class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _initialized = false;

  static const _chUrgent = 'share_draw_urgent';
  static const _chInfo = 'share_draw_info';

  static Future<void> init() async {
    if (_initialized) return;
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: androidInit);
    await _plugin.initialize(settings);

    const urgentChannel = AndroidNotificationChannel(
      _chUrgent,
      'Kỳ chia giải Độc Đắc',
      description: 'Báo khi đã xác định và khi ĐẾN kỳ chia giải Độc Đắc.',
      importance: Importance.high,
    );
    const infoChannel = AndroidNotificationChannel(
      _chInfo,
      'Thông tin khác',
      description: 'Kết quả kỳ mới, huỷ/hoàn tất chia giải, lỗi tra cứu.',
      importance: Importance.defaultImportance,
    );

    final androidPlugin =
        _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(urgentChannel);
    await androidPlugin?.createNotificationChannel(infoChannel);

    _initialized = true;
  }

  /// Xin quyền hiện thông báo (bắt buộc trên Android 13+).
  static Future<bool> requestPermission() async {
    final androidPlugin =
        _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    final granted = await androidPlugin?.requestNotificationsPermission();
    return granted ?? false;
  }

  static Future<void> show(ShareDrawEvent event, int id) async {
    await init();
    final channelId = event.urgent ? _chUrgent : _chInfo;
    final details = AndroidNotificationDetails(
      channelId,
      event.urgent ? 'Kỳ chia giải Độc Đắc' : 'Thông tin khác',
      importance: event.urgent ? Importance.high : Importance.defaultImportance,
      priority: event.urgent ? Priority.max : Priority.defaultPriority,
      styleInformation: BigTextStyleInformation(event.message),
      category: AndroidNotificationCategory.reminder,
      autoCancel: true,
    );
    await _plugin.show(
      id,
      event.title,
      event.message,
      NotificationDetails(android: details),
    );
  }
}
