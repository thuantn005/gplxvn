import '../models/draw.dart';

/// Parser CHUYÊN DỤNG cho https://xosominhngoc.net.vn/kqxs-lotto-535 — nguồn
/// dữ liệu DUY NHẤT của app (vietlott.vn chính thức chặn request từ server
/// ngoài nên không dùng được, xem lịch sử trò chuyện).
///
/// Đã xác nhận thực tế qua nội dung trang thật (29/08/2026):
///   - Trang liệt kê nhiều kỳ, KỲ MỚI NHẤT nằm ĐẦU TIÊN (không phải cuối).
///   - Mỗi kỳ có khối riêng dạng:
///       "... Kỳ QSMT: #00854 ... Ngày: 29/08/2026 - 21:00
///        06  07  12  18  20  09
///        Giá trị giải Độc Đắc
///        7.263.527.500
///        ...
///        Giải Độc Đắc   5 số & ĐB   0   7.263.527.500
///        Giải Nhất      5 số        1   10.000.000
///        ..."
///   - 6 số cách nhau bằng khoảng trắng: 5 số đầu là số chính (đã sắp XẾP
///     TĂNG DẦN), số thứ 6 là số đặc biệt (KHÔNG nằm trong thứ tự tăng dần
///     đó — ví dụ "02 26 27 32 34 08": 02<26<27<32<34 tăng dần, còn 08 là
///     đặc biệt, không phải phần tử tăng dần tiếp theo).
///   - Cột "Trùng" của bảng bậc giải đôi khi CÓ chữ số (vd "5 số & ĐB", "4
///     số") nên KHÔNG thể lấy "2 số đầu tiên tìm thấy" như vietlott.vn —
///     phải lấy 2 SỐ CUỐI CÙNG trong đoạn văn bản của từng dòng (SL rồi đến
///     Giá trị luôn là 2 số cuối, bất kể cột Trùng có số hay không).
class MinhNgocParser {
  static final _kyHeader = RegExp(
    r'Kỳ QSMT:\s*#(\d{2,6})[\s\S]{0,150}?Ngày:\s*(\d{2})/(\d{2})/(\d{4})',
  );
  static final _nextKyHeader = RegExp(r'Kỳ QSMT:\s*#\d{2,6}');
  static final _numbers = RegExp(
    r'(?<![:.\d])(\d{2})\s+(\d{2})\s+(\d{2})\s+(\d{2})\s+(\d{2})\s+(\d{2})(?!\d)',
  );
  static final _jackpotLabel = RegExp(r'Giá trị giải Độc Đắc');
  static final _money = RegExp(r'([\d]{1,3}(?:\.\d{3})+|\d+)');

  static const _tierNames = [
    'Giải Độc Đắc',
    'Giải Nhất',
    'Giải Nhì',
    'Giải Ba',
    'Giải Tư',
    'Giải Năm',
    'Giải Khuyến Khích',
  ];

  // Các HTML entity hay gặp trên trang - đặc biệt &nbsp; hay được dùng thay
  // khoảng trắng thường giữa các số/ô bảng. Nếu không giải mã, "\s+" trong
  // _numbers/_money sẽ không khớp được với chuỗi ký tự "&nbsp;" (đây từng là
  // nguyên nhân khiến parse() trả null dù trang tải về bình thường).
  static String _decodeEntities(String s) {
    return s
        .replaceAll(RegExp(r'&nbsp;', caseSensitive: false), ' ')
        .replaceAllMapped(
          RegExp(r'&#(\d+);'),
          (m) => String.fromCharCode(int.parse(m.group(1)!)),
        )
        .replaceAllMapped(
          RegExp(r'&#x([0-9a-fA-F]+);'),
          (m) => String.fromCharCode(int.parse(m.group(1)!, radix: 16)),
        )
        .replaceAll(RegExp(r'&amp;', caseSensitive: false), '&')
        .replaceAll(RegExp(r'&lt;', caseSensitive: false), '<')
        .replaceAll(RegExp(r'&gt;', caseSensitive: false), '>')
        .replaceAll(RegExp(r'&quot;', caseSensitive: false), '"')
        .replaceAll(RegExp(r'&#0?39;|&apos;', caseSensitive: false), "'");
  }

  static String _clean(String html) {
    return _decodeEntities(html
            .replaceAll(RegExp(r'<script[\s\S]*?</script>', caseSensitive: false), ' ')
            .replaceAll(RegExp(r'<style[\s\S]*?</style>', caseSensitive: false), ' ')
            .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n')
            .replaceAll(RegExp(r'<[^>]+>'), ' '))
        .replaceAll(RegExp(r'[ \t]+'), ' ')
        .replaceAll(RegExp(r'\n\s*\n+'), '\n')
        .trim();
  }

  static int? _toInt(String s) => int.tryParse(s.replaceAll('.', ''));

  /// Trả về null nếu bất kỳ phần nào không đọc chắc chắn được.
  static Snapshot? parse(String html) => parseVerbose(html).$1;

  /// Giống [parse] nhưng kèm theo LÝ DO cụ thể khi thất bại — để phân biệt
  /// "trang tải về không phải trang mong đợi (có thể bị chặn bot / đổi
  /// domain / đổi cấu trúc hoàn toàn)" với "chỉ 1 phần nhỏ không khớp".
  static (Snapshot?, String?) parseVerbose(String html) {
    final text = _clean(html);

    // Kỳ ĐẦU TIÊN xuất hiện trên trang = kỳ MỚI NHẤT (trang sắp xếp mới
    // nhất trước).
    final kyMatch = _kyHeader.firstMatch(text);
    if (kyMatch == null) {
      final hasKy = text.contains('Kỳ QSMT');
      final hasJackpotWord = text.contains('Độc Đắc');
      // Khi CÓ thấy chữ "Kỳ QSMT" nhưng regex vẫn không khớp, in ra NGUYÊN
      // VĂN đoạn xung quanh vị trí tìm thấy — để phân biệt "trang rút gọn
      // chỉ còn chữ này trong <title>/<meta>" (bị chặn thật) với "định dạng
      // đổi khác đôi chút" (chỉ cần nới regex). Không có đoạn này thì mỗi
      // lần lỗi đều phải đoán mù.
      String? kyContext;
      if (hasKy) {
        final idx = text.indexOf('Kỳ QSMT');
        final start = (idx - 30).clamp(0, text.length);
        final end = (idx + 150).clamp(0, text.length);
        kyContext = text.substring(start, end);
      }
      return (
        null,
        'không tìm thấy khối "Kỳ QSMT..." trong trang tải về (dài ${text.length} '
            'ký tự, ${hasKy ? "CÓ" : "KHÔNG"} thấy chữ "Kỳ QSMT", '
            '${hasJackpotWord ? "CÓ" : "KHÔNG"} thấy chữ "Độc Đắc" — nếu cả 2 đều '
            'KHÔNG thấy, khả năng cao trang bị chặn/đổi nội dung cho app, không '
            'phải lỗi đọc dữ liệu)'
            '${kyContext != null ? ' | ngữ cảnh quanh "Kỳ QSMT": "$kyContext"' : ''}',
      );
    }
    final drawId = kyMatch.group(1)!.padLeft(5, '0');
    final drawDate = '${kyMatch.group(4)}-${kyMatch.group(3)}-${kyMatch.group(2)}';

    // Chỉ xét trong phạm vi khối của kỳ này (đến trước khi "Kỳ QSMT:" tiếp
    // theo xuất hiện, hoặc hết văn bản) — tránh lẫn dữ liệu từ kỳ trước đó.
    final nextKyMatch = _nextKyHeader.firstMatch(text.substring(kyMatch.end));
    final blockEnd = nextKyMatch != null ? kyMatch.end + nextKyMatch.start : text.length;
    final block = text.substring(kyMatch.start, blockEnd);
    final kyEndInBlock = kyMatch.end - kyMatch.start;

    final numMatch = _numbers.firstMatch(block.substring(kyEndInBlock));
    if (numMatch == null) {
      return (
        null,
        'thấy kỳ #$drawId nhưng không tìm thấy dãy 6 số ngay sau đó (đoạn văn '
            'bản: "${block.substring(kyEndInBlock, kyEndInBlock + (block.length - kyEndInBlock < 60 ? block.length - kyEndInBlock : 60)).trim()}")',
      );
    }
    final main = <int>[
      int.parse(numMatch.group(1)!),
      int.parse(numMatch.group(2)!),
      int.parse(numMatch.group(3)!),
      int.parse(numMatch.group(4)!),
      int.parse(numMatch.group(5)!),
    ];
    if (main.toSet().length != 5 || main.any((n) => n < 1 || n > 35)) {
      return (null, 'kỳ #$drawId: 5 số chính đọc được không hợp lệ ($main)');
    }
    // main phải đã ở dạng tăng dần trên trang (không tự sort ở đây) — nếu
    // không tăng dần tức là đọc sai vị trí, coi như thất bại cho an toàn.
    for (var i = 1; i < main.length; i++) {
      if (main[i] <= main[i - 1]) {
        return (null, 'kỳ #$drawId: 5 số chính đọc được không theo thứ tự tăng dần ($main)');
      }
    }
    final special = int.parse(numMatch.group(6)!);
    if (special < 1 || special > 12) {
      return (null, 'kỳ #$drawId: số đặc biệt đọc được không hợp lệ ($special)');
    }

    final draw = Draw(drawId: drawId, drawDate: drawDate, numbers: main, special: special);

    final jackpotLabelMatch = _jackpotLabel.firstMatch(block);
    if (jackpotLabelMatch == null) {
      return (null, 'kỳ #$drawId: không tìm thấy chữ "Giá trị giải Độc Đắc"');
    }
    final jackpotMatch = _money.firstMatch(block.substring(jackpotLabelMatch.end));
    if (jackpotMatch == null) {
      return (null, 'kỳ #$drawId: tìm thấy "Giá trị giải Độc Đắc" nhưng không thấy số tiền theo sau');
    }
    final jackpotVnd = _toInt(jackpotMatch.group(0)!);
    if (jackpotVnd == null || jackpotVnd < 1000000) {
      return (null, 'kỳ #$drawId: giá trị Độc Đắc đọc được không hợp lệ ($jackpotVnd)');
    }

    // Bang 7 bac giai: tim vi tri tung ten bac giai, cua so cua moi dong la
    // [het ten bac giai nay .. bat dau ten bac giai tiep theo]. Lay 2 SO
    // CUOI CUNG trong cua so do (SL, Gia tri) - vi cot "Trung" doi khi co
    // chu so (vd "5 so & DB") nen khong the lay 2 so DAU tien.
    final positions = <int>[];
    var searchFrom = jackpotLabelMatch.end + jackpotMatch.end;
    for (final name in _tierNames) {
      final idx = block.indexOf(name, searchFrom);
      positions.add(idx);
      if (idx >= 0) searchFrom = idx + name.length;
    }

    final tiers = <PrizeTier>[];
    for (var i = 0; i < _tierNames.length; i++) {
      final start = positions[i];
      if (start < 0) break;
      final contentStart = start + _tierNames[i].length;
      var contentEnd = block.length;
      for (var j = i + 1; j < positions.length; j++) {
        if (positions[j] >= 0) {
          contentEnd = positions[j];
          break;
        }
      }
      if (contentEnd <= contentStart) break;
      final window = block.substring(contentStart, contentEnd);
      final nums = _money.allMatches(window).toList();
      if (nums.length < 2) break;
      final count = _toInt(nums[nums.length - 2].group(0)!);
      final value = _toInt(nums[nums.length - 1].group(0)!);
      if (count == null || value == null) break;
      final rule = window.substring(0, nums[nums.length - 2].start).trim();
      tiers.add(PrizeTier(name: _tierNames[i], rule: rule, count: count, valueVnd: value));
    }

    return (
      Snapshot(
        jackpotVnd: jackpotVnd,
        jackpotDrawId: drawId,
        latestDraw: draw,
        draws: [draw],
        jackpotSource: 'xosominhngoc.net.vn',
        drawSource: 'xosominhngoc.net.vn',
        prizeTiers: tiers.length == _tierNames.length ? tiers : const [],
      ),
      null,
    );
  }
}
