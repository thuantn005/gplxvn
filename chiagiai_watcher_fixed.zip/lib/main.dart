import 'package:flutter/material.dart';

import 'screens/root_screen.dart';
import 'services/background_service.dart';
import 'services/notification_service.dart';
import 'theme/app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  await NotificationService.requestPermission();
  await JackpotBackgroundService.initialize();
  runApp(const ChiaGiaiApp());
}

class ChiaGiaiApp extends StatelessWidget {
  const ChiaGiaiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Săn Chia Giải',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: const RootScreen(),
    );
  }
}
