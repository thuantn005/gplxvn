import 'dart:async';

import 'package:flutter/material.dart';

import 'screens/root_screen.dart';
import 'services/ads_service.dart';
import 'services/app_language.dart';
import 'services/background_service.dart';
import 'services/home_widget_service.dart';
import 'services/jackpot_storage_service.dart';
import 'services/notification_service.dart';
import 'theme/app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  await NotificationService.requestPermission();
  await JackpotBackgroundService.initialize();
  await AppLanguage.load();
  await AppTheme.load();
  // Khong await day xuong hang de tranh lam cham thoi gian mo app neu SDK
  // quang cao khoi dong cham (vd mang yeu) — cac man hinh dung banner/
  // rewarded se tu load rieng khi can, khong phu thuoc vao ket qua nay.
  unawaited(AdsService.initialize());
  // Day du lieu CACHE (da co san tu lan kiem tra truoc) ra widget ngay,
  // khong doi tan lan kiem tra nen tiep theo — de widget khong trong rong
  // trong luc do neu nguoi dung vua gan widget.
  unawaited((() async {
    final storage = JackpotStorageService();
    await HomeWidgetService.push(
      jackpotVnd: await storage.lastJackpot,
      drawId: await storage.lastDrawId,
    );
  })());
  runApp(const ChiaGiaiApp());
}

class ChiaGiaiApp extends StatelessWidget {
  const ChiaGiaiApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Rebuild toan bo cay widget khi doi ngon ngu HOAC doi dark mode, de
    // moi loi goi t() / AppColors.xxx trong build() cua cac man hinh con
    // cap nhat lai theo lua chon moi.
    return ValueListenableBuilder<bool>(
      valueListenable: AppLanguage.isEnglish,
      builder: (context, isEnglish, _) {
        return ValueListenableBuilder<bool>(
          valueListenable: AppTheme.isDark,
          builder: (context, isDark, __) {
            return MaterialApp(
              title: isEnglish ? 'Jackpot Share Hunter 535' : 'Săn Chia Giải 535',
              debugShowCheckedModeBanner: false,
              theme: buildAppTheme(),
              // KHÔNG dùng `const RootScreen()` — Flutter có tối ưu bỏ qua
              // rebuild subtree khi widget con y hệt (identical) giữa 2 lần
              // build cha, nghĩa là nếu để const thì khi đổi ngôn ngữ/dark
              // mode, các tab ĐANG MỞ SẴN (Thống Kê, Sinh Số, Cài đặt...) sẽ
              // KHÔNG áp dụng màu/chữ mới cho tới khi có setState cục bộ nào
              // đó xảy ra ở đúng tab đó (rất khó đoán, dễ gây "đổi nửa vời").
              home: RootScreen(),
            );
          },
        );
      },
    );
  }
}
