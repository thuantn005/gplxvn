import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../models/draw.dart';
import '../theme/app_theme.dart';

/// Bảng 7 bậc giải (Số lượng giải / Giá trị giải) — TÁCH RA từ home_screen
/// theo yêu cầu: không hiện trên Home nữa, chuyển hẳn sang tab Thống Kê để
/// Home gọn hơn, chỉ tập trung vào kết quả kỳ mới nhất.
class PrizeTable extends StatelessWidget {
  final List<PrizeTier> tiers;
  final String Function(String vi, String en) t;
  final String? headerSuffix; // vd "#00856" để biết đang xem kỳ nào

  const PrizeTable({super.key, required this.tiers, required this.t, this.headerSuffix});

  static String _thousands(int v) {
    final s = v.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  @override
  Widget build(BuildContext context) {
    if (tiers.isEmpty) return const SizedBox.shrink();
    return Container(
      decoration: BoxDecoration(
        color: AppColors.cardIvory,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.gold.withOpacity(0.4)),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 11),
            color: AppColors.luckyRed,
            alignment: Alignment.center,
            child: Text(
              headerSuffix == null
                  ? t('Số lượng trúng giải kỳ này', 'Winners this draw')
                  : '${t('Số lượng trúng giải', 'Winners')} $headerSuffix',
              style: GoogleFonts.baloo2(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14.5),
            ),
          ),
          _headerRow(),
          for (int i = 0; i < tiers.length; i++) _dataRow(tiers[i], i.isEven),
        ],
      ),
    );
  }

  Widget _headerRow() {
    final style = TextStyle(fontWeight: FontWeight.bold, fontSize: 12.5, color: AppColors.ink);
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 10),
      color: AppColors.gold.withOpacity(0.18),
      child: Row(
        children: [
          Expanded(flex: 3, child: Text(t('Giải', 'Prize'), style: style)),
          Expanded(flex: 2, child: Text(t('SL', 'Qty'), style: style, textAlign: TextAlign.center)),
          Expanded(flex: 4, child: Text(t('Giá trị', 'Value'), style: style, textAlign: TextAlign.right)),
        ],
      ),
    );
  }

  Widget _dataRow(PrizeTier tier, bool alt) {
    final isJackpot = tier.name.contains('Độc Đắc');
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
      color: alt ? AppColors.ivory.withOpacity(0.5) : Colors.transparent,
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              tier.name,
              style: TextStyle(
                fontSize: 13,
                fontWeight: isJackpot ? FontWeight.w800 : FontWeight.w500,
                color: isJackpot ? AppColors.luckyRed : AppColors.ink,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              _thousands(tier.count),
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                fontWeight: tier.count > 0 ? FontWeight.w700 : FontWeight.w400,
                color: tier.count > 0 ? AppColors.jade : AppColors.muted,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Text(
              '${_thousands(tier.valueVnd)} đ',
              textAlign: TextAlign.right,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}
