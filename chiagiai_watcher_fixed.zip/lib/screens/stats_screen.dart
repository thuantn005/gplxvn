import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/draw_history_source.dart';
import '../services/jackpot_storage_service.dart';
import '../services/share_draw_machine.dart';
import '../theme/app_theme.dart';

class StatsScreen extends StatefulWidget {
  const StatsScreen({super.key});

  @override
  State<StatsScreen> createState() => _StatsScreenState();
}

class _StatsScreenState extends State<StatsScreen> {
  final _storage = JackpotStorageService();
  bool _loading = true;
  List<JackpotHistoryEntry> _history = [];
  List<ShareDrawLogEntry> _log = [];

  NumberFreqStats? _freqStats;
  bool _freqLoading = false;
  String? _freqError;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool forceFreq = false}) async {
    final h = await _storage.jackpotHistoryFull();
    final l = await _storage.shareDrawLog();
    final cachedFreq = await _storage.numberFreqStats;
    if (!mounted) return;
    setState(() {
      _history = h;
      _log = l;
      _freqStats = cachedFreq;
      _loading = false;
    });

    // Cache qua 24h hoac chua co du lieu -> cao lai tu GitHub. Nguoi dung
    // bam nut lam moi thi luon cao lai bat ke cache con moi hay khong.
    final stale = cachedFreq == null ||
        DateTime.now().difference(cachedFreq.fetchedAt) > const Duration(hours: 24);
    if (forceFreq || stale) {
      await _refreshFreqStats();
    }
  }

  Future<void> _refreshFreqStats() async {
    if (!mounted) return;
    setState(() {
      _freqLoading = true;
      _freqError = null;
    });
    try {
      final stats = await DrawHistorySource.fetchAndCompute();
      if (stats != null) {
        await _storage.setNumberFreqStats(stats);
        if (!mounted) return;
        setState(() => _freqStats = stats);
      } else if (_freqStats == null) {
        if (!mounted) return;
        setState(() => _freqError = 'Không đọc được dữ liệu lịch sử từ GitHub');
      }
    } catch (e) {
      if (!mounted) return;
      if (_freqStats == null) setState(() => _freqError = 'Lỗi tải lịch sử: $e');
    } finally {
      if (mounted) setState(() => _freqLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Thống Kê'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: () => _load(forceFreq: true)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () => _load(forceFreq: true),
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (_history.isEmpty && _log.isEmpty && _freqStats == null) _buildEmptyState(),
                  _sectionTitle('Tần suất về số (toàn bộ lịch sử)'),
                  const SizedBox(height: 8),
                  _buildFreqSection(),
                  const SizedBox(height: 20),
                  if (_history.isNotEmpty) ...[
                    _sectionTitle('Lịch sử giá trị Độc Đắc'),
                    const SizedBox(height: 8),
                    _buildJackpotChart(),
                    const SizedBox(height: 8),
                    Text(
                      '${_history.length} kỳ đã ghi nhận (kỳ #${_history.first.drawId} → '
                      '#${_history.last.drawId})',
                      style: TextStyle(fontSize: 11, color: AppColors.muted),
                    ),
                    const SizedBox(height: 20),
                  ],
                  if (_log.isNotEmpty) ...[
                    _sectionTitle('Tần suất kỳ chia giải'),
                    const SizedBox(height: 8),
                    _buildShareDrawStats(),
                    const SizedBox(height: 12),
                    _buildShareDrawLogList(),
                  ],
                  const SizedBox(height: 12),
                  Text(
                    'Phần "Tần suất về số" lấy từ toàn bộ lịch sử kỳ quay (nguồn: GitHub '
                    'lotto-scan). Riêng lịch sử giá trị Độc Đắc và tần suất chia giải bên '
                    'dưới chỉ ghi nhận TỪ KHI cài app này — không hồi cứu quá khứ trước đó. '
                    'Đây đều là thống kê mô tả thuần túy, không dùng để dự đoán kỳ quay '
                    'tiếp theo.',
                    style: TextStyle(fontSize: 10.5, color: AppColors.muted, fontStyle: FontStyle.italic),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildEmptyState() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 60),
      child: Column(
        children: [
          Icon(Icons.bar_chart, size: 48, color: AppColors.muted.withOpacity(0.4)),
          const SizedBox(height: 12),
          Text(
            'Chưa có dữ liệu thống kê.\nBấm "Kiểm tra ngay" ở tab Chia Giải để bắt đầu ghi nhận.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, color: AppColors.muted),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String s) =>
      Text(s, style: GoogleFonts.baloo2(fontSize: 15, fontWeight: FontWeight.w700));

  // ── Thống kê tần suất về số (từ file CSV lịch sử trên GitHub) ─────────

  Widget _buildFreqSection() {
    final stats = _freqStats;
    if (stats == null) {
      if (_freqLoading) {
        return const Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Center(child: CircularProgressIndicator()),
        );
      }
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.cardIvory,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.gold.withOpacity(0.4)),
        ),
        child: Row(
          children: [
            Icon(Icons.warning_amber_rounded, size: 18, color: AppColors.muted),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                _freqError ?? 'Chưa có dữ liệu — kéo xuống để làm mới.',
                style: TextStyle(fontSize: 12, color: AppColors.muted),
              ),
            ),
          ],
        ),
      );
    }

    final mostMain = stats.mainFreq.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final leastMain = stats.mainFreq.entries.toList()
      ..sort((a, b) => a.value.compareTo(b.value));
    final ganMain = List<int>.generate(35, (i) => i + 1)
      ..sort((a, b) => stats.mainGan(b).compareTo(stats.mainGan(a)));
    final mostSpecial = stats.specialFreq.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardIvory,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.gold.withOpacity(0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${stats.totalDraws} kỳ (#${stats.firstDrawId} → #${stats.lastDrawId}) — '
            'nguồn: GitHub lotto-scan',
            style: TextStyle(fontSize: 11, color: AppColors.muted),
          ),
          if (_freqLoading) ...[
            const SizedBox(height: 6),
            Row(
              children: [
                const SizedBox(
                  width: 12,
                  height: 12,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
                const SizedBox(width: 6),
                Text('Đang làm mới...', style: TextStyle(fontSize: 10.5, color: AppColors.muted)),
              ],
            ),
          ],
          const SizedBox(height: 12),
          _freqRow('Số chính về nhiều nhất', mostMain.take(6).map((e) => '${e.key} (${e.value})')),
          const SizedBox(height: 8),
          _freqRow('Số chính về ít nhất', leastMain.take(6).map((e) => '${e.key} (${e.value})')),
          const SizedBox(height: 8),
          _freqRow('Số chính "gan" lâu nhất',
              ganMain.take(6).map((n) => '$n (${stats.mainGan(n)} kỳ)')),
          const SizedBox(height: 8),
          _freqRow('Số đặc biệt về nhiều nhất',
              mostSpecial.take(6).map((e) => '${e.key} (${e.value})')),
        ],
      ),
    );
  }

  Widget _freqRow(String label, Iterable<String> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600)),
        const SizedBox(height: 4),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            for (final s in items)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.jade.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(s, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
              ),
          ],
        ),
      ],
    );
  }

  // ── Biểu đồ cột tự vẽ (không phụ thuộc thư viện chart ngoài) ───────────

  Widget _buildJackpotChart() {
    final shown = _history.length > 30 ? _history.sublist(_history.length - 30) : _history;
    final maxVal = shown.map((e) => e.jackpotVnd).reduce((a, b) => a > b ? a : b);

    return Container(
      padding: const EdgeInsets.fromLTRB(12, 16, 12, 8),
      decoration: BoxDecoration(
        color: AppColors.cardIvory,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.gold.withOpacity(0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('${(maxVal / 1e9).toStringAsFixed(1)} tỷ (cao nhất trong ${shown.length} kỳ gần đây)',
              style: TextStyle(fontSize: 11, color: AppColors.muted)),
          const SizedBox(height: 8),
          SizedBox(
            height: 140,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final e in shown)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 1),
                      child: Tooltip(
                        message: '#${e.drawId}\n${ShareDrawMachine.fmt(e.jackpotVnd)}',
                        child: Container(
                          height: 130 * (e.jackpotVnd / maxVal).clamp(0.03, 1.0),
                          decoration: BoxDecoration(
                            color: e.jackpotVnd >= 12000000000 ? AppColors.luckyRed : AppColors.jade,
                            borderRadius: const BorderRadius.vertical(top: Radius.circular(2)),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('#${shown.first.drawId}', style: TextStyle(fontSize: 9, color: AppColors.muted)),
              Row(
                children: [
                  _legendDot(AppColors.jade, '< 12 tỷ'),
                  const SizedBox(width: 10),
                  _legendDot(AppColors.luckyRed, '≥ 12 tỷ'),
                ],
              ),
              Text('#${shown.last.drawId}', style: TextStyle(fontSize: 9, color: AppColors.muted)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _legendDot(Color c, String label) {
    return Row(
      children: [
        Container(width: 8, height: 8, decoration: BoxDecoration(color: c, shape: BoxShape.circle)),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(fontSize: 9, color: AppColors.muted)),
      ],
    );
  }

  // ── Thống kê tần suất chia giải ─────────────────────────────────────

  Widget _buildShareDrawStats() {
    final completed = _log.where((e) => e.kind == 'completed').toList();
    final cancelled = _log.where((e) => e.kind == 'cancelled').length;
    final scheduled = _log.where((e) => e.kind == 'scheduled').length;

    String? avgGapText;
    if (completed.length >= 2) {
      final dates = completed.map((e) => DateTime.tryParse(e.loggedAtIso)).whereType<DateTime>().toList()
        ..sort();
      if (dates.length >= 2) {
        final totalDays = dates.last.difference(dates.first).inDays;
        final avgDays = totalDays / (dates.length - 1);
        avgGapText = '~${avgDays.toStringAsFixed(0)} ngày/lần (trung bình)';
      }
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardIvory,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.gold.withOpacity(0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _statChip('Đã xác định', scheduled.toString(), AppColors.luckyRed),
              const SizedBox(width: 10),
              _statChip('Đã chia', completed.length.toString(), AppColors.jade),
              const SizedBox(width: 10),
              _statChip('Đã huỷ', cancelled.toString(), AppColors.muted),
            ],
          ),
          if (avgGapText != null) ...[
            const SizedBox(height: 10),
            Text('Khoảng cách trung bình giữa các lần chia giải: $avgGapText',
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
          ],
        ],
      ),
    );
  }

  Widget _statChip(String label, String value, Color color) {
    return Expanded(
      child: Column(
        children: [
          Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: color)),
          Text(label, style: TextStyle(fontSize: 10.5, color: AppColors.muted), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildShareDrawLogList() {
    final reversed = _log.reversed.take(15).toList();
    return Column(
      children: [
        for (final e in reversed) _logRow(e),
      ],
    );
  }

  Widget _logRow(ShareDrawLogEntry e) {
    final (icon, color, label) = switch (e.kind) {
      'scheduled' => (Icons.event_available, AppColors.luckyRed, 'Xác định kỳ chia giải'),
      'completed' => (Icons.check_circle, AppColors.jade, 'Đã chia giải xong'),
      'cancelled' => (Icons.cancel, AppColors.muted, 'Huỷ (có người trúng trước)'),
      _ => (Icons.info, AppColors.muted, e.kind),
    };
    final dt = DateTime.tryParse(e.loggedAtIso);
    final dateStr = dt != null
        ? '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}'
        : '';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                if (e.jackpotVnd != null)
                  Text(ShareDrawMachine.fmt(e.jackpotVnd),
                      style: TextStyle(fontSize: 11, color: AppColors.muted)),
              ],
            ),
          ),
          Text(dateStr, style: TextStyle(fontSize: 10.5, color: AppColors.muted)),
        ],
      ),
    );
  }
}
