import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../models/draw.dart';
import '../services/background_service.dart';
import '../services/jackpot_storage_service.dart';
import '../services/share_draw_machine.dart';
import '../theme/app_theme.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _storage = JackpotStorageService();
  bool _checking = false;

  String _lastDrawText = '—';
  String _lastStatus = 'Chưa kiểm tra lần nào';
  String _lastSource = '—';
  int? _lastJackpot;
  ShareDrawState? _state;
  List<int> _mainNumbers = [];
  int? _specialNumber;
  String _drawIdLabel = '';
  List<PrizeTier> _tiers = [];

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await _load();
    // Cai moi / chua bao gio kiem tra thanh cong -> tu dong kiem tra ngay
    // lan dau, khong bat nguoi dung phai biet la can bam nut "Kiem tra
    // ngay" thi moi co du lieu.
    if (!mounted) return;
    if (_drawIdLabel.isEmpty) {
      await _checkNow();
    }
  }

  Future<void> _load() async {
    final drawText = await _storage.lastDrawText;
    final status = await _storage.lastStatus;
    final source = await _storage.lastSource;
    final jackpot = await _storage.lastJackpot;
    final state = await _storage.loadState();
    final tiers = await _storage.prizeTiers;
    final drawId = await _storage.lastDrawId;

    // "lastDrawText" luu dang "#00852 — 11 17 28 29 34 + ĐB 09", tach so ra
    // de ve bi tron rieng thay vi hien nguyen chuoi text.
    final numbers = <int>[];
    int? special;
    final match = RegExp(r'((?:\d{2}\s+){4}\d{2})\s*\+\s*ĐB\s*(\d{2})').firstMatch(drawText);
    if (match != null) {
      numbers.addAll(match.group(1)!.trim().split(RegExp(r'\s+')).map(int.parse));
      special = int.tryParse(match.group(2)!);
    }

    if (!mounted) return;
    setState(() {
      _lastDrawText = drawText;
      _lastStatus = status;
      _lastSource = source;
      _lastJackpot = jackpot;
      _state = state;
      _tiers = tiers;
      _mainNumbers = numbers;
      _specialNumber = special;
      _drawIdLabel = drawId != null ? '#$drawId' : '';
    });
  }

  Future<void> _checkNow() async {
    setState(() => _checking = true);
    try {
      await JackpotBackgroundService.checkNow();
    } catch (_) {
      // trang thai loi da duoc luu, se hien qua _lastStatus sau khi _load()
    }
    await _load();
    if (mounted) setState(() => _checking = false);
  }

  @override
  Widget build(BuildContext context) {
    final state = _state;
    final pending = state?.pending ?? false;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Săn Chia Giải'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
              _load();
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _checkNow,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildResultCard(),
            const SizedBox(height: 14),
            if (pending) ...[
              _buildPendingCard(state!),
              const SizedBox(height: 14),
            ],
            if (_tiers.isNotEmpty) ...[
              _buildPrizeTable(),
              const SizedBox(height: 14),
            ],
            _buildStatusFooter(),
            const SizedBox(height: 20),
            Center(
              child: ElevatedButton.icon(
                onPressed: _checking ? null : _checkNow,
                icon: _checking
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : const Icon(Icons.refresh),
                label: Text(_checking ? 'Đang kiểm tra...' : 'Kiểm tra ngay'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.luckyRed,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
              ),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  // ── Card kết quả kỳ mới nhất: kỳ/ngày + dãy bi tròn + pill Độc Đắc ──────

  Widget _buildResultCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.cardIvory,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.gold.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'KỲ QUAY THƯỞNG $_drawIdLabel',
            style: GoogleFonts.baloo2(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppColors.muted,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            _lastDrawText,
            style: const TextStyle(fontSize: 12, color: AppColors.muted),
          ),
          const SizedBox(height: 14),
          if (_mainNumbers.length == 5 && _specialNumber != null)
            _buildBallRow()
          else
            Text(_lastDrawText, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
          const SizedBox(height: 16),
          _buildJackpotPill(),
        ],
      ),
    );
  }

  Widget _buildBallRow() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final n in _mainNumbers) _ball(n, AppColors.jade),
        Container(
          width: 2,
          height: 40,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          color: AppColors.muted.withOpacity(0.3),
        ),
        _ball(_specialNumber!, const Color(0xFFE07B1A)),
      ],
    );
  }

  Widget _ball(int n, Color color) {
    return Container(
      width: 42,
      height: 42,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color.withOpacity(0.85), color],
          center: const Alignment(-0.3, -0.3),
        ),
        boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 4, offset: const Offset(0, 2))],
      ),
      child: Text(
        n.toString().padLeft(2, '0'),
        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15),
      ),
    );
  }

  Widget _buildJackpotPill() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Giá trị giải Độc Đắc',
            style: TextStyle(fontSize: 12.5, color: AppColors.muted, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 14),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: AppColors.luckyRed,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(color: AppColors.luckyRed.withOpacity(0.35), blurRadius: 10, offset: const Offset(0, 4)),
            ],
          ),
          child: Text(
            _lastJackpot != null ? '${_thousands(_lastJackpot!)} VNĐ' : ShareDrawMachine.fmt(_lastJackpot),
            style: GoogleFonts.baloo2(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white),
          ),
        ),
      ],
    );
  }

  // ── Bảng 7 bậc giải ──────────────────────────────────────────────────

  Widget _buildPrizeTable() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.cardIvory,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.gold.withOpacity(0.4)),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 10),
            color: AppColors.luckyRed,
            alignment: Alignment.center,
            child: Text(
              'Số lượng trúng giải kỳ này',
              style: GoogleFonts.baloo2(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14),
            ),
          ),
          _tableHeaderRow(),
          for (int i = 0; i < _tiers.length; i++) _tableDataRow(_tiers[i], i.isEven),
        ],
      ),
    );
  }

  Widget _tableHeaderRow() {
    const style = TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: AppColors.ink);
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
      color: AppColors.gold.withOpacity(0.18),
      child: const Row(
        children: [
          Expanded(flex: 3, child: Text('Giải', style: style)),
          Expanded(flex: 2, child: Text('SL', style: style, textAlign: TextAlign.center)),
          Expanded(flex: 4, child: Text('Giá trị', style: style, textAlign: TextAlign.right)),
        ],
      ),
    );
  }

  Widget _tableDataRow(PrizeTier t, bool alt) {
    final isJackpot = t.name.contains('Độc Đắc');
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 10),
      color: alt ? AppColors.ivory.withOpacity(0.5) : Colors.transparent,
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              t.name,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: isJackpot ? FontWeight.w800 : FontWeight.w500,
                color: isJackpot ? AppColors.luckyRed : AppColors.ink,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              _thousands(t.count),
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: t.count > 0 ? FontWeight.w700 : FontWeight.w400,
                color: t.count > 0 ? AppColors.jade : AppColors.muted,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Text(
              '${_thousands(t.valueVnd)} đ',
              textAlign: TextAlign.right,
              style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  static String _thousands(int v) {
    final s = v.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  // ── Card "đã xác định kỳ chia giải" + footer trạng thái ─────────────

  Widget _buildPendingCard(ShareDrawState state) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.gold.withOpacity(0.15),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.gold),
      ),
      child: Row(
        children: [
          const Icon(Icons.celebration, color: AppColors.luckyRed, size: 28),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Đã xác định kỳ CHIA GIẢI',
                  style: GoogleFonts.baloo2(fontWeight: FontWeight.w700, fontSize: 14),
                ),
                const SizedBox(height: 2),
                Text(
                  'Kỳ quay 21:00 ngày ${state.shareDate ?? "?"}',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                ),
                Text(
                  'Đỉnh Độc Đắc trước chia: ${ShareDrawMachine.fmt(state.peakJackpot)}',
                  style: TextStyle(fontSize: 11.5, color: AppColors.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusFooter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(_lastStatus, style: TextStyle(fontSize: 11.5, color: AppColors.muted)),
        const SizedBox(height: 2),
        Text('Nguồn: $_lastSource', style: TextStyle(fontSize: 10.5, color: AppColors.muted)),
      ],
    );
  }
}
