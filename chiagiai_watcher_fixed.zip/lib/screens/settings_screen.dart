import 'package:flutter/material.dart';

import '../services/jackpot_storage_service.dart';
import '../services/share_draw_machine.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _storage = JackpotStorageService();
  bool _loading = true;
  final Map<EventKind, bool> _notifyEnabled = {};

  static const _labels = {
    EventKind.scheduled: ('Đã xác định kỳ chia giải', 'Báo ngay khi phát hiện Độc Đắc vượt 12 tỷ'),
    EventKind.reminder: ('Nhắc TỐI NAY chia giải', 'Báo vào đúng ngày diễn ra kỳ chia giải'),
    EventKind.missed: ('Bỏ lỡ kỳ (mất mạng)', 'Báo khi ứng dụng phát hiện có thể đã bỏ lỡ 1 kỳ'),
    EventKind.cancelled: ('Huỷ kỳ chia giải', 'Báo khi có người trúng trước ngày dự kiến'),
    EventKind.completed: ('Kỳ chia giải đã xong', 'Báo sau khi kỳ chia giải diễn ra'),
    EventKind.newDraw: ('Kết quả mỗi kỳ mới', 'Báo mỗi khi có kỳ quay mới (tần suất cao)'),
    EventKind.scrapeFail: ('Lỗi tra cứu', 'Báo khi không lấy được dữ liệu từ mọi nguồn'),
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final map = <EventKind, bool>{};
    for (final k in _labels.keys) {
      map[k] = await _storage.isEnabled(k);
    }
    if (!mounted) return;
    setState(() {
      _notifyEnabled.addAll(map);
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Cài đặt')),
      body: ListView(
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text('Thông báo', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          ),
          for (final entry in _labels.entries)
            SwitchListTile(
              title: Text(entry.value.$1),
              subtitle: Text(entry.value.$2, style: const TextStyle(fontSize: 12)),
              value: _notifyEnabled[entry.key] ?? false,
              activeColor: AppColors.luckyRed,
              onChanged: (v) async {
                await _storage.setEnabled(entry.key, v);
                setState(() => _notifyEnabled[entry.key] = v);
              },
            ),
          const Divider(height: 32),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Text('Nguồn dữ liệu', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'App đọc trực tiếp từ 1 nguồn DUY NHẤT: vietlott.vn chính thức — '
              'không dùng nguồn phụ/mirror nào khác.',
              style: TextStyle(fontSize: 12, color: AppColors.muted),
            ),
          ),
          const SizedBox(height: 24),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'App tự động kiểm tra nền mỗi 3 tiếng. Dữ liệu Độc Đắc và kết quả quay '
              'được đọc trực tiếp từ trang chính thức vietlott.vn — app không dự đoán, '
              'không đảm bảo trúng thưởng, chỉ theo dõi và báo đúng luật chia giải.',
              style: TextStyle(fontSize: 11.5, color: AppColors.muted),
            ),
          ),
        ],
      ),
    );
  }
}
