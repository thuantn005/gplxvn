import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import 'home_screen.dart';
import 'random_pick_screen.dart';
import 'stats_screen.dart';

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int _index = 0;

  // GlobalKey de RootScreen chu dong goi refreshNextDrawId() moi khi
  // nguoi dung chuyen sang tab "Sinh So" -> bat kip lastDrawId ma tab
  // "Chia Giai" vua cao xong (IndexedStack khong tu goi lai initState khi
  // doi tab, xem giai thich trong random_pick_screen.dart).
  final _randomPickKey = GlobalKey<RandomPickScreenState>();

  late final _screens = [
    const HomeScreen(),
    RandomPickScreen(key: _randomPickKey),
    const StatsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) {
          setState(() => _index = i);
          if (i == 1) {
            _randomPickKey.currentState?.refreshNextDrawId();
          }
        },
        backgroundColor: AppColors.cardIvory,
        indicatorColor: AppColors.gold.withOpacity(0.3),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.emoji_events_outlined),
            selectedIcon: Icon(Icons.emoji_events, color: AppColors.luckyRed),
            label: 'Chia Giải',
          ),
          NavigationDestination(
            icon: Icon(Icons.casino_outlined),
            selectedIcon: Icon(Icons.casino, color: AppColors.luckyRed),
            label: 'Sinh Số',
          ),
          NavigationDestination(
            icon: Icon(Icons.bar_chart_outlined),
            selectedIcon: Icon(Icons.bar_chart, color: AppColors.luckyRed),
            label: 'Thống Kê',
          ),
        ],
      ),
    );
  }
}
