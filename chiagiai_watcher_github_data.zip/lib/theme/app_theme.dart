import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/jackpot_storage_service.dart';

/// Bật/tắt Dark Mode toàn app. Dùng ValueNotifier giống AppLanguage —
/// MaterialApp lắng nghe để rebuild lại theme khi đổi, AppColors đọc trực
/// tiếp .value (đồng bộ, không cần async) để mọi Text/Icon/Container dùng
/// AppColors.xxx tự động đổi màu theo, không cần sửa lại từng màn hình.
class AppTheme {
  static final ValueNotifier<bool> isDark = ValueNotifier<bool>(false);

  static Future<void> load() async {
    isDark.value = await JackpotStorageService().isDarkMode;
  }

  static Future<void> setDark(bool v) async {
    isDark.value = v;
    await JackpotStorageService().setIsDarkMode(v);
  }
}

/// LƯU Ý: dùng static GETTER (không phải static const) để đọc theo
/// AppTheme.isDark.value tại thời điểm build — nhờ vậy TOÀN BỘ code màn
/// hình hiện có (`AppColors.luckyRed`, `AppColors.cardIvory`...) vẫn chạy
/// nguyên xi không cần sửa gì, chỉ riêng những chỗ trước đây đánh dấu
/// `const` (TextStyle/Icon/BoxDecoration...) cần bỏ `const` đi vì getter
/// không phải hằng số biên dịch — đã rà soát và bỏ hết trong toàn bộ lib/.
class AppColors {
  static bool get _dark => AppTheme.isDark.value;

  static Color get luckyRed => _dark ? const Color(0xFFE0574F) : const Color(0xFFA61C1C);
  static Color get gold => _dark ? const Color(0xFFE8BE55) : const Color(0xFFD4A017);
  static Color get ivory => _dark ? const Color(0xFF16120E) : const Color(0xFFFFF7E8);
  static Color get ink => _dark ? const Color(0xFFF3E9DD) : const Color(0xFF2B1710);
  static Color get jade => _dark ? const Color(0xFF3FAE7C) : const Color(0xFF1F6E4A);
  static Color get muted => _dark ? const Color(0xFFAE9C89) : const Color(0xFF8A7A68);
  static Color get cardIvory => _dark ? const Color(0xFF241D16) : const Color(0xFFFFFDF7);
}

ThemeData buildAppTheme() {
  final dark = AppTheme.isDark.value;
  final base = ThemeData(
    useMaterial3: true,
    brightness: dark ? Brightness.dark : Brightness.light,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.luckyRed,
      brightness: dark ? Brightness.dark : Brightness.light,
      primary: AppColors.luckyRed,
      secondary: AppColors.gold,
      surface: AppColors.ivory,
    ),
    scaffoldBackgroundColor: AppColors.ivory,
    fontFamily: GoogleFonts.notoSans().fontFamily,
  );
  return base.copyWith(
    appBarTheme: AppBarTheme(
      backgroundColor: AppColors.luckyRed,
      foregroundColor: Colors.white,
      titleTextStyle: GoogleFonts.baloo2(
        fontSize: 21,
        fontWeight: FontWeight.w700,
        color: Colors.white,
      ),
      elevation: 0,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: AppColors.cardIvory,
      iconTheme: WidgetStateProperty.all(const IconThemeData(size: 27)),
      labelTextStyle: WidgetStateProperty.all(
        TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppColors.ink),
      ),
    ),
  );
}
