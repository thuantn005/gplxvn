import 'package:flutter/material.dart';

import '../services/app_language.dart';
import '../services/jackpot_storage_service.dart';
import '../services/share_draw_machine.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _storage = JackpotStorageService();
  bool _loading = true;
  final Map<EventKind, bool> _notifyEnabled = {};

  // (nhãn Việt, nhãn Anh, mô tả Việt, mô tả Anh)
  static const _labels = {
    EventKind.scheduled: (
      'Đã xác định kỳ chia giải',
      'Share draw confirmed',
      'Báo ngay khi phát hiện Độc Đắc vượt 12 tỷ',
      'Alert as soon as the jackpot passes 12 billion VND',
    ),
    EventKind.reminder: (
      'Nhắc TỐI NAY chia giải',
      'Reminder: share draw TONIGHT',
      'Báo vào đúng ngày diễn ra kỳ chia giải',
      'Alert on the day the share draw takes place',
    ),
    EventKind.missed: (
      'Bỏ lỡ kỳ (mất mạng)',
      'Missed draw (offline)',
      'Báo khi ứng dụng phát hiện có thể đã bỏ lỡ 1 kỳ',
      'Alert when the app detects a possibly missed draw',
    ),
    EventKind.cancelled: (
      'Huỷ kỳ chia giải',
      'Share draw cancelled',
      'Báo khi có người trúng trước ngày dự kiến',
      'Alert when someone wins before the expected date',
    ),
    EventKind.completed: (
      'Kỳ chia giải đã xong',
      'Share draw completed',
      'Báo sau khi kỳ chia giải diễn ra',
      'Alert after the share draw has taken place',
    ),
    EventKind.newDraw: (
      'Kết quả mỗi kỳ mới',
      'Every new draw result',
      'Báo mỗi khi có kỳ quay mới (tần suất cao)',
      'Alert on every new draw (high frequency)',
    ),
    EventKind.scrapeFail: (
      'Lỗi tra cứu',
      'Lookup failed',
      'Báo khi không lấy được dữ liệu từ mọi nguồn',
      'Alert when no source returns data',
    ),
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final map = <EventKind, bool>{};
    for (final k in _labels.keys) {
      map[k] = await _storage.isEnabled(k);
    }
    if (!mounted) return;
    setState(() {
      _notifyEnabled.addAll(map);
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final isEn = AppLanguage.isEnglish.value;
    return Scaffold(
      appBar: AppBar(title: Text(t('Cài đặt', 'Settings'))),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text(t('Ngôn ngữ', 'Language'),
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Icon(Icons.language, size: 26),
                const SizedBox(width: 16),
                Expanded(
                  child: SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment(value: false, label: Text('Tiếng Việt')),
                      ButtonSegment(value: true, label: Text('English')),
                    ],
                    selected: {isEn},
                    style: SegmentedButton.styleFrom(
                      selectedBackgroundColor: AppColors.luckyRed,
                      selectedForegroundColor: Colors.white,
                    ),
                    onSelectionChanged: (selection) => AppLanguage.setEnglish(selection.first),
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 32),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Text(t('Giao diện', 'Appearance'),
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          ),
          ValueListenableBuilder<bool>(
            valueListenable: AppTheme.isDark,
            builder: (context, isDark, _) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    const Icon(Icons.dark_mode_outlined, size: 26),
                    const SizedBox(width: 16),
                    Expanded(
                      child: SegmentedButton<bool>(
                        segments: [
                          ButtonSegment(value: false, label: Text(t('Sáng', 'Light'))),
                          ButtonSegment(value: true, label: Text(t('Tối', 'Dark'))),
                        ],
                        selected: {isDark},
                        style: SegmentedButton.styleFrom(
                          selectedBackgroundColor: AppColors.luckyRed,
                          selectedForegroundColor: Colors.white,
                        ),
                        onSelectionChanged: (selection) => AppTheme.setDark(selection.first),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          const Divider(height: 32),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Text(t('Thông báo', 'Notifications'),
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          ),
          for (final entry in _labels.entries)
            SwitchListTile(
              title: Text(t(entry.value.$1, entry.value.$2)),
              subtitle: Text(t(entry.value.$3, entry.value.$4), style: const TextStyle(fontSize: 12)),
              value: _notifyEnabled[entry.key] ?? false,
              activeColor: AppColors.luckyRed,
              onChanged: (v) async {
                await _storage.setEnabled(entry.key, v);
                setState(() => _notifyEnabled[entry.key] = v);
              },
            ),
          const Divider(height: 32),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              t(
                'App tự động kiểm tra nền mỗi 3 tiếng, dựa trên dữ liệu kết quả xổ số '
                'công khai. Ứng dụng không dự đoán, không đảm bảo trúng thưởng, chỉ '
                'theo dõi và báo đúng luật chia giải.\n\n'
                'Dữ liệu tổng hợp từ các trang xổ số công khai, không đại diện/liên kết '
                'với Vietlott hay bất kỳ trang nguồn nào.',
                'The app checks automatically every 3 hours, based on publicly '
                'available lottery result data. The app does not predict numbers '
                'or guarantee winnings, it only tracks and reports according to '
                'the official share-draw rule.\n\n'
                'Data is aggregated from public lottery result sites. This app is not '
                'affiliated with or endorsed by Vietlott or any of its data sources.',
              ),
              style: TextStyle(fontSize: 11.5, color: AppColors.muted),
            ),
          ),
        ],
      ),
    );
  }
}
