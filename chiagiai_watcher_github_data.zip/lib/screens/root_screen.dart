import 'package:flutter/material.dart';

import '../services/app_language.dart';
import '../services/jackpot_check_service.dart';
import '../theme/app_theme.dart';
import '../widgets/ad_banner_widget.dart';
import 'home_screen.dart';
import 'random_pick_screen.dart';
import 'stats_screen.dart';

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  /// Cho phép các tab con (vd Home) tự chuyển sang tab khác — ví dụ nút
  /// "Xem số lượng trúng giải →" trên Home nhảy thẳng sang tab Thống Kê mà
  /// không cần Navigator.push (giữ nguyên IndexedStack, không mất state).
  static final ValueNotifier<int> switchTabRequest = ValueNotifier<int>(-1);

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> with WidgetsBindingObserver {
  int _index = 0;

  // GlobalKey de RootScreen chu dong goi refresh() moi khi app quay lai
  // foreground - xem giai thich chi tiet trong HomeScreenState.refresh().
  final _homeKey = GlobalKey<HomeScreenState>();

  // GlobalKey de RootScreen chu dong goi refreshNextDrawId() moi khi
  // nguoi dung chuyen sang tab "Sinh So" -> bat kip lastDrawId ma tab
  // "Chia Giai" vua cao xong (IndexedStack khong tu goi lai initState khi
  // doi tab, xem giai thich trong random_pick_screen.dart).
  final _randomPickKey = GlobalKey<RandomPickScreenState>();

  // GlobalKey de tab "Thong Ke" tu tai lai (so luong trung giai ky nay,
  // lich su...) moi khi nguoi dung chuyen sang - cung ly do/co che nhu
  // _randomPickKey o tren (IndexedStack khong tu goi lai initState).
  final _statsKey = GlobalKey<StatsScreenState>();

  late final _screens = [
    HomeScreen(key: _homeKey),
    RandomPickScreen(key: _randomPickKey),
    StatsScreen(key: _statsKey),
  ];

  @override
  void initState() {
    super.initState();
    RootScreen.switchTabRequest.addListener(_onSwitchTabRequest);
    WidgetsBinding.instance.addObserver(this);
    // Bat tin hieu "vua co du lieu moi" tu JackpotCheckService.runCheck() -
    // bat truong hop tin FCM toi dung luc app dang MO SAN (foreground):
    // luc do khong co chuyen "quay lai foreground" nao de didChangeAppLifecycleState
    // bat duoc, nen can nghe truc tiep o day. Xem giai thich day du trong
    // JackpotCheckService.updateTick.
    JackpotCheckService.updateTick.addListener(_refreshAllTabs);
  }

  @override
  void dispose() {
    RootScreen.switchTabRequest.removeListener(_onSwitchTabRequest);
    WidgetsBinding.instance.removeObserver(this);
    JackpotCheckService.updateTick.removeListener(_refreshAllTabs);
    super.dispose();
  }

  /// Đọc lại dữ liệu (từ bộ nhớ máy, KHÔNG gọi mạng) cho cả 3 tab — dùng
  /// chung cho 2 trường hợp: (a) app vừa quay lại foreground, (b) có dữ
  /// liệu mới được ghi trong khi app đang mở sẵn (tin FCM tới lúc
  /// foreground). Cả 2 đều rẻ (chỉ đọc local), an toàn gọi thường xuyên.
  void _refreshAllTabs() {
    _homeKey.currentState?.refresh();
    _randomPickKey.currentState?.refreshNextDrawId();
    _statsKey.currentState?.refresh();
  }

  /// App vừa quay lại foreground (mở lại từ nền, KHÔNG phải khởi động
  /// lạnh — khởi động lạnh đã có `initState()` của từng tab lo). Bắt
  /// trường hợp: tin FCM đến lúc app đang ở NỀN, được xử lý bởi 1 isolate
  /// riêng (`firebaseMessagingBackgroundHandler`) ghi thẳng vào bộ nhớ
  /// máy — cây widget hiện tại vẫn đang sống y nguyên từ trước, không tự
  /// biết mà đọc lại.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refreshAllTabs();
  }

  void _onSwitchTabRequest() {
    final i = RootScreen.switchTabRequest.value;
    if (i < 0 || i >= _screens.length) return;
    setState(() => _index = i);
    _homeKey.currentState?.setVisible(i == 0);
    if (i == 1) _randomPickKey.currentState?.refreshNextDrawId();
    if (i == 2) _statsKey.currentState?.refresh();
    // Dat lai ve sentinel (-1) NGAY SAU khi da xu ly. Neu khong, lan bam
    // TIEP THEO vao dung nut do (vd "Xem so luong trung giai" 2 lan lien
    // tiep ma khong doi qua tab nao khac o giua) se gan CUNG 1 gia tri
    // nhu lan truoc -> ValueNotifier KHONG BAO GIO ban listener (no chi
    // ban khi gia tri thuc su thay doi) -> tab khong chuyen, giong het
    // nhu khong bam gi ca. Doi sang microtask (khong reset dong bo ngay
    // trong listener) de tranh goi lai notifyListeners() long nhau trong
    // luc dang duyet danh sach listener.
    Future.microtask(() => RootScreen.switchTabRequest.value = -1);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Banner cố định dưới màn hình, đứng trên NavigationBar — dùng
          // chung 1 instance cho mọi tab (RootScreen không đổi tab bằng
          // Navigator.push nên widget này không bị dispose/tạo lại liên
          // tục khi chuyển tab).
          const SafeArea(bottom: false, child: AdBannerWidget()),
          NavigationBar(
            selectedIndex: _index,
            height: 68,
            onDestinationSelected: (i) {
              setState(() => _index = i);
              _homeKey.currentState?.setVisible(i == 0);
              if (i == 1) {
                _randomPickKey.currentState?.refreshNextDrawId();
              }
              if (i == 2) {
                _statsKey.currentState?.refresh();
              }
            },
            backgroundColor: AppColors.cardIvory,
            indicatorColor: AppColors.gold.withOpacity(0.3),
            destinations: [
              NavigationDestination(
                icon: const Icon(Icons.emoji_events_outlined, size: 26),
                selectedIcon: Icon(Icons.emoji_events, color: AppColors.luckyRed, size: 28),
                label: t('Chia Giải', 'Jackpot'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.auto_awesome_outlined, size: 26),
                selectedIcon: Icon(Icons.auto_awesome, color: AppColors.luckyRed, size: 28),
                label: t('Sinh Số', 'Generate'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.bar_chart_outlined, size: 26),
                selectedIcon: Icon(Icons.bar_chart, color: AppColors.luckyRed, size: 28),
                label: t('Thống Kê', 'Stats'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
