import 'package:flutter/material.dart';

import '../services/app_language.dart';
import '../theme/app_theme.dart';
import '../widgets/ad_banner_widget.dart';
import 'home_screen.dart';
import 'random_pick_screen.dart';
import 'stats_screen.dart';

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  /// Cho phép các tab con (vd Home) tự chuyển sang tab khác — ví dụ nút
  /// "Xem số lượng trúng giải →" trên Home nhảy thẳng sang tab Thống Kê mà
  /// không cần Navigator.push (giữ nguyên IndexedStack, không mất state).
  static final ValueNotifier<int> switchTabRequest = ValueNotifier<int>(-1);

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int _index = 0;

  // GlobalKey de RootScreen chu dong goi refreshNextDrawId() moi khi
  // nguoi dung chuyen sang tab "Sinh So" -> bat kip lastDrawId ma tab
  // "Chia Giai" vua cao xong (IndexedStack khong tu goi lai initState khi
  // doi tab, xem giai thich trong random_pick_screen.dart).
  final _randomPickKey = GlobalKey<RandomPickScreenState>();

  // GlobalKey de tab "Thong Ke" tu tai lai (so luong trung giai ky nay,
  // lich su...) moi khi nguoi dung chuyen sang - cung ly do/co che nhu
  // _randomPickKey o tren (IndexedStack khong tu goi lai initState).
  final _statsKey = GlobalKey<StatsScreenState>();

  late final _screens = [
    const HomeScreen(),
    RandomPickScreen(key: _randomPickKey),
    StatsScreen(key: _statsKey),
  ];

  @override
  void initState() {
    super.initState();
    RootScreen.switchTabRequest.addListener(_onSwitchTabRequest);
  }

  @override
  void dispose() {
    RootScreen.switchTabRequest.removeListener(_onSwitchTabRequest);
    super.dispose();
  }

  void _onSwitchTabRequest() {
    final i = RootScreen.switchTabRequest.value;
    if (i < 0 || i >= _screens.length) return;
    setState(() => _index = i);
    if (i == 1) _randomPickKey.currentState?.refreshNextDrawId();
    if (i == 2) _statsKey.currentState?.refresh();
    // Dat lai ve sentinel (-1) NGAY SAU khi da xu ly. Neu khong, lan bam
    // TIEP THEO vao dung nut do (vd "Xem so luong trung giai" 2 lan lien
    // tiep ma khong doi qua tab nao khac o giua) se gan CUNG 1 gia tri
    // nhu lan truoc -> ValueNotifier KHONG BAO GIO ban listener (no chi
    // ban khi gia tri thuc su thay doi) -> tab khong chuyen, giong het
    // nhu khong bam gi ca. Doi sang microtask (khong reset dong bo ngay
    // trong listener) de tranh goi lai notifyListeners() long nhau trong
    // luc dang duyet danh sach listener.
    Future.microtask(() => RootScreen.switchTabRequest.value = -1);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Banner cố định dưới màn hình, đứng trên NavigationBar — dùng
          // chung 1 instance cho mọi tab (RootScreen không đổi tab bằng
          // Navigator.push nên widget này không bị dispose/tạo lại liên
          // tục khi chuyển tab).
          const SafeArea(bottom: false, child: AdBannerWidget()),
          NavigationBar(
            selectedIndex: _index,
            height: 68,
            onDestinationSelected: (i) {
              setState(() => _index = i);
              if (i == 1) {
                _randomPickKey.currentState?.refreshNextDrawId();
              }
              if (i == 2) {
                _statsKey.currentState?.refresh();
              }
            },
            backgroundColor: AppColors.cardIvory,
            indicatorColor: AppColors.gold.withOpacity(0.3),
            destinations: [
              NavigationDestination(
                icon: const Icon(Icons.emoji_events_outlined, size: 26),
                selectedIcon: Icon(Icons.emoji_events, color: AppColors.luckyRed, size: 28),
                label: t('Chia Giải', 'Jackpot'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.auto_awesome_outlined, size: 26),
                selectedIcon: Icon(Icons.auto_awesome, color: AppColors.luckyRed, size: 28),
                label: t('Sinh Số', 'Generate'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.bar_chart_outlined, size: 26),
                selectedIcon: Icon(Icons.bar_chart, color: AppColors.luckyRed, size: 28),
                label: t('Thống Kê', 'Stats'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
