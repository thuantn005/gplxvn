import 'package:flutter/material.dart';

import '../services/app_language.dart';
import '../theme/app_theme.dart';
import '../widgets/ad_banner_widget.dart';
import 'home_screen.dart';
import 'random_pick_screen.dart';
import 'stats_screen.dart';

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  /// Cho phép các tab con (vd Home) tự chuyển sang tab khác — ví dụ nút
  /// "Xem số lượng trúng giải →" trên Home nhảy thẳng sang tab Thống Kê mà
  /// không cần Navigator.push (giữ nguyên IndexedStack, không mất state).
  static final ValueNotifier<int> switchTabRequest = ValueNotifier<int>(-1);

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int _index = 0;

  // GlobalKey de RootScreen chu dong goi refreshNextDrawId() moi khi
  // nguoi dung chuyen sang tab "Sinh So" -> bat kip lastDrawId ma tab
  // "Chia Giai" vua cao xong (IndexedStack khong tu goi lai initState khi
  // doi tab, xem giai thich trong random_pick_screen.dart).
  final _randomPickKey = GlobalKey<RandomPickScreenState>();

  @override
  void initState() {
    super.initState();
    RootScreen.switchTabRequest.addListener(_onSwitchTabRequest);
  }

  @override
  void dispose() {
    RootScreen.switchTabRequest.removeListener(_onSwitchTabRequest);
    super.dispose();
  }

  void _onSwitchTabRequest() {
    final i = RootScreen.switchTabRequest.value;
    if (i < 0 || i >= _screens.length) return;
    setState(() => _index = i);
    if (i == 1) _randomPickKey.currentState?.refreshNextDrawId();
    // Dat lai ve sentinel (-1) NGAY SAU khi da xu ly. Neu khong, lan bam
    // TIEP THEO vao dung nut do (vd "Xem so luong trung giai" 2 lan lien
    // tiep ma khong doi qua tab nao khac o giua) se gan CUNG 1 gia tri
    // nhu lan truoc -> ValueNotifier KHONG BAO GIO ban listener (no chi
    // ban khi gia tri thuc su thay doi) -> tab khong chuyen, giong het
    // nhu khong bam gi ca. Doi sang microtask (khong reset dong bo ngay
    // trong listener) de tranh goi lai notifyListeners() long nhau trong
    // luc dang duyet danh sach listener.
    Future.microtask(() => RootScreen.switchTabRequest.value = -1);
  }

  @override
  Widget build(BuildContext context) {
    // QUAN TRONG: tao list nay MOI LAN build(), KHONG cache thanh field
    // (truoc day la "late final _screens" - chi tinh 1 lan roi dung mai).
    // Neu cache, IndexedStack se nhan lai DUNG CUNG 1 object nhu lan
    // truoc moi khi RootScreen build lai (vd luc doi ngon ngu/dark mode)
    // -> Flutter thay "widget y het lan truoc" (identical) -> TU DONG BO
    // QUA, khong ve lai tab do - day chinh la bug "doi ngon ngu tab Chia
    // Giai/Thong Ke khong doi" da gap. Tao instance MOI moi lan dam bao
    // Flutter luon dem lai build() cho tung tab con voi t()/AppColors moi.
    final screens = [
      HomeScreen(),
      RandomPickScreen(key: _randomPickKey),
      StatsScreen(),
    ];
    return Scaffold(
      body: IndexedStack(index: _index, children: screens),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Banner cố định dưới màn hình, đứng trên NavigationBar — dùng
          // chung 1 instance cho mọi tab (RootScreen không đổi tab bằng
          // Navigator.push nên widget này không bị dispose/tạo lại liên
          // tục khi chuyển tab).
          const SafeArea(bottom: false, child: AdBannerWidget()),
          NavigationBar(
            selectedIndex: _index,
            height: 68,
            onDestinationSelected: (i) {
              setState(() => _index = i);
              if (i == 1) {
                _randomPickKey.currentState?.refreshNextDrawId();
              }
            },
            backgroundColor: AppColors.cardIvory,
            indicatorColor: AppColors.gold.withOpacity(0.3),
            destinations: [
              NavigationDestination(
                icon: const Icon(Icons.emoji_events_outlined, size: 26),
                selectedIcon: Icon(Icons.emoji_events, color: AppColors.luckyRed, size: 28),
                label: t('Chia Giải', 'Jackpot'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.auto_awesome_outlined, size: 26),
                selectedIcon: Icon(Icons.auto_awesome, color: AppColors.luckyRed, size: 28),
                label: t('Sinh Số', 'Generate'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.bar_chart_outlined, size: 26),
                selectedIcon: Icon(Icons.bar_chart, color: AppColors.luckyRed, size: 28),
                label: t('Thống Kê', 'Stats'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
