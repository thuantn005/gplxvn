import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../models/draw.dart';
import '../services/app_language.dart';
import '../services/background_service.dart';
import '../services/jackpot_storage_service.dart';
import '../services/share_draw_machine.dart';
import '../theme/app_theme.dart';
import 'root_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final _storage = JackpotStorageService();
  bool _checking = false;

  String _lastDrawText = '—';
  String _lastStatus = '';
  String _lastSource = '—';
  int? _lastJackpot;
  ShareDrawState? _state;
  List<int> _mainNumbers = [];
  int? _specialNumber;
  String _drawIdLabel = '';
  String _drawDateLabel = '';
  String? _lastDrawDateIso; // "2026-09-01", de doi chieu voi ky vua qua
  String? _lastDrawTimeRaw; // "13:00" hoac "21:00"
  List<PrizeTier> _tiers = [];
  int _streak = 0;

  Timer? _countdownTimer;
  Duration _timeToNextDraw = Duration.zero;
  bool _waitingForResult = false; // da qua gio quay nhung chua co ket qua moi

  late final AnimationController _celebrateController = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );
  bool _celebratedThisLoad = false;

  @override
  void initState() {
    super.initState();
    _init();
    _updateCountdown();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) => _updateCountdown());
    _storage.bumpStreakOnOpen().then((s) {
      if (mounted) setState(() => _streak = s);
    });
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _celebrateController.dispose();
    super.dispose();
  }

  // ── Đếm ngược tới kỳ quay tiếp theo (13:00 / 21:00 mỗi ngày) ──────────

  void _updateCountdown() {
    final now = DateTime.now();
    final today13 = DateTime(now.year, now.month, now.day, 13, 0);
    final today21 = DateTime(now.year, now.month, now.day, 21, 0);
    DateTime next;
    DateTime justPassed;
    String justPassedTime;
    if (now.isBefore(today13)) {
      next = today13;
      justPassed = today13.subtract(const Duration(hours: 16)); // 21:00 hôm trước
      justPassedTime = '21:00';
    } else if (now.isBefore(today21)) {
      next = today21;
      justPassed = today13;
      justPassedTime = '13:00';
    } else {
      next = today13.add(const Duration(days: 1));
      justPassed = today21;
      justPassedTime = '21:00';
    }

    // Da co ket qua cho DUNG ky vua qua chua? So ca ngay LAN gio, vi
    // 2 ky/ngay co CUNG ngay nhung KHAC gio - chi so ngay thi khong phan
    // biet duoc "da co ky 13:00" hay "van dang cho ky 21:00".
    final justPassedDateIso =
        '${justPassed.year.toString().padLeft(4, '0')}-${justPassed.month.toString().padLeft(2, '0')}-${justPassed.day.toString().padLeft(2, '0')}';
    final haveResult = _lastDrawDateIso == justPassedDateIso && _lastDrawTimeRaw == justPassedTime;

    final remaining = next.difference(now);
    if (!mounted) return;
    setState(() {
      _timeToNextDraw = remaining.isNegative ? Duration.zero : remaining;
      // Da qua gio quay (dong ho da toi/vuot moc) MA CHUA co ket qua moi
      // -> hien "dang cap nhat ket qua" thay vi lap tuc dem sang ky KE
      // TIEP - tranh gay cam giac sai la da co ket qua trong khi thuc te
      // van dang cho GitHub Actions cao xong + gui FCM.
      _waitingForResult = remaining <= Duration.zero && !haveResult;
    });
  }

  String _fmtCountdown(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  /// "2026-08-30" -> "30/08/2026". Trả về rỗng nếu không đúng định dạng.
  String _fmtDrawDate(String? isoDate) {
    if (isoDate == null || isoDate.isEmpty) return '';
    final parts = isoDate.split('-');
    if (parts.length != 3) return '';
    return '${parts[2]}/${parts[1]}/${parts[0]}';
  }

  Future<void> _init() async {
    await _load();
    // Cai moi / chua bao gio kiem tra thanh cong -> tu dong kiem tra ngay
    // lan dau, khong bat nguoi dung phai biet la can bam nut "Kiem tra
    // ngay" thi moi co du lieu.
    if (!mounted) return;
    if (_drawIdLabel.isEmpty) {
      await _checkNow();
    }
  }

  Future<void> _load() async {
    final drawText = await _storage.lastDrawText;
    final status = await _storage.lastStatus;
    final source = await _storage.lastSource;
    final jackpot = await _storage.lastJackpot;
    final state = await _storage.loadState();
    final tiers = await _storage.prizeTiers;
    final drawId = await _storage.lastDrawId;
    final drawDate = await _storage.lastDrawDate;
    final drawTime = await _storage.lastDrawTime;

    // "lastDrawText" luu dang "#00852 — 11 17 28 29 34 + ĐB 09", tach so ra
    // de ve bi tron rieng thay vi hien nguyen chuoi text.
    final numbers = <int>[];
    int? special;
    final match = RegExp(r'((?:\d{2}\s+){4}\d{2})\s*\+\s*ĐB\s*(\d{2})').firstMatch(drawText);
    if (match != null) {
      numbers.addAll(match.group(1)!.trim().split(RegExp(r'\s+')).map(int.parse));
      special = int.tryParse(match.group(2)!);
    }

    if (!mounted) return;
    setState(() {
      _lastDrawText = drawText;
      _lastStatus = status.isEmpty || status == 'Chưa kiểm tra lần nào'
          ? t('Chưa kiểm tra lần nào', 'Not checked yet')
          : status;
      _lastSource = source;
      _lastJackpot = jackpot;
      _state = state;
      _tiers = tiers;
      _mainNumbers = numbers;
      _specialNumber = special;
      _drawIdLabel = drawId != null ? '#$drawId' : '';
      _drawDateLabel = _fmtDrawDate(drawDate);
      _lastDrawDateIso = drawDate;
      _lastDrawTimeRaw = drawTime;
    });
    // Vua nap du lieu moi -> tinh lai xem con "dang cho ket qua" hay
    // khong (co the vua het lai vi drawDate/drawTime moi doc duoc o tren).
    _updateCountdown();

    // Hiệu ứng/âm thanh nhẹ khi mở app ĐÚNG LÚC đã xác định kỳ CHIA GIẢI —
    // chỉ chạy 1 lần cho mỗi lần mở màn hình này (không lặp lại mỗi khi
    // _load() được gọi lại do kéo-refresh), việc thông báo lặp lại đã có
    // NotificationService lo, ở đây chỉ là điểm nhấn trải nghiệm trong app.
    if ((state.pending) && !_celebratedThisLoad) {
      _celebratedThisLoad = true;
      _celebrateController.forward(from: 0);
      unawaited(SystemSound.play(SystemSoundType.click));
    }
  }

  Future<void> _checkNow() async {
    setState(() => _checking = true);
    try {
      await JackpotBackgroundService.checkNow();
    } catch (_) {
      // trang thai loi da duoc luu, se hien qua _lastStatus sau khi _load()
    }
    await _load();
    if (mounted) setState(() => _checking = false);
  }

  @override
  Widget build(BuildContext context) {
    final state = _state;
    final pending = state?.pending ?? false;

    return Scaffold(
      appBar: AppBar(
        title: Text(t('Săn Chia Giải 535', 'Jackpot Share Hunter 535')),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings, size: 26),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
              _load();
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _checkNow,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildCountdownCard(),
            const SizedBox(height: 14),
            _buildResultCard(),
            const SizedBox(height: 14),
            if (pending) ...[
              ScaleTransition(
                scale: CurvedAnimation(parent: _celebrateController, curve: Curves.elasticOut),
                child: _buildPendingCard(state!),
              ),
              const SizedBox(height: 14),
            ] else if (_lastJackpot != null) ...[
              _buildThresholdGapCard(_lastJackpot!),
              const SizedBox(height: 14),
            ],
            if (_tiers.isNotEmpty) ...[
              _buildPrizeTableLink(),
              const SizedBox(height: 14),
            ],
            _buildStatusFooter(),
            const SizedBox(height: 20),
            Center(
              child: ElevatedButton.icon(
                onPressed: _checking ? null : _checkNow,
                icon: _checking
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2.2, color: Colors.white),
                      )
                    : const Icon(Icons.refresh, size: 22),
                label: Text(t(
                  _checking ? 'Đang kiểm tra...' : 'Kiểm tra ngay',
                  _checking ? 'Checking...' : 'Check now',
                )),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.luckyRed,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 14),
                  textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                ),
              ),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Widget _buildThresholdGapCard(int jackpotVnd) {
    final gap = ShareDrawMachine.thresholdVnd - jackpotVnd;
    if (gap <= 0) return const SizedBox.shrink();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.luckyRed.withOpacity(0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.luckyRed.withOpacity(0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            t(
              'Chưa có kỳ chia giải — còn thiếu ${_thousands(gap)} đ '
              '(~${(gap / 1e9).toStringAsFixed(1)} tỷ) để vượt mốc 12 tỷ',
              'No share draw yet — ${_thousands(gap)} VND '
              '(~${(gap / 1e9).toStringAsFixed(1)}B) short of the 12B mark',
            ),
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.luckyRed),
          ),
        ],
      ),
    );
  }

  // ── Card đếm ngược tới kỳ quay tiếp theo + streak ngày mở app ────────

  Widget _buildCountdownCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
      decoration: BoxDecoration(
        color: AppColors.gold.withOpacity(0.15),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.gold.withOpacity(0.5)),
      ),
      child: Row(
        children: [
          Icon(
            _waitingForResult ? Icons.sync : Icons.timer_outlined,
            color: AppColors.luckyRed,
            size: 18,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _waitingForResult
                      ? t('Đang cập nhật kết quả', 'Updating result')
                      : t('Kỳ quay tiếp theo', 'Next draw'),
                  style: TextStyle(fontSize: 11.5, color: AppColors.muted),
                ),
                if (!_waitingForResult)
                  Text(
                    _fmtCountdown(_timeToNextDraw),
                    style: GoogleFonts.baloo2(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: AppColors.luckyRed,
                    ),
                  ),
              ],
            ),
          ),
          if (_streak >= 2)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: AppColors.luckyRed.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                '🔥 $_streak ${t('ngày', 'days')}',
                style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppColors.luckyRed),
              ),
            ),
        ],
      ),
    );
  }

  // ── Card kết quả kỳ mới nhất: kỳ/ngày + dãy bi tròn + pill Độc Đắc ──────

  Widget _buildResultCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.cardIvory,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.gold.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Vietlott · Lotto 5/35',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: AppColors.muted.withOpacity(0.8),
              letterSpacing: 0.3,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            _drawDateLabel.isEmpty
                ? '${t('KỲ QUAY THƯỞNG', 'DRAW')} $_drawIdLabel'
                : '${t('KỲ QUAY THƯỞNG', 'DRAW')} $_drawIdLabel · ${t('ngày', '')} $_drawDateLabel'
                        '${_lastDrawTimeRaw == null || _lastDrawTimeRaw!.isEmpty ? '' : ' - ${_lastDrawTimeRaw!}'}'
                    .trim(),
            style: GoogleFonts.baloo2(
              fontSize: 13.5,
              fontWeight: FontWeight.w700,
              color: AppColors.muted,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            _lastDrawText,
            style: TextStyle(fontSize: 12.5, color: AppColors.muted),
          ),
          const SizedBox(height: 14),
          if (_mainNumbers.length == 5 && _specialNumber != null)
            _buildBallRow()
          else
            Text(_lastDrawText, style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w600)),
          const SizedBox(height: 16),
          _buildJackpotPill(),
        ],
      ),
    );
  }

  Widget _buildBallRow() {
    // Ép về ĐÚNG 1 HÀNG (Row, không dùng Wrap) — bo nhỏ kích cỡ bi lại để
    // vừa màn hình, và bọc FittedBox làm lưới an toàn cho máy màn hình rất
    // hẹp thay vì để nó tự xuống dòng.
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 450),
      transitionBuilder: (child, anim) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.elasticOut),
        child: FadeTransition(opacity: anim, child: child),
      ),
      child: FittedBox(
        key: ValueKey(_drawIdLabel),
        fit: BoxFit.scaleDown,
        alignment: Alignment.centerLeft,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (final n in _mainNumbers) ...[
              _ball(n, AppColors.jade),
              const SizedBox(width: 6),
            ],
            Container(
              width: 2,
              height: 34,
              margin: const EdgeInsets.symmetric(horizontal: 4),
              color: AppColors.muted.withOpacity(0.3),
            ),
            const SizedBox(width: 6),
            _ball(_specialNumber!, AppColors.gold),
          ],
        ),
      ),
    );
  }

  Widget _ball(int n, Color color) {
    return Container(
      width: 40,
      height: 40,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color.withOpacity(0.85), color],
          center: const Alignment(-0.3, -0.3),
        ),
        boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 6, offset: const Offset(0, 2))],
      ),
      child: Text(
        n.toString().padLeft(2, '0'),
        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15),
      ),
    );
  }

  Widget _buildJackpotPill() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(t('Giá trị giải Độc Đắc', 'Jackpot value'),
            style: TextStyle(fontSize: 13.5, color: AppColors.muted, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 16),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: AppColors.luckyRed,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(color: AppColors.luckyRed.withOpacity(0.35), blurRadius: 12, offset: const Offset(0, 4)),
            ],
          ),
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            transitionBuilder: (child, anim) =>
                FadeTransition(opacity: anim, child: ScaleTransition(scale: anim, child: child)),
            child: Text(
              _lastJackpot != null ? _thousands(_lastJackpot!) : ShareDrawMachine.fmt(_lastJackpot),
              key: ValueKey(_lastJackpot),
              style: GoogleFonts.baloo2(fontSize: 27, fontWeight: FontWeight.w800, color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }

  // ── Link sang bảng 7 bậc giải (đã chuyển hẳn sang tab Thống Kê) ──────

  static String _thousands(int v) {
    final s = v.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  Widget _buildPrizeTableLink() {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => RootScreen.switchTabRequest.value = 2,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 16),
        decoration: BoxDecoration(
          color: AppColors.cardIvory,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.gold.withOpacity(0.4)),
        ),
        child: Row(
          children: [
            Icon(Icons.emoji_events_outlined, size: 20, color: AppColors.luckyRed),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                t('Xem số lượng trúng giải kỳ này', 'See winners for this draw'),
                style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: AppColors.ink),
              ),
            ),
            Icon(Icons.chevron_right, size: 20, color: AppColors.muted),
          ],
        ),
      ),
    );
  }

  // ── Card "đã xác định kỳ chia giải" + footer trạng thái ─────────────

  Widget _buildPendingCard(ShareDrawState state) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.gold.withOpacity(0.15),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.gold),
      ),
      child: Row(
        children: [
          Icon(Icons.celebration, color: AppColors.luckyRed, size: 36),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  t('Đã xác định kỳ CHIA GIẢI', 'SHARE DRAW confirmed'),
                  style: GoogleFonts.baloo2(fontWeight: FontWeight.w700, fontSize: 14.5),
                ),
                const SizedBox(height: 2),
                Text(
                  t(
                    'Kỳ quay 21:00 ngày ${state.shareDate ?? "?"}',
                    '21:00 draw on ${state.shareDate ?? "?"}',
                  ),
                  style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600),
                ),
                Text(
                  t(
                    'Đỉnh Độc Đắc trước chia: ${ShareDrawMachine.fmt(state.peakJackpot)}',
                    'Peak jackpot before draw: ${ShareDrawMachine.fmt(state.peakJackpot)}',
                  ),
                  style: TextStyle(fontSize: 12, color: AppColors.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusFooter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(_lastStatus, style: TextStyle(fontSize: 12, color: AppColors.muted)),
        const SizedBox(height: 4),
        Text(
          t(
            'Dữ liệu tổng hợp từ các trang xổ số công khai, không đại diện/liên kết với Vietlott.',
            'Data aggregated from public lottery result sites. Not affiliated with Vietlott.',
          ),
          style: TextStyle(fontSize: 10, color: AppColors.muted.withOpacity(0.75)),
        ),
      ],
    );
  }
}
