import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import '../models/draw.dart';
import '../services/ads_service.dart';
import '../services/app_language.dart';
import '../services/draw_history_source.dart';
import '../services/error_text.dart';
import '../services/github_seed_source.dart';
import '../services/jackpot_storage_service.dart';
import '../services/ticket_formula.dart';
import '../theme/app_theme.dart';

class SeedTicket {
  final int seed;
  final List<int> numbers;
  final int special;
  SeedTicket({required this.seed, required this.numbers, required this.special});

  String pretty() {
    final main = numbers.map((n) => n.toString().padLeft(2, '0')).join(' ');
    return '$main + ĐB ${special.toString().padLeft(2, '0')}';
  }
}

/// Kết quả so sánh 1 vé lịch sử với kết quả thật (nếu kỳ đó đã quay).
class _Compared {
  final TicketHistoryEntry ticket;
  final Draw? actual; // null = kỳ chưa quay / chưa có dữ liệu
  final int mainHits;
  final bool specialHit;

  _Compared({required this.ticket, this.actual, this.mainHits = 0, this.specialHit = false});

  /// Tên bậc giải khớp với luật thật của Lotto 5/35 (giống bảng 7 bậc giải
  /// ở tab Chia Giải) — chỉ mang tính tham khảo/mô tả, KHÔNG phải dự đoán.
  /// (nhãn Việt, nhãn Anh) hoặc null nếu không trúng giải nào.
  (String, String)? get prizeLabel {
    if (actual == null) return null;
    if (mainHits == 5 && specialHit) return ('Giải Độc Đắc 🎉', 'Jackpot 🎉');
    if (mainHits == 5) return ('Giải Nhất', '1st Prize');
    if (mainHits == 4 && specialHit) return ('Giải Nhì', '2nd Prize');
    if (mainHits == 4) return ('Giải Ba', '3rd Prize');
    if (mainHits == 3 && specialHit) return ('Giải Tư', '4th Prize');
    if (mainHits == 3) return ('Giải Năm', '5th Prize');
    if (specialHit) return ('Giải Khuyến Khích', 'Consolation Prize');
    return null; // khong trung giai nao
  }
}

/// Sinh vé bằng công thức (`TicketFormula`) áp lên các SEED ĐANG CÓ SẴN
/// trong danh sách đang theo dõi — không gõ tay, không tự bịa seed mới.
/// App CHỌN NGẪU NHIÊN trong danh sách đó (không ưu tiên seed nào), rồi
/// tính vé cho KỲ TIẾP THEO (kỳ chưa xảy ra).
///
/// Có 2 tab: "Tạo Vé" (sinh vé mới) và "Lịch Sử" (toàn bộ vé đã sinh trước
/// đây, tự động so với kết quả thật khi kỳ đó đã quay xong — thuần thống kê
/// mô tả, không phải dự đoán hay gợi ý số "may mắn hơn").
class RandomPickScreen extends StatefulWidget {
  const RandomPickScreen({super.key});

  @override
  State<RandomPickScreen> createState() => RandomPickScreenState();
}

/// Public (không phải `_RandomPickScreenState`) vì `RootScreen` cần cầm
/// `GlobalKey<RandomPickScreenState>` để chủ động gọi [refreshNextDrawId]
/// mỗi khi người dùng chuyển sang tab này — do `IndexedStack` chỉ gọi
/// `initState()` đúng 1 lần lúc mở app, không tự đọc lại `lastDrawId` sau
/// khi tab "Chia Giải" cào xong dữ liệu.
class RandomPickScreenState extends State<RandomPickScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  final _rng = Random.secure();
  final _storage = JackpotStorageService();

  List<int> _seedPool = [];
  final List<SeedTicket> _tickets = [];
  int _lineCount = 1;
  int? _nextDrawId;

  bool _loadingPool = true;
  String? _poolError;

  // ── Lịch sử + so sánh kết quả ───────────────────────────────────────
  bool _historyLoading = true;
  bool _comparing = false;
  String? _historyError;
  List<TicketHistoryEntry> _historyRaw = [];
  final Map<String, Draw> _actualResults = {}; // drawId -> ket qua that

  // ── Quảng cáo có thưởng cho nút "Xem quảng cáo để nhận số" ───────────
  RewardedAd? _rewardedAd;
  int _rewardedLoadAttempts = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadPool();
    _loadNextDrawId();
    _loadHistory();
    _loadRewardedAd();
  }

  // Tải sẵn quảng cáo TRƯỚC khi người dùng bấm nút, để lúc bấm hiện lên
  // ngay không phải chờ — nếu lỗi thì thử lại tối đa vài lần rồi thôi (khi
  // đó nút vẫn hoạt động bình thường, chỉ là sinh số miễn phí luôn, không
  // chặn tính năng chính của app vì lỗi quảng cáo).
  void _loadRewardedAd() {
    RewardedAd.load(
      adUnitId: AdsService.rewardedAdUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          if (!mounted) {
            ad.dispose();
            return;
          }
          setState(() {
            _rewardedAd = ad;
            _rewardedLoadAttempts = 0;
          });
        },
        onAdFailedToLoad: (error) {
          _rewardedAd = null;
          _rewardedLoadAttempts++;
          if (_rewardedLoadAttempts < AdsService.maxLoadAttempts) _loadRewardedAd();
        },
      ),
    );
  }

  /// Bấm nút "Xem quảng cáo để nhận số": có quảng cáo thì hiện lên, sinh số
  /// khi xem xong (onUserEarnedReward); KHÔNG có quảng cáo (lỗi mạng, chưa
  /// tải kịp...) thì vẫn sinh số bình thường luôn — không khoá tính năng
  /// chính của app chỉ vì quảng cáo trục trặc.
  void _generateWithRewardGate() {
    final ad = _rewardedAd;
    if (ad == null) {
      _generate();
      return;
    }
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        setState(() => _rewardedAd = null);
        _loadRewardedAd();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        setState(() => _rewardedAd = null);
        _loadRewardedAd();
        _generate();
      },
    );
    ad.show(onUserEarnedReward: (ad, reward) => _generate());
  }

  @override
  void dispose() {
    _tabController.dispose();
    _rewardedAd?.dispose();
    super.dispose();
  }

  Future<void> _loadNextDrawId() async {
    final lastId = await _storage.lastDrawId;
    if (!mounted) return;
    setState(() {
      _nextDrawId = lastId != null ? int.tryParse(lastId)! + 1 : null;
    });
  }

  /// Đọc lại `lastDrawId` từ bộ nhớ. Gọi công khai từ `RootScreen` mỗi khi
  /// người dùng chuyển sang tab này, để bắt kịp dữ liệu tab "Chia Giải" vừa
  /// cào xong (xem giải thích ở comment class phía trên).
  Future<void> refreshNextDrawId() => _loadNextDrawId();

  Future<void> _loadPool({bool forceRefresh = false}) async {
    setState(() {
      _loadingPool = true;
      _poolError = null;
    });
    try {
      final seeds = await GithubSeedSource.fetchSeeds(forceRefresh: forceRefresh);
      if (!mounted) return;
      setState(() {
        _seedPool = seeds;
        _loadingPool = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _poolError = t(friendlyError(e), friendlyErrorEn(e));
        _loadingPool = false;
      });
    }
  }

  void _generate() {
    if (_seedPool.isEmpty || _nextDrawId == null) return;
    final drawId = _nextDrawId!;
    final picked = <int>{};
    final tickets = <SeedTicket>[];
    // Chon ngau nhien N seed KHONG TRUNG tu danh sach dang co, ap dung cong
    // thuc cho kỳ tiếp theo.
    var guard = 0;
    while (tickets.length < _lineCount && guard < _lineCount * 50) {
      guard++;
      final seed = _seedPool[_rng.nextInt(_seedPool.length)];
      if (picked.contains(seed)) continue;
      picked.add(seed);
      final (numbers, special) = TicketFormula.generate(seed, drawId);
      tickets.add(SeedTicket(seed: seed, numbers: numbers, special: special));
    }
    setState(() {
      _tickets
        ..clear()
        ..addAll(tickets);
    });

    // Lưu lại để so sánh với kết quả thật khi kỳ này quay xong.
    final now = DateTime.now().toIso8601String();
    _storage.pushTickets([
      for (final ticket in tickets)
        TicketHistoryEntry(
          seed: ticket.seed,
          drawId: drawId.toString().padLeft(5, '0'),
          numbers: ticket.numbers,
          special: ticket.special,
          generatedAtIso: now,
        ),
    ]).then((_) => _loadHistory());
  }

  void _copyAll() {
    if (_tickets.isEmpty) return;
    final text = _tickets
        .asMap()
        .entries
        .map((e) => '${t('Vé', 'Ticket')} ${e.key + 1} (seed ${e.value.seed}): ${e.value.pretty()}')
        .join('\n');
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(t('Đã sao chép vào bộ nhớ tạm', 'Copied to clipboard'))),
    );
  }

  // ── Lịch sử + so sánh ───────────────────────────────────────────────

  Future<void> _loadHistory({bool forceCompare = false}) async {
    setState(() => _historyLoading = true);
    final list = await _storage.ticketHistory();
    if (!mounted) return;
    setState(() {
      _historyRaw = list.reversed.toList(); // moi sinh gan day nhat len dau
      _historyLoading = false;
    });
    await _compareWithResults(force: forceCompare);
  }

  Future<void> _compareWithResults({bool force = false}) async {
    final needIds = _historyRaw.map((tk) => tk.drawId).toSet();
    if (!force) needIds.removeWhere(_actualResults.containsKey);
    if (needIds.isEmpty) return;
    setState(() {
      _comparing = true;
      _historyError = null;
    });
    try {
      final results = await DrawHistorySource.fetchResultsFor(needIds);
      if (!mounted) return;
      setState(() => _actualResults.addAll(results));
    } catch (e) {
      if (!mounted) return;
      setState(() => _historyError =
          '${t('Không tải được kết quả để so sánh', "Couldn't load results to compare")}: '
          '${t(friendlyError(e), friendlyErrorEn(e))}');
    } finally {
      if (mounted) setState(() => _comparing = false);
    }
  }

  List<_Compared> get _comparedHistory {
    return _historyRaw.map((tk) {
      final actual = _actualResults[tk.drawId];
      if (actual == null) return _Compared(ticket: tk);
      final hits = tk.numbers.toSet().intersection(actual.numbers.toSet()).length;
      final spHit = actual.special != null && tk.special == actual.special;
      return _Compared(ticket: tk, actual: actual, mainHits: hits, specialHit: spHit);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(t('Sinh Số Từ Seed', 'Generate From Seed')),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: [
            Tab(icon: const Icon(Icons.auto_awesome, size: 24), text: t('Tạo Vé', 'Generate')),
            Tab(icon: const Icon(Icons.fact_check_outlined, size: 24), text: t('Lịch Sử', 'History')),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, size: 26),
            tooltip: t('Tải lại danh sách seed', 'Reload seed list'),
            onPressed: () => _loadPool(forceRefresh: true),
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildGenerateTab(),
          _buildHistoryTab(),
        ],
      ),
    );
  }

  // ── Tab 1: Tạo Vé ─────────────────────────────────────────────────

  Widget _buildGenerateTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.ink.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.ink.withOpacity(0.2)),
          ),
          child: Text(
            t(
              'Ứng dụng này không cung cấp dịch vụ mua vé số, cá cược hay giao '
              'dịch tiền thật, mà hoạt động như một công cụ tính toán và quản '
              'lý dữ liệu cá nhân chuyên nghiệp.',
              'This app does not provide lottery ticket purchase, betting, or '
              'real-money transaction services — it works purely as a personal '
              'calculation and data-management tool.',
            ),
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.ink),
          ),
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.gold.withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.gold.withOpacity(0.5)),
          ),
          child: Row(
            children: [
              Icon(Icons.info_outline, size: 20, color: AppColors.luckyRed),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  t(
                    'Vé được sinh bằng công thức toán áp lên seed ngẫu nhiên.',
                    'Tickets are generated by a formula applied to a random seed.',
                  ),
                  style: TextStyle(fontSize: 12, color: AppColors.ink),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        _buildPoolStatus(),
        const SizedBox(height: 14),
        Row(
          children: [
            Text(t('Số vé:', 'Lines:'), style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            const SizedBox(width: 12),
            Expanded(
              child: Slider(
                value: _lineCount.toDouble(),
                min: 1,
                max: 5,
                divisions: 4,
                activeColor: AppColors.luckyRed,
                label: '$_lineCount',
                onChanged: (v) => setState(() => _lineCount = v.round()),
              ),
            ),
            SizedBox(
              width: 26,
              child: Text('$_lineCount', textAlign: TextAlign.right, style: const TextStyle(fontSize: 15)),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Center(
          child: ElevatedButton.icon(
            onPressed: (_seedPool.isEmpty || _nextDrawId == null) ? null : _generateWithRewardGate,
            icon: Icon(_rewardedAd != null ? Icons.play_circle_fill : Icons.auto_awesome, size: 22),
            label: Text(_rewardedAd != null
                ? t('Xem quảng cáo để nhận số', 'Watch ad to reveal')
                : t('Sinh Số', 'Generate')),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.luckyRed,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 34, vertical: 17),
              textStyle: GoogleFonts.baloo2(fontSize: 17, fontWeight: FontWeight.w700),
            ),
          ),
        ),
        if (_tickets.isNotEmpty) ...[
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                t(
                  'Kết quả (${_tickets.length} vé) — kỳ #${_nextDrawId ?? "?"}',
                  'Result (${_tickets.length} tickets) — draw #${_nextDrawId ?? "?"}',
                ),
                style: GoogleFonts.baloo2(fontWeight: FontWeight.w700, fontSize: 14.5),
              ),
              TextButton.icon(
                onPressed: _copyAll,
                icon: const Icon(Icons.copy, size: 17),
                label: Text(t('Sao chép', 'Copy')),
              ),
            ],
          ),
          const SizedBox(height: 8),
          for (int i = 0; i < _tickets.length; i++) _ticketCard(i, _tickets[i]),
        ],
      ],
    );
  }

  Widget _buildPoolStatus() {
    if (_loadingPool) {
      return Row(
        children: [
          const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
          const SizedBox(width: 8),
          Text(t('Đang tải danh sách seed...', 'Loading seed list...'), style: const TextStyle(fontSize: 12)),
        ],
      );
    }
    if (_poolError != null) {
      return Row(
        children: [
          Icon(Icons.error_outline, size: 16, color: AppColors.luckyRed),
          const SizedBox(width: 6),
          Expanded(
            child: Text('${t('Lỗi tải seed', 'Failed to load seeds')}: $_poolError',
                style: TextStyle(fontSize: 11.5, color: AppColors.luckyRed)),
          ),
        ],
      );
    }
    return Text(
      t(
        'Đang có ${_seedPool.length} seed'
        '${_nextDrawId != null ? " · sinh vé cho kỳ #$_nextDrawId" : " · chưa rõ kỳ tiếp theo (mở tab Chia Giải để cập nhật)"}',
        '${_seedPool.length} seeds available'
        '${_nextDrawId != null ? " · generating for draw #$_nextDrawId" : " · next draw unknown (open the Jackpot tab to update)"}',
      ),
      style: TextStyle(fontSize: 12, color: AppColors.muted),
    );
  }

  Widget _ticketCard(int index, SeedTicket ticket) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: AppColors.cardIvory,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.gold.withOpacity(0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: AppColors.luckyRed, shape: BoxShape.circle),
                child: Text('${index + 1}',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Wrap(
                  spacing: 7,
                  runSpacing: 7,
                  children: [
                    for (final n in ticket.numbers) _ball(n, AppColors.jade),
                    _ball(ticket.special, AppColors.gold),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text('seed: ${ticket.seed}', style: TextStyle(fontSize: 10.5, color: AppColors.muted)),
        ],
      ),
    );
  }

  // ── Tab 2: Lịch Sử ────────────────────────────────────────────────

  Widget _buildHistoryTab() {
    if (_historyLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_historyRaw.isEmpty) {
      return _buildHistoryEmptyState();
    }

    final compared = _comparedHistory;
    final withActual = compared.where((c) => c.actual != null).toList();
    final wins = withActual.where((c) => c.prizeLabel != null).toList();

    return RefreshIndicator(
      onRefresh: () => _loadHistory(forceCompare: true),
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_comparing) ...[
            Row(
              children: [
                const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
                const SizedBox(width: 8),
                Text(t('Đang so với kết quả thật...', 'Comparing with real results...'),
                    style: const TextStyle(fontSize: 12)),
              ],
            ),
            const SizedBox(height: 10),
          ],
          if (_historyError != null) ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.luckyRed.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Icon(Icons.error_outline, size: 16, color: AppColors.luckyRed),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(_historyError!,
                        style: TextStyle(fontSize: 11.5, color: AppColors.luckyRed)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
          ],
          _historySummaryCard(
            total: compared.length,
            withResult: withActual.length,
            wins: wins.length,
          ),
          const SizedBox(height: 16),
          for (final c in compared) _historyCard(c),
          const SizedBox(height: 8),
          Text(
            t(
              'So sánh dựa trên kết quả THẬT đã công bố. Đây là thống kê mô tả — '
              'số vé đã sinh không ảnh hưởng đến khả năng trúng của các kỳ sau.',
              'Comparison is based on published REAL results. This is purely '
              "descriptive statistics — the number of tickets generated doesn't "
              'affect the odds of future draws.',
            ),
            style: TextStyle(fontSize: 10.5, color: AppColors.muted, fontStyle: FontStyle.italic),
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryEmptyState() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 60, horizontal: 24),
      child: Column(
        children: [
          Icon(Icons.fact_check_outlined, size: 52, color: AppColors.muted.withOpacity(0.4)),
          const SizedBox(height: 12),
          Text(
            t(
              'Chưa có vé nào trong lịch sử.\nSang tab "Tạo Vé" bấm "Sinh Số" để bắt đầu.',
              'No tickets in history yet.\nGo to the "Generate" tab and tap "Generate" to start.',
            ),
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13.5, color: AppColors.muted),
          ),
        ],
      ),
    );
  }

  Widget _historySummaryCard({required int total, required int withResult, required int wins}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.luckyRed, Color(0xFF7A1414)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(color: AppColors.luckyRed.withOpacity(0.25), blurRadius: 14, offset: const Offset(0, 6)),
        ],
      ),
      child: Row(
        children: [
          _summaryStat('$total', t('Vé đã sinh', 'Generated')),
          _summaryDivider(),
          _summaryStat('$withResult', t('Đã có kết quả', 'Have results')),
          _summaryDivider(),
          _summaryStat('$wins', t('Trúng giải', 'Won'), highlight: wins > 0),
        ],
      ),
    );
  }

  Widget _summaryDivider() => Container(width: 1, height: 36, color: Colors.white24);

  Widget _summaryStat(String value, String label, {bool highlight = false}) {
    return Expanded(
      child: Column(
        children: [
          Text(value,
              style: GoogleFonts.baloo2(
                fontSize: 23,
                fontWeight: FontWeight.w800,
                color: highlight ? AppColors.gold : Colors.white,
              )),
          const SizedBox(height: 2),
          Text(label,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 11, color: Colors.white70)),
        ],
      ),
    );
  }

  Widget _historyCard(_Compared c) {
    final ticket = c.ticket;
    final actual = c.actual;
    final win = c.prizeLabel;
    final dt = DateTime.tryParse(ticket.generatedAtIso);
    final dateStr = dt != null
        ? '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}'
        : '';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardIvory,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: win != null ? AppColors.gold : AppColors.gold.withOpacity(0.3),
          width: win != null ? 1.6 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: (win != null ? AppColors.gold : Colors.black).withOpacity(win != null ? 0.18 : 0.04),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('${t('Kỳ', 'Draw')} #${ticket.drawId}',
                  style: GoogleFonts.baloo2(fontWeight: FontWeight.w700, fontSize: 14)),
              _statusChip(c),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            '${t('Sinh lúc', 'Generated at')} $dateStr · seed ${ticket.seed}',
            style: TextStyle(fontSize: 10.5, color: AppColors.muted),
          ),
          const SizedBox(height: 10),
          Text(t('Vé', 'Ticket'), style: TextStyle(fontSize: 11, color: AppColors.muted)),
          const SizedBox(height: 4),
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: [
              for (final n in ticket.numbers)
                _ball(n, AppColors.jade, hit: actual?.numbers.contains(n) ?? false),
              _ball(ticket.special, AppColors.gold, hit: c.specialHit),
            ],
          ),
          if (actual != null) ...[
            const SizedBox(height: 10),
            Text(t('Kết quả', 'Result'), style: TextStyle(fontSize: 11, color: AppColors.muted)),
            const SizedBox(height: 4),
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: [
                for (final n in actual.numbers) _ball(n, AppColors.luckyRed, hit: ticket.numbers.contains(n)),
                if (actual.special != null) _ball(actual.special!, AppColors.ink, hit: c.specialHit),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              win != null
                  ? t(
                      '🎯 Trùng ${c.mainHits}/5 số${c.specialHit ? " + ĐB" : ""} — ${win.$1}',
                      '🎯 Matched ${c.mainHits}/5 numbers${c.specialHit ? " + special" : ""} — ${win.$2}',
                    )
                  : t(
                      'Trùng ${c.mainHits}/5 số${c.specialHit ? " + ĐB" : ""} — chưa đủ trúng giải',
                      'Matched ${c.mainHits}/5 numbers${c.specialHit ? " + special" : ""} — not enough to win',
                    ),
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
                color: win != null ? AppColors.luckyRed : AppColors.muted,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _statusChip(_Compared c) {
    if (c.actual == null) {
      return _chip(t('Chưa quay', 'Not drawn'), AppColors.muted, Icons.schedule);
    }
    if (c.prizeLabel != null) {
      return _chip(t(c.prizeLabel!.$1, c.prizeLabel!.$2), AppColors.gold, Icons.emoji_events, filled: true);
    }
    return _chip(t('Không trúng', 'No win'), AppColors.muted, Icons.remove_circle_outline);
  }

  Widget _chip(String label, Color color, IconData icon, {bool filled = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: filled ? color : color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: filled ? Colors.white : color),
          const SizedBox(width: 4),
          Text(label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: filled ? Colors.white : color,
              )),
        ],
      ),
    );
  }

  Widget _ball(int n, Color color, {bool hit = false}) {
    return Container(
      width: 41,
      height: 41,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        border: hit ? Border.all(color: AppColors.gold, width: 2.5) : null,
        boxShadow: hit
            ? [BoxShadow(color: AppColors.gold.withOpacity(0.6), blurRadius: 6)]
            : null,
      ),
      child: Text(
        n.toString().padLeft(2, '0'),
        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14.5),
      ),
    );
  }
}
