import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../models/draw.dart';
import '../services/app_language.dart';
import '../services/draw_history_source.dart';
import '../services/error_text.dart';
import '../services/jackpot_storage_service.dart';
import '../services/share_draw_machine.dart';
import '../theme/app_theme.dart';
import '../widgets/ad_banner_widget.dart';
import '../widgets/prize_table.dart';

class StatsScreen extends StatefulWidget {
  const StatsScreen({super.key});

  @override
  State<StatsScreen> createState() => _StatsScreenState();
}

class _StatsScreenState extends State<StatsScreen> {
  final _storage = JackpotStorageService();
  bool _loading = true;
  List<JackpotHistoryEntry> _history = [];
  List<ShareDrawLogEntry> _log = [];
  List<PrizeTier> _tiers = [];
  String? _drawIdLabel;

  NumberFreqStats? _freqStats;
  bool _freqLoading = false;
  String? _freqError;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool forceFreq = false}) async {
    final h = await _storage.jackpotHistoryFull();
    final l = await _storage.shareDrawLog();
    final cachedFreq = await _storage.numberFreqStats;
    final tiers = await _storage.prizeTiers;
    final drawId = await _storage.lastDrawId;
    if (!mounted) return;
    setState(() {
      _history = h;
      _log = l;
      _freqStats = cachedFreq;
      _tiers = tiers;
      _drawIdLabel = drawId != null ? '#$drawId' : null;
      _loading = false;
    });

    // Cache qua 24h hoac chua co du lieu -> cao lai. Nguoi dung bam nut lam
    // moi thi luon cao lai bat ke cache con moi hay khong.
    final stale = cachedFreq == null ||
        DateTime.now().difference(cachedFreq.fetchedAt) > const Duration(hours: 24);
    if (forceFreq || stale) {
      await _refreshFreqStats();
    }
  }

  Future<void> _refreshFreqStats() async {
    if (!mounted) return;
    setState(() {
      _freqLoading = true;
      _freqError = null;
    });
    try {
      final stats = await DrawHistorySource.fetchAndCompute();
      if (stats != null) {
        await _storage.setNumberFreqStats(stats);
        if (!mounted) return;
        setState(() => _freqStats = stats);
      } else if (_freqStats == null) {
        if (!mounted) return;
        setState(() => _freqError = t('Không đọc được dữ liệu lịch sử', 'Could not load history data'));
      }
    } catch (e) {
      if (!mounted) return;
      if (_freqStats == null) {
        setState(() => _freqError =
            '${t('Lỗi tải lịch sử', 'Failed to load history')}: ${t(friendlyError(e), friendlyErrorEn(e))}');
      }
    } finally {
      if (mounted) setState(() => _freqLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.ivory,
      appBar: AppBar(
        title: Text(t('Thống Kê', 'Stats')),
        actions: [
          IconButton(icon: const Icon(Icons.refresh, size: 26), onPressed: () => _load(forceFreq: true)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () => _load(forceFreq: true),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
                children: [
                  if (_history.isEmpty && _log.isEmpty && _freqStats == null) _buildEmptyState(),
                  if (_tiers.isNotEmpty) ...[
                    PrizeTable(tiers: _tiers, t: t, headerSuffix: _drawIdLabel),
                    const SizedBox(height: 22),
                  ],
                  if (_freqStats != null) ...[
                    _buildHeroCard(),
                    const SizedBox(height: 22),
                  ],
                  _sectionHeader(Icons.leaderboard_rounded, t('Tần suất về số', 'Number frequency'),
                      t('Toàn bộ lịch sử', 'Full history')),
                  const SizedBox(height: 10),
                  _buildFreqSection(),
                  const SizedBox(height: 24),
                  _adBreak(),
                  if (_history.isNotEmpty) ...[
                    _sectionHeader(
                      Icons.show_chart_rounded,
                      t('Lịch sử giá trị Độc Đắc', 'Jackpot value history'),
                      t(
                        '${_history.length} kỳ · #${_history.first.drawId} → #${_history.last.drawId}',
                        '${_history.length} draws · #${_history.first.drawId} → #${_history.last.drawId}',
                      ),
                    ),
                    const SizedBox(height: 10),
                    _buildJackpotChart(),
                    const SizedBox(height: 24),
                    _adBreak(),
                  ],
                  if (_log.isNotEmpty) ...[
                    _sectionHeader(
                        Icons.emoji_events_rounded, t('Tần suất kỳ chia giải', 'Share draw frequency'), null),
                    const SizedBox(height: 10),
                    _buildShareDrawStats(),
                    const SizedBox(height: 14),
                    _buildShareDrawLogList(),
                    const SizedBox(height: 16),
                  ],
                  _buildDisclaimer(),
                ],
              ),
            ),
    );
  }

  Widget _adBreak() {
    return const Padding(
      padding: EdgeInsets.only(bottom: 24),
      child: Center(child: AdBannerWidget()),
    );
  }

  Widget _buildEmptyState() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 60),
      child: Column(
        children: [
          Icon(Icons.bar_chart_rounded, size: 56, color: AppColors.muted.withOpacity(0.35)),
          const SizedBox(height: 14),
          Text(
            t(
              'Chưa có dữ liệu thống kê.\nBấm "Kiểm tra ngay" ở tab Chia Giải để bắt đầu ghi nhận.',
              'No stats data yet.\nTap "Check now" on the Jackpot tab to start recording.',
            ),
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13.5, color: AppColors.muted),
          ),
        ],
      ),
    );
  }

  // ── Hero: điểm nhấn tổng quan đầu trang ──────────────────────────────

  Widget _buildHeroCard() {
    final stats = _freqStats!;
    final hottestMain = stats.mainFreq.entries.reduce((a, b) => a.value >= b.value ? a : b);
    final coldestMain = List<int>.generate(35, (i) => i + 1)
        .reduce((a, b) => stats.mainGan(a) >= stats.mainGan(b) ? a : b);
    final hottestSpecial = stats.specialFreq.entries.reduce((a, b) => a.value >= b.value ? a : b);

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.luckyRed, Color(0xFF6E1010)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: AppColors.luckyRed.withOpacity(0.28), blurRadius: 18, offset: const Offset(0, 8)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.insights_rounded, color: Colors.white, size: 22),
              const SizedBox(width: 8),
              Text(t('Tổng quan ${stats.totalDraws} kỳ', 'Overview: ${stats.totalDraws} draws'),
                  style: GoogleFonts.baloo2(color: Colors.white, fontSize: 16.5, fontWeight: FontWeight.w700)),
            ],
          ),
          const SizedBox(height: 4),
          Text('#${stats.firstDrawId} → #${stats.lastDrawId}',
              style: const TextStyle(color: Colors.white70, fontSize: 11)),
          const SizedBox(height: 16),
          Row(
            children: [
              _heroStat(t('Về nhiều nhất', 'Most frequent'), hottestMain.key,
                  t('${hottestMain.value} lần', '${hottestMain.value}x'), AppColors.jade),
              _heroDivider(),
              _heroStat(t('Gan lâu nhất', 'Longest overdue'), coldestMain,
                  t('${stats.mainGan(coldestMain)} kỳ', '${stats.mainGan(coldestMain)} draws'), AppColors.gold),
              _heroDivider(),
              _heroStat(t('ĐB nhiều nhất', 'Top special'), hottestSpecial.key,
                  t('${hottestSpecial.value} lần', '${hottestSpecial.value}x'), const Color(0xFFE07B1A)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _heroDivider() => Container(width: 1, height: 48, color: Colors.white24);

  Widget _heroStat(String label, int number, String sub, Color ballColor) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 46,
            height: 46,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: ballColor,
              border: Border.all(color: Colors.white, width: 2),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 4)],
            ),
            child: Text(number.toString().padLeft(2, '0'),
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15.5)),
          ),
          const SizedBox(height: 6),
          Text(label,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 10.5, fontWeight: FontWeight.w600)),
          Text(sub, style: const TextStyle(color: Colors.white70, fontSize: 10)),
        ],
      ),
    );
  }

  Widget _sectionHeader(IconData icon, String title, String? subtitle) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: AppColors.luckyRed.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, size: 18, color: AppColors.luckyRed),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: GoogleFonts.baloo2(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.ink)),
              if (subtitle != null)
                Text(subtitle, style: TextStyle(fontSize: 11, color: AppColors.muted)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardIvory,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.gold.withOpacity(0.35)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 4)),
        ],
      ),
      child: child,
    );
  }

  // ── Thống kê tần suất về số (từ file CSV lịch sử) ──────────────────────

  Widget _buildFreqSection() {
    final stats = _freqStats;
    if (stats == null) {
      if (_freqLoading) {
        return const Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Center(child: CircularProgressIndicator()),
        );
      }
      return _card(
        child: Row(
          children: [
            Icon(Icons.warning_amber_rounded, size: 20, color: AppColors.muted),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                _freqError ?? t('Chưa có dữ liệu — kéo xuống để làm mới.', 'No data yet — pull down to refresh.'),
                style: TextStyle(fontSize: 12, color: AppColors.muted),
              ),
            ),
          ],
        ),
      );
    }

    final mostMain = stats.mainFreq.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final leastMain = stats.mainFreq.entries.toList()
      ..sort((a, b) => a.value.compareTo(b.value));
    final ganMain = List<int>.generate(35, (i) => i + 1)
      ..sort((a, b) => stats.mainGan(b).compareTo(stats.mainGan(a)));
    final mostSpecial = stats.specialFreq.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final maxFreq = mostMain.first.value == 0 ? 1 : mostMain.first.value;

    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_freqLoading) ...[
            Row(
              children: [
                const SizedBox(width: 12, height: 12, child: CircularProgressIndicator(strokeWidth: 2)),
                const SizedBox(width: 6),
                Text(t('Đang làm mới...', 'Refreshing...'),
                    style: TextStyle(fontSize: 11, color: AppColors.muted)),
              ],
            ),
            const SizedBox(height: 12),
          ],
          _freqBallRow(t('🔥 Về nhiều nhất', '🔥 Most frequent'), mostMain.take(6), maxFreq, AppColors.jade),
          const SizedBox(height: 14),
          _freqBallRow(t('❄️ Về ít nhất', '❄️ Least frequent'), leastMain.take(6), maxFreq, AppColors.muted),
          const SizedBox(height: 14),
          _ganRow(t('⏳ "Gan" lâu nhất', '⏳ Longest overdue'), ganMain.take(6), stats),
          const SizedBox(height: 14),
          _freqBallRow(t('🎯 Số đặc biệt về nhiều nhất', '🎯 Most frequent special'), mostSpecial.take(6),
              mostSpecial.first.value == 0 ? 1 : mostSpecial.first.value, const Color(0xFFE07B1A)),
        ],
      ),
    );
  }

  Widget _freqBallRow(String label, Iterable<MapEntry<int, int>> items, int maxFreq, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Row(
          children: [
            for (final e in items)
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: Column(
                    children: [
                      Container(
                        width: 37,
                        height: 37,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: color.withOpacity(0.35 + 0.65 * (e.value / maxFreq)),
                          boxShadow: [BoxShadow(color: color.withOpacity(0.2), blurRadius: 4)],
                        ),
                        child: Text(e.key.toString().padLeft(2, '0'),
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12.5)),
                      ),
                      const SizedBox(height: 3),
                      Text('${e.value}', style: TextStyle(fontSize: 9.5, color: AppColors.muted)),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }

  Widget _ganRow(String label, Iterable<int> nums, NumberFreqStats stats) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Row(
          children: [
            for (final n in nums)
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: Column(
                    children: [
                      Container(
                        width: 37,
                        height: 37,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppColors.gold,
                          boxShadow: [BoxShadow(color: AppColors.gold.withOpacity(0.35), blurRadius: 4)],
                        ),
                        child: Text(n.toString().padLeft(2, '0'),
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12.5)),
                      ),
                      const SizedBox(height: 3),
                      Text('${stats.mainGan(n)}k', style: TextStyle(fontSize: 9.5, color: AppColors.muted)),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }

  // ── Biểu đồ cột tự vẽ (không phụ thuộc thư viện chart ngoài) ───────────

  Widget _buildJackpotChart() {
    final shown = _history.length > 30 ? _history.sublist(_history.length - 30) : _history;
    final maxVal = shown.map((e) => e.jackpotVnd).reduce((a, b) => a > b ? a : b);

    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('${(maxVal / 1e9).toStringAsFixed(1)} ${t('tỷ', 'B')}',
                  style: GoogleFonts.baloo2(fontSize: 19, fontWeight: FontWeight.w800, color: AppColors.luckyRed)),
              const SizedBox(width: 6),
              Text(t('cao nhất trong ${shown.length} kỳ gần đây', 'highest in the last ${shown.length} draws'),
                  style: TextStyle(fontSize: 11.5, color: AppColors.muted)),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 140,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final e in shown)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 1.5),
                      child: Tooltip(
                        message: '#${e.drawId}\n${ShareDrawMachine.fmt(e.jackpotVnd)}',
                        child: Container(
                          height: 130 * (e.jackpotVnd / maxVal).clamp(0.03, 1.0),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                              colors: e.jackpotVnd >= 12000000000
                                  ? [AppColors.luckyRed, const Color(0xFFDA5A5A)]
                                  : [AppColors.jade, const Color(0xFF3FA377)],
                            ),
                            borderRadius: const BorderRadius.vertical(top: Radius.circular(3)),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('#${shown.first.drawId}', style: TextStyle(fontSize: 9.5, color: AppColors.muted)),
              Row(
                children: [
                  _legendDot(AppColors.jade, t('< 12 tỷ', '< 12B')),
                  const SizedBox(width: 10),
                  _legendDot(AppColors.luckyRed, t('≥ 12 tỷ', '≥ 12B')),
                ],
              ),
              Text('#${shown.last.drawId}', style: TextStyle(fontSize: 9.5, color: AppColors.muted)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _legendDot(Color c, String label) {
    return Row(
      children: [
        Container(width: 8, height: 8, decoration: BoxDecoration(color: c, shape: BoxShape.circle)),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(fontSize: 9.5, color: AppColors.muted)),
      ],
    );
  }

  // ── Thống kê tần suất chia giải ─────────────────────────────────────

  Widget _buildShareDrawStats() {
    final completed = _log.where((e) => e.kind == 'completed').toList();
    final cancelled = _log.where((e) => e.kind == 'cancelled').length;
    final scheduled = _log.where((e) => e.kind == 'scheduled').length;

    String? avgGapText;
    if (completed.length >= 2) {
      final dates = completed.map((e) => DateTime.tryParse(e.loggedAtIso)).whereType<DateTime>().toList()
        ..sort();
      if (dates.length >= 2) {
        final totalDays = dates.last.difference(dates.first).inDays;
        final avgDays = totalDays / (dates.length - 1);
        avgGapText = t(
          '~${avgDays.toStringAsFixed(0)} ngày/lần (trung bình)',
          '~${avgDays.toStringAsFixed(0)} days/draw (average)',
        );
      }
    }

    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _statChip(t('Đã xác định', 'Confirmed'), scheduled.toString(), AppColors.luckyRed,
                  Icons.event_available),
              const SizedBox(width: 10),
              _statChip(t('Đã chia', 'Completed'), completed.length.toString(), AppColors.jade,
                  Icons.check_circle),
              const SizedBox(width: 10),
              _statChip(t('Đã huỷ', 'Cancelled'), cancelled.toString(), AppColors.muted, Icons.cancel),
            ],
          ),
          if (avgGapText != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: AppColors.gold.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  Icon(Icons.timelapse, size: 15, color: AppColors.gold),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      '${t('Khoảng cách trung bình giữa các lần chia giải', 'Average gap between share draws')}: $avgGapText',
                      style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _statChip(String label, String value, Color color, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 11),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Icon(icon, size: 18, color: color),
            const SizedBox(height: 4),
            Text(value, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: color)),
            Text(label, style: TextStyle(fontSize: 10, color: AppColors.muted), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _buildShareDrawLogList() {
    final reversed = _log.reversed.take(15).toList();
    return _card(
      child: Column(
        children: [
          for (int i = 0; i < reversed.length; i++) ...[
            _logRow(reversed[i]),
            if (i != reversed.length - 1) Divider(height: 1, color: AppColors.gold.withOpacity(0.15)),
          ],
        ],
      ),
    );
  }

  Widget _logRow(ShareDrawLogEntry e) {
    final (icon, color, label) = switch (e.kind) {
      'scheduled' => (Icons.event_available, AppColors.luckyRed, t('Xác định kỳ chia giải', 'Share draw confirmed')),
      'completed' => (Icons.check_circle, AppColors.jade, t('Đã chia giải xong', 'Share draw completed')),
      'cancelled' => (Icons.cancel, AppColors.muted, t('Huỷ (có người trúng trước)', 'Cancelled (won early)')),
      _ => (Icons.info, AppColors.muted, e.kind),
    };
    final dt = DateTime.tryParse(e.loggedAtIso);
    final dateStr = dt != null
        ? '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}'
        : '';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(color: color.withOpacity(0.12), shape: BoxShape.circle),
            child: Icon(icon, size: 15, color: color),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                if (e.jackpotVnd != null)
                  Text(ShareDrawMachine.fmt(e.jackpotVnd),
                      style: TextStyle(fontSize: 11, color: AppColors.muted)),
              ],
            ),
          ),
          Text(dateStr, style: TextStyle(fontSize: 11, color: AppColors.muted)),
        ],
      ),
    );
  }

  Widget _buildDisclaimer() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.muted.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.info_outline, size: 15, color: AppColors.muted),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              t(
                'Đây đều là thống kê mô tả, không dùng để dự đoán kỳ quay tiếp theo.',
                'This is purely descriptive statistics, not a prediction for the next draw.',
              ),
              style: TextStyle(fontSize: 11, color: AppColors.muted, fontStyle: FontStyle.italic),
            ),
          ),
        ],
      ),
    );
  }
}
