import 'package:http/http.dart' as http;

/// Nguồn CDN cho dữ liệu từ repo `lotto-scan` — dùng jsDelivr
/// (cdn.jsdelivr.net) THAY CHO raw.githubusercontent.com làm nguồn chính.
///
/// Vì sao đổi: raw.githubusercontent.com từng bị lỗi "Failed host lookup"
/// trên một số mạng di động VN (DNS không phân giải được host này). jsDelivr
/// là CDN công cộng có nhiều điểm PoP, cache lại nguyên nội dung GitHub raw
/// và thường dễ truy cập hơn.
///
/// KHÔNG xoá cache CDN (jsDelivr) từ phía app — repo `lotto-scan` chỉ cập
/// nhật 2 lần/ngày, cache jsDelivr tự làm mới trong vài phút tới vài giờ là
/// đủ nhanh so với tần suất đó, không cần app chủ động gọi endpoint purge
/// (tốn thêm 1 request mạng mỗi lần "làm mới" mà không mang lại lợi ích
/// đáng kể).
///
/// Vẫn giữ raw.githubusercontent.com làm DỰ PHÒNG (rơi xuống tự động) nếu
/// jsDelivr lỗi/mạng chặn CDN — không phụ thuộc hoàn toàn vào 1 nguồn duy
/// nhất.
class GithubCdn {
  GithubCdn._();

  static const owner = 'thuantn005';
  static const repo = 'lotto-scan';
  static const branch = 'main';

  /// URL jsDelivr cho 1 đường dẫn trong repo, vd: 'data/all.csv'.
  static String url(String path) => 'https://cdn.jsdelivr.net/gh/$owner/$repo@$branch/$path';

  /// URL gốc GitHub raw — dự phòng khi jsDelivr lỗi.
  static String rawUrl(String path) =>
      'https://raw.githubusercontent.com/$owner/$repo/$branch/$path';

  /// Tải 1 file: ưu tiên jsDelivr; tự động rơi về raw.githubusercontent.com
  /// nếu jsDelivr lỗi (timeout, mạng chặn CDN, jsDelivr sập tạm...) hoặc trả
  /// về mã lỗi khác 200.
  static Future<http.Response> fetch(
    String path, {
    Duration timeout = const Duration(seconds: 30),
    Map<String, String>? headers,
  }) async {
    try {
      final resp = await http.get(Uri.parse(url(path)), headers: headers).timeout(timeout);
      if (resp.statusCode == 200) return resp;
    } catch (_) {
      // roi xuong raw ben duoi
    }
    return http.get(Uri.parse(rawUrl(path)), headers: headers).timeout(timeout);
  }
}
