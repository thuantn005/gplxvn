import 'package:http/http.dart' as http;

/// Nguồn CDN cho dữ liệu từ repo `lotto-scan` — dùng jsDelivr
/// (cdn.jsdelivr.net) THAY CHO raw.githubusercontent.com làm nguồn chính.
///
/// Vì sao đổi: raw.githubusercontent.com từng bị lỗi "Failed host lookup"
/// trên một số mạng di động VN (DNS không phân giải được host này). jsDelivr
/// là CDN công cộng có nhiều điểm PoP, cache lại nguyên nội dung GitHub raw
/// và thường dễ truy cập hơn. jsDelivr cũng có endpoint xoá cache (purge)
/// riêng — dùng khi cần chắc chắn lấy đúng bản mới nhất ngay, thay vì đợi
/// cache tự hết hạn (mặc định jsDelivr cache ~12h - 7 ngày tuỳ file).
///
/// Vẫn giữ raw.githubusercontent.com làm DỰ PHÒNG (rơi xuống tự động) nếu
/// jsDelivr lỗi/mạng chặn CDN — không phụ thuộc hoàn toàn vào 1 nguồn duy
/// nhất.
class GithubCdn {
  GithubCdn._();

  static const owner = 'thuantn005';
  static const repo = 'lotto-scan';
  static const branch = 'main';

  /// URL jsDelivr cho 1 đường dẫn trong repo, vd: 'data/all.csv'.
  static String url(String path) => 'https://cdn.jsdelivr.net/gh/$owner/$repo@$branch/$path';

  /// URL gốc GitHub raw — dự phòng khi jsDelivr lỗi.
  static String rawUrl(String path) =>
      'https://raw.githubusercontent.com/$owner/$repo/$branch/$path';

  /// Xoá cache jsDelivr cho 1 đường dẫn cụ thể. Gọi trước khi tải khi người
  /// dùng bấm "làm mới"/"tải lại" và cần chắc chắn không dính bản cache cũ.
  /// Thất bại thì bỏ qua lặng lẽ — không chặn luồng tải dữ liệu chính, vì
  /// dữ liệu vẫn tải được (chỉ là có thể là bản cache cũ vài phút/giờ).
  static Future<void> purge(String path) async {
    try {
      await http
          .get(Uri.parse('https://purge.jsdelivr.net/gh/$owner/$repo@$branch/$path'))
          .timeout(const Duration(seconds: 10));
    } catch (_) {
      // bo qua
    }
  }

  /// Tải 1 file: ưu tiên jsDelivr; tự động rơi về raw.githubusercontent.com
  /// nếu jsDelivr lỗi (timeout, mạng chặn CDN, jsDelivr sập tạm...) hoặc trả
  /// về mã lỗi khác 200.
  ///
  /// [forcePurge] = true để xoá cache jsDelivr TRƯỚC khi tải — dùng cho các
  /// nút "làm mới"/"tải lại" do người dùng chủ động bấm.
  static Future<http.Response> fetch(
    String path, {
    bool forcePurge = false,
    Duration timeout = const Duration(seconds: 30),
    Map<String, String>? headers,
  }) async {
    if (forcePurge) await purge(path);
    try {
      final resp = await http.get(Uri.parse(url(path)), headers: headers).timeout(timeout);
      if (resp.statusCode == 200) return resp;
    } catch (_) {
      // roi xuong raw ben duoi
    }
    return http.get(Uri.parse(rawUrl(path)), headers: headers).timeout(timeout);
  }
}
