import 'package:http/http.dart' as http;

/// Đọc dữ liệu từ repo `lotto-scan` — CHỈ dùng raw.githubusercontent.com,
/// đọc THẲNG từ GitHub, không qua bất kỳ lớp CDN/cache trung gian nào.
///
/// Đã bỏ hẳn jsDelivr (từng dùng làm dự phòng): jsDelivr có lớp cache riêng
/// mà app không xoá được nữa (đã bỏ cơ chế purge để đỡ tốn 1 request mạng
/// mỗi lần làm mới) — dẫn tới lỗi "GitHub Actions đã báo có kỳ mới qua FCM,
/// nhưng app tự đọc lại (WorkManager, bấm "Kiểm tra ngay", mở app lần đầu)
/// vẫn dính bản cache CŨ của jsDelivr". raw.githubusercontent.com không có
/// vấn đề này — luôn trả đúng bản mới nhất đã commit.
///
/// Đánh đổi: một số mạng di động VN từng gặp lỗi DNS "Failed host lookup"
/// với host này (không phải lỗi app, lỗi phân giải tên miền phía mạng) —
/// chấp nhận rủi ro này để đổi lấy dữ liệu LUÔN MỚI, không có class dữ
/// liệu cũ/mới lẫn lộn khó debug.
class GithubCdn {
  GithubCdn._();

  static const owner = 'thuantn005';
  static const repo = 'lotto-scan';
  static const branch = 'main';

  static String rawUrl(String path) =>
      'https://raw.githubusercontent.com/$owner/$repo/$branch/$path';

  static Future<http.Response> fetch(
    String path, {
    Duration timeout = const Duration(seconds: 30),
    Map<String, String>? headers,
  }) {
    return http.get(Uri.parse(rawUrl(path)), headers: headers).timeout(timeout);
  }
}
