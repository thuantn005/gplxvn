import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../models/draw.dart';
import 'draw_history_source.dart';
import 'share_draw_machine.dart';

/// 1 mốc giá trị Độc Đắc theo kỳ — dùng để vẽ lịch sử/thống kê.
class JackpotHistoryEntry {
  final String drawId;
  final String drawDate;
  final int jackpotVnd;

  JackpotHistoryEntry({required this.drawId, required this.drawDate, required this.jackpotVnd});

  Map<String, dynamic> toJson() =>
      {'drawId': drawId, 'drawDate': drawDate, 'jackpotVnd': jackpotVnd};

  factory JackpotHistoryEntry.fromJson(Map<String, dynamic> j) => JackpotHistoryEntry(
        drawId: j['drawId'] as String,
        drawDate: j['drawDate'] as String,
        jackpotVnd: j['jackpotVnd'] as int,
      );
}

/// 1 dòng log sự kiện chia giải (chỉ log các mốc quan trọng: xác định kỳ
/// chia giải, huỷ, hoàn tất) — dùng để thống kê tần suất/khoảng cách.
class ShareDrawLogEntry {
  final String loggedAtIso;
  final String kind; // ten EventKind
  final int? jackpotVnd;
  final String? shareDate;

  ShareDrawLogEntry({
    required this.loggedAtIso,
    required this.kind,
    this.jackpotVnd,
    this.shareDate,
  });

  Map<String, dynamic> toJson() =>
      {'loggedAtIso': loggedAtIso, 'kind': kind, 'jackpotVnd': jackpotVnd, 'shareDate': shareDate};

  factory ShareDrawLogEntry.fromJson(Map<String, dynamic> j) => ShareDrawLogEntry(
        loggedAtIso: j['loggedAtIso'] as String,
        kind: j['kind'] as String,
        jackpotVnd: j['jackpotVnd'] as int?,
        shareDate: j['shareDate'] as String?,
      );
}

/// 1 vé đã sinh bằng "Sinh Số" — lưu lại để về sau so sánh với kết quả thật
/// khi kỳ đó đã quay xong (mục "Lịch sử" ở tab Sinh Số).
class TicketHistoryEntry {
  final int seed;
  final String drawId;
  final List<int> numbers; // 5 so chinh
  final int special;
  final String generatedAtIso;

  TicketHistoryEntry({
    required this.seed,
    required this.drawId,
    required this.numbers,
    required this.special,
    required this.generatedAtIso,
  });

  Map<String, dynamic> toJson() => {
        'seed': seed,
        'drawId': drawId,
        'numbers': numbers,
        'special': special,
        'generatedAtIso': generatedAtIso,
      };

  factory TicketHistoryEntry.fromJson(Map<String, dynamic> j) => TicketHistoryEntry(
        seed: j['seed'] as int,
        drawId: j['drawId'] as String,
        numbers: (j['numbers'] as List).map((e) => e as int).toList(),
        special: j['special'] as int,
        generatedAtIso: j['generatedAtIso'] as String,
      );
}

/// Lưu trạng thái máy chia giải + dữ liệu phụ trợ, dùng file JSON (đồng
/// nhất với cách các service khác trong app lưu trữ). Port phần liên quan
/// tới jackpot/chia-giải của `Prefs.kt`.
class JackpotStorageService {
  static const _fileName = 'jackpot_prefs.json';
  static const _maxHistoryEntries = 500; // ~du cho nhieu thang du lieu
  static const _maxLogEntries = 200;
  static const _maxTicketEntries = 300;

  Future<File> _getFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$_fileName');
  }

  Future<Map<String, dynamic>> _readAll() async {
    try {
      final file = await _getFile();
      if (!await file.exists()) return {};
      final content = await file.readAsString();
      if (content.trim().isEmpty) return {};
      return jsonDecode(content) as Map<String, dynamic>;
    } catch (_) {
      return {};
    }
  }

  Future<void> _writeAll(Map<String, dynamic> data) async {
    final file = await _getFile();
    await file.writeAsString(jsonEncode(data));
  }

  Future<ShareDrawState> loadState() async {
    final data = await _readAll();
    final raw = data['state'] as Map<String, dynamic>?;
    return raw != null ? ShareDrawState.fromJson(raw) : ShareDrawState();
  }

  Future<void> saveState(ShareDrawState state) async {
    final data = await _readAll();
    data['state'] = state.toJson();
    await _writeAll(data);
  }

  // ── Lịch sử giá trị Độc Đắc (đầy đủ, dùng cho thống kê) ────────────────

  Future<List<JackpotHistoryEntry>> jackpotHistoryFull() async {
    final raw = (await _readAll())['jackpotHistoryFull'] as List?;
    if (raw == null) return [];
    return raw.map((e) => JackpotHistoryEntry.fromJson(e as Map<String, dynamic>)).toList();
  }

  /// Thêm/cập nhật 1 mốc theo kỳ (dedup theo drawId — cào lại cùng kỳ sẽ
  /// GHI ĐÈ đúng vị trí, không tạo bản trùng). Sắp xếp lại theo drawId tăng
  /// dần, giữ tối đa [_maxHistoryEntries] mốc gần nhất.
  Future<void> pushJackpotEntry({
    required String drawId,
    required String drawDate,
    required int jackpotVnd,
  }) async {
    final data = await _readAll();
    final list = await jackpotHistoryFull();
    list.removeWhere((e) => e.drawId == drawId);
    list.add(JackpotHistoryEntry(drawId: drawId, drawDate: drawDate, jackpotVnd: jackpotVnd));
    list.sort((a, b) => (int.tryParse(a.drawId) ?? 0).compareTo(int.tryParse(b.drawId) ?? 0));
    final kept =
        list.length > _maxHistoryEntries ? list.sublist(list.length - _maxHistoryEntries) : list;
    data['jackpotHistoryFull'] = kept.map((e) => e.toJson()).toList();
    await _writeAll(data);
  }

  /// Vài giá trị pot gần nhất dạng số thuần (dùng cho `ShareDrawMachine`
  /// phát hiện pot reset) — lấy từ đuôi của lịch sử đầy đủ ở trên.
  Future<List<int>> jackpotHistory() async {
    final full = await jackpotHistoryFull();
    final tail = full.length > 6 ? full.sublist(full.length - 6) : full;
    return tail.map((e) => e.jackpotVnd).toList();
  }

  // ── Log sự kiện chia giải (dùng cho thống kê tần suất) ─────────────────

  Future<List<ShareDrawLogEntry>> shareDrawLog() async {
    final raw = (await _readAll())['shareDrawLog'] as List?;
    if (raw == null) return [];
    return raw.map((e) => ShareDrawLogEntry.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<void> appendShareDrawLog(ShareDrawLogEntry entry) async {
    final data = await _readAll();
    final list = await shareDrawLog();
    list.add(entry);
    final kept = list.length > _maxLogEntries ? list.sublist(list.length - _maxLogEntries) : list;
    data['shareDrawLog'] = kept.map((e) => e.toJson()).toList();
    await _writeAll(data);
  }

  // ── Lịch sử vé đã sinh (mục "Lịch sử" ở tab Sinh Số) ───────────────────

  Future<List<TicketHistoryEntry>> ticketHistory() async {
    final raw = (await _readAll())['ticketHistory'] as List?;
    if (raw == null) return [];
    return raw.map((e) => TicketHistoryEntry.fromJson(e as Map<String, dynamic>)).toList();
  }

  /// Thêm 1 loạt vé vừa sinh vào lịch sử (mới nhất ở cuối), giữ tối đa
  /// [_maxTicketEntries] vé gần nhất.
  Future<void> pushTickets(List<TicketHistoryEntry> tickets) async {
    if (tickets.isEmpty) return;
    final data = await _readAll();
    final list = await ticketHistory();
    list.addAll(tickets);
    final kept =
        list.length > _maxTicketEntries ? list.sublist(list.length - _maxTicketEntries) : list;
    data['ticketHistory'] = kept.map((e) => e.toJson()).toList();
    await _writeAll(data);
  }

  // ── Các giá trị đơn lẻ khác (không đổi) ────────────────────────────────

  Future<String?> get lastDrawId async => (await _readAll())['lastDrawId'] as String?;
  Future<void> setLastDrawId(String? v) async {
    final data = await _readAll();
    data['lastDrawId'] = v;
    await _writeAll(data);
  }

  Future<String?> get lastDrawDate async => (await _readAll())['lastDrawDate'] as String?;
  Future<void> setLastDrawDate(String? v) async {
    final data = await _readAll();
    data['lastDrawDate'] = v;
    await _writeAll(data);
  }

  Future<String?> get lastDrawTime async => (await _readAll())['lastDrawTime'] as String?;
  Future<void> setLastDrawTime(String? v) async {
    final data = await _readAll();
    data['lastDrawTime'] = v;
    await _writeAll(data);
  }

  /// Đánh dấu đã gieo 2 task nền bám giờ quay (13h10/21h10) lần đầu, để
  /// không đăng ký lại (và làm lệch initialDelay) mỗi lần mở app.
  Future<bool> get anchorTasksSeeded async => (await _readAll())['anchorTasksSeeded'] as bool? ?? false;
  Future<void> setAnchorTasksSeeded(bool v) async {
    final data = await _readAll();
    data['anchorTasksSeeded'] = v;
    await _writeAll(data);
  }

  /// Dark mode: false = sáng (mặc định), true = tối.
  Future<bool> get isDarkMode async => (await _readAll())['isDarkMode'] as bool? ?? false;
  Future<void> setIsDarkMode(bool v) async {
    final data = await _readAll();
    data['isDarkMode'] = v;
    await _writeAll(data);
  }

  Future<String> get lastStatus async =>
      (await _readAll())['lastStatus'] as String? ?? 'Chưa kiểm tra lần nào';
  Future<void> setLastStatus(String v) async {
    final data = await _readAll();
    data['lastStatus'] = v;
    await _writeAll(data);
  }

  Future<String> get lastDrawText async => (await _readAll())['lastDrawText'] as String? ?? '—';
  Future<void> setLastDrawText(String v) async {
    final data = await _readAll();
    data['lastDrawText'] = v;
    await _writeAll(data);
  }

  Future<int?> get lastJackpot async => (await _readAll())['lastJackpot'] as int?;
  Future<void> setLastJackpot(int v) async {
    final data = await _readAll();
    data['lastJackpot'] = v;
    await _writeAll(data);
  }

  Future<String> get lastSource async => (await _readAll())['lastSource'] as String? ?? '—';
  Future<void> setLastSource(String v) async {
    final data = await _readAll();
    data['lastSource'] = v;
    await _writeAll(data);
  }

  /// Bảng 7 bậc giải của kỳ mới nhất — lưu để hiển thị lại khi mở app,
  /// không cần chờ cào lại.
  Future<List<PrizeTier>> get prizeTiers async {
    final raw = (await _readAll())['prizeTiers'] as List?;
    if (raw == null) return [];
    return raw.map((e) {
      final m = e as Map<String, dynamic>;
      return PrizeTier(
        name: m['name'] as String,
        rule: m['rule'] as String,
        count: m['count'] as int,
        valueVnd: m['valueVnd'] as int,
      );
    }).toList();
  }

  Future<void> setPrizeTiers(List<PrizeTier> tiers) async {
    final data = await _readAll();
    data['prizeTiers'] = tiers
        .map((t) => {'name': t.name, 'rule': t.rule, 'count': t.count, 'valueVnd': t.valueVnd})
        .toList();
    await _writeAll(data);
  }

  // ── Cache thống kê tần suất số (cào từ CSV lịch sử GitHub) ─────────────
  // Cache lại vì file ~850 dòng, không cần cào lại mỗi lần mở tab Thống Kê.

  Future<NumberFreqStats?> get numberFreqStats async {
    final raw = (await _readAll())['numberFreqStats'] as Map<String, dynamic>?;
    if (raw == null) return null;
    try {
      return NumberFreqStats.fromJson(raw);
    } catch (_) {
      return null;
    }
  }

  Future<void> setNumberFreqStats(NumberFreqStats stats) async {
    final data = await _readAll();
    data['numberFreqStats'] = stats.toJson();
    await _writeAll(data);
  }

  /// Bật/tắt từng loại thông báo. Mặc định BẬT scheduled/reminder/missed
  /// (đúng thứ người dùng cần biết), TẮT các loại phụ để đỡ làm phiền.
  bool _defaultFor(EventKind k) {
    switch (k) {
      case EventKind.scheduled:
      case EventKind.reminder:
      case EventKind.missed:
        return true;
      default:
        return false;
    }
  }

  Future<bool> isEnabled(EventKind k) async {
    final data = await _readAll();
    return data['notify_${k.name}'] as bool? ?? _defaultFor(k);
  }

  Future<void> setEnabled(EventKind k, bool on) async {
    final data = await _readAll();
    data['notify_${k.name}'] = on;
    await _writeAll(data);
  }

  /// Cho phép dùng nguồn dự phòng (xosominhngoc.net.vn, minhchinh.com) khi
  /// vietlott.vn không vào được. MẶC ĐỊNH TẮT — app chỉ đọc trang chính
  /// thức, đúng nguyên tắc port từ `Prefs.kt`.
  Future<bool> get useMirrors async => (await _readAll())['useMirrors'] as bool? ?? false;
  Future<void> setUseMirrors(bool v) async {
    final data = await _readAll();
    data['useMirrors'] = v;
    await _writeAll(data);
  }

  /// Ngôn ngữ hiển thị: false = Tiếng Việt (mặc định), true = English.
  Future<bool> get isEnglish async => (await _readAll())['isEnglish'] as bool? ?? false;
  Future<void> setIsEnglish(bool v) async {
    final data = await _readAll();
    data['isEnglish'] = v;
    await _writeAll(data);
  }

  // ── Streak ngày mở app liên tiếp ────────────────────────────────────
  // Nhẹ nhàng, chỉ để hiển thị lại cho vui, KHÔNG có phạt/mất streak gây
  // áp lực — nếu bỏ lỡ 1 ngày thì đơn giản đếm lại từ 1, không cảnh báo.

  static String _todayStr() {
    final n = DateTime.now();
    return '${n.year.toString().padLeft(4, '0')}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
  }

  static bool _isYesterday(String lastDateStr, String todayStr) {
    try {
      final last = DateTime.parse(lastDateStr);
      final today = DateTime.parse(todayStr);
      return today.difference(last).inDays == 1;
    } catch (_) {
      return false;
    }
  }

  /// Gọi 1 lần mỗi khi mở app (Home). Trả về số ngày liên tiếp SAU khi cập
  /// nhật (đã tính luôn hôm nay).
  Future<int> bumpStreakOnOpen() async {
    final data = await _readAll();
    final today = _todayStr();
    final last = data['lastOpenDate'] as String?;
    int streak = data['streak'] as int? ?? 0;
    if (last == today) {
      // Đã mở hôm nay rồi, giữ nguyên streak hiện tại.
    } else if (last != null && _isYesterday(last, today)) {
      streak += 1;
    } else {
      streak = 1;
    }
    data['lastOpenDate'] = today;
    data['streak'] = streak;
    await _writeAll(data);
    return streak;
  }
}
