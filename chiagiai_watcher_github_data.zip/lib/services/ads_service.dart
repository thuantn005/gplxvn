import 'package:google_mobile_ads/google_mobile_ads.dart';

/// ID QUẢNG CÁO THẬT — tài khoản AdMob của Thuận (app "Săn Chia Giải 535",
/// package jp.devjlog.vn). App ID cũng đã được cập nhật trong build_apk.yml
/// (bước "Thêm AdMob App ID vào AndroidManifest").
class AdsService {
  static Future<void> initialize() => MobileAds.instance.initialize();

  // Banner cố định dưới màn hình (RootScreen) + banner xen kẽ trong tab
  // Thống Kê — dùng chung 1 loại banner đơn giản, không cần Native Ad
  // Factory phía Kotlin (native ads cần đăng ký thêm code Android riêng,
  // rủi ro build hỏng cao hơn nhiều so với lợi ích).
  static const String bannerAdUnitId = 'ca-app-pub-9611577327028569/5718163824';

  // Quảng cáo có thưởng cho nút "Xem quảng cáo để nhận số" ở tab Sinh Số.
  static const String rewardedAdUnitId = 'ca-app-pub-9611577327028569/4802713575';

  static const int maxLoadAttempts = 3;
}
