import 'package:google_mobile_ads/google_mobile_ads.dart';

/// ⚠️ ĐANG DÙNG ID TEST CỦA GOOGLE (an toàn để build & chạy thử, KHÔNG vi
/// phạm chính sách AdMob, nhưng KHÔNG SINH RA TIỀN THẬT). Trước khi phát
/// hành, bạn PHẢI:
///   1. Tạo app + ad unit thật trong tài khoản AdMob của bạn (admob.google.com)
///   2. Thay App ID trong bước "Thêm AdMob App ID" của build_apk.yml
///   3. Thay các adUnitId bên dưới bằng ID thật tương ứng
/// Nếu phát hành lên Play Store mà vẫn dùng ID test, tài khoản AdMob CÓ THỂ
/// bị khoá vì Google coi đó là click ảo/gian lận khi có traffic thật.
class AdsService {
  static Future<void> initialize() => MobileAds.instance.initialize();

  // Banner cố định dưới màn hình (RootScreen) + banner xen kẽ trong tab
  // Thống Kê — dùng chung 1 loại banner đơn giản, không cần Native Ad
  // Factory phía Kotlin (native ads cần đăng ký thêm code Android riêng,
  // rủi ro build hỏng cao hơn nhiều so với lợi ích).
  static const String bannerAdUnitId = 'ca-app-pub-3940256099942544/6300978111'; // TEST

  // Quảng cáo có thưởng cho nút "Xem quảng cáo để nhận số" ở tab Sinh Số.
  static const String rewardedAdUnitId = 'ca-app-pub-3940256099942544/5224354917'; // TEST

  static const int maxLoadAttempts = 3;
}
