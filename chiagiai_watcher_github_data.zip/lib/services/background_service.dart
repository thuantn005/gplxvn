import 'package:workmanager/workmanager.dart';

import 'jackpot_check_service.dart';

const String kJackpotCheckTask = 'jackpot_check_task';

/// Điểm vào cho isolate nền — BẮT BUỘC là top-level function hoặc static,
/// đánh dấu @pragma để Flutter không tree-shake mất khi build release.
@pragma('vm:entry-point')
void backgroundCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task == kJackpotCheckTask) {
      return JackpotCheckService.runCheck();
    }
    return true;
  });
}

/// Đăng ký kiểm tra nền — CHỈ còn 1 task định kỳ 3 tiếng/lần làm lớp dự
/// phòng nhẹ. Đường đi CHÍNH để biết có kết quả mới giờ là tin đánh thức
/// FCM (tức thời, xem PushService) — bỏ hẳn 2 task bám giờ quay (13:00/
/// 21:00, tự thử lại mỗi 2 phút tới 5 lần) để đỡ tốn pin, vì giờ GitHub
/// Actions đã chủ động báo qua FCM ngay khi có dữ liệu mới, không cần app
/// tự dò bằng cách đánh thức máy liên tục quanh giờ quay nữa.
class JackpotBackgroundService {
  static Future<void> initialize() async {
    await Workmanager().initialize(backgroundCallbackDispatcher);

    await Workmanager().registerPeriodicTask(
      kJackpotCheckTask,
      kJackpotCheckTask,
      frequency: const Duration(hours: 3),
      constraints: Constraints(networkType: NetworkType.connected),
      // Khong truyen existingWorkPolicy: mac dinh cua package da la KEEP
      // (giu nguyen task dinh ky da co, khong tao trung). Bo qua de tranh
      // phu thuoc ten enum co the doi giua cac phien ban package
      // (ExistingWorkPolicy vs ExistingPeriodicWorkPolicy).
    );
  }

  /// Kiểm tra ngay (bấm tay trên app), chạy trực tiếp trên UI isolate,
  /// không qua WorkManager. Đường DUY NHẤT được phép cào trực tiếp
  /// vietlott.vn/mirror làm dự phòng khi GitHub lỗi/chưa có dữ liệu.
  static Future<bool> checkNow() =>
      JackpotCheckService.runCheck(allowDirectScrapeFallback: true);
}
