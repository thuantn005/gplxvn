import 'package:workmanager/workmanager.dart';

import 'jackpot_check_service.dart';

const String kJackpotCheckTask = 'jackpot_check_task';

/// Điểm vào cho isolate nền — BẮT BUỘC là top-level function hoặc static,
/// đánh dấu @pragma để Flutter không tree-shake mất khi build release.
@pragma('vm:entry-point')
void backgroundCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task == kJackpotCheckTask) {
      return JackpotCheckService.runCheck();
    }
    return true;
  });
}

/// Đăng ký kiểm tra nền — CHỈ còn 1 task định kỳ làm lớp dự phòng NHẸ.
/// Đường đi CHÍNH để biết có kết quả mới là tin đánh thức FCM (tức thời,
/// xem PushService) — bỏ hẳn 2 task bám giờ quay (13:00/21:00, tự thử lại
/// mỗi 2 phút tới 5 lần) để đỡ tốn pin, vì GitHub Actions đã chủ động báo
/// qua FCM ngay khi có dữ liệu mới, không cần app tự dò bằng cách đánh
/// thức máy liên tục quanh giờ quay nữa.
///
/// TẦN SUẤT 8 TIẾNG/LẦN (thay vì 3 tiếng như trước) — kỳ quay chỉ có 2
/// lần/ngày (13:00, 21:00), và FCM đã là đường đi chính, nên task này gần
/// như KHÔNG BAO GIỜ thực sự cần thiết (chỉ hữu ích khi FCM bị lỗi/mất
/// đăng ký hiếm khi xảy ra). Giữ 8 tiếng/lần vẫn đủ để bắt kịp trong cùng
/// ngày nếu FCM có trục trặc, mà giảm được hơn nửa số lần đánh thức máy so
/// với 3 tiếng/lần (3 lần/ngày thay vì 8 lần/ngày) — tiết kiệm pin đáng kể
/// vì đây là task chạy 2 lần/ngày trên MỌI máy đang cài app, kể cả những
/// lúc không có gì thay đổi để kiểm tra.
class JackpotBackgroundService {
  static Future<void> initialize() async {
    // Chay unawaited() tu main.dart (khong con chan giao dien) - bat loi
    // o day de tranh log "unhandled exception" am tham neu native call
    // that bai (hiem, nhung khong duoc de crash app).
    try {
      await Workmanager().initialize(backgroundCallbackDispatcher);

      await Workmanager().registerPeriodicTask(
        kJackpotCheckTask,
        kJackpotCheckTask,
        frequency: const Duration(hours: 8),
        constraints: Constraints(networkType: NetworkType.connected),
        // Khong truyen existingWorkPolicy: mac dinh cua package da la KEEP
        // (giu nguyen task dinh ky da co, khong tao trung). Bo qua de tranh
        // phu thuoc ten enum co the doi giua cac phien ban package
        // (ExistingWorkPolicy vs ExistingPeriodicWorkPolicy).
      );
    } catch (e) {
      // ignore: avoid_print
      print('JackpotBackgroundService.initialize() loi (bo qua): $e');
    }
  }

  /// Kiểm tra ngay (bấm tay trên app), chạy trực tiếp trên UI isolate,
  /// không qua WorkManager. Không còn cào trực tiếp trên máy — chỉ đọc
  /// GitHub (qua CDN), không xoá cache CDN.
  static Future<bool> checkNow() => JackpotCheckService.runCheck();
}
