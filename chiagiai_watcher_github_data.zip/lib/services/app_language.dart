import 'package:flutter/foundation.dart';

import 'jackpot_storage_service.dart';

/// Chuyển đổi Tiếng Việt / English cho toàn app.
///
/// Không dùng bộ máy l10n đầy đủ (ARB + codegen) vì app đã có rất nhiều
/// chuỗi cố định rải khắp các màn hình — thay vào đó dùng 1 ValueNotifier
/// toàn cục + hàm `t(vi, en)` bọc trực tiếp tại chỗ dùng chuỗi. Đơn giản,
/// dễ bảo trì, không cần build_runner (không có mạng để `pub get` gói mới
/// trong môi trường build từ xa).
class AppLanguage {
  AppLanguage._();

  /// true = tiếng Anh, false = tiếng Việt (mặc định).
  static final isEnglish = ValueNotifier<bool>(false);

  static final _storage = JackpotStorageService();

  /// Đọc lựa chọn đã lưu — gọi 1 lần lúc khởi động app (trước `runApp`).
  static Future<void> load() async {
    isEnglish.value = await _storage.isEnglish;
  }

  static Future<void> setEnglish(bool v) async {
    isEnglish.value = v;
    await _storage.setIsEnglish(v);
  }
}

/// Trả về chuỗi theo ngôn ngữ hiện tại. Dùng trực tiếp trong `build()`:
/// `Text(t('Cài đặt', 'Settings'))`. Vì đọc `ValueNotifier.value` đồng bộ,
/// widget cha (bọc `ValueListenableBuilder` ở gốc app) rebuild lại toàn bộ
/// cây mỗi khi đổi ngôn ngữ là đủ để mọi `t()` trong `build()` cập nhật.
String t(String vi, String en) => AppLanguage.isEnglish.value ? en : vi;
