import 'package:home_widget/home_widget.dart';

/// Đẩy dữ liệu mới nhất sang Widget màn hình chính Android (không hỗ trợ
/// iOS trong project này — pubspec.yaml đã đặt `ios: false` cho
/// flutter_launcher_icons, tức app chỉ build Android).
///
/// Tên provider "JackpotWidgetProvider" phải KHỚP CHÍNH XÁC với tên class
/// Kotlin trong android/app/src/main/kotlin/jp/devjlog/vn/JackpotWidgetProvider.kt
/// — file đó được ghi ra bởi bước "Thêm Home Screen Widget" trong
/// build_apk.yml (vì thư mục android/ không được lưu sẵn trong repo, CI tự
/// sinh lại mỗi lần build).
class HomeWidgetService {
  static const _androidProviderName = 'JackpotWidgetProvider';

  static String _thousands(int v) {
    final s = v.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  static String _nextDrawTimeText() {
    final now = DateTime.now();
    final today13 = DateTime(now.year, now.month, now.day, 13, 0);
    final today21 = DateTime(now.year, now.month, now.day, 21, 0);
    if (now.isBefore(today13)) return '13:00 hôm nay';
    if (now.isBefore(today21)) return '21:00 hôm nay';
    return '13:00 ngày mai';
  }

  /// Kỳ vừa hiển thị (drawId) LUÔN LÀ kỳ đã có kết quả — "Kỳ tới" nghĩa là
  /// kỳ NGAY SAU đó, suy ra bằng cách +1 vào drawId (đúng quy ước kỳ quay
  /// tăng dần liên tục, giống cách random_pick_screen.dart tính "kỳ tiếp
  /// theo" để sinh vé). Rỗng nếu chưa có drawId nào (chưa kiểm tra lần nào).
  static String _nextDrawIdLabel(String? drawId) {
    if (drawId == null) return '';
    final n = int.tryParse(drawId);
    if (n == null) return '';
    return '#${(n + 1).toString().padLeft(5, '0')} · ';
  }

  static Future<void> push({
    int? jackpotVnd,
    String? drawId,
    String? drawDate,
    String? drawTime,
  }) async {
    try {
      await HomeWidget.saveWidgetData<String>(
        'widget_jackpot',
        jackpotVnd != null ? _thousands(jackpotVnd) : '—',
      );
      final when = _fmtDrawWhen(drawDate, drawTime);
      await HomeWidget.saveWidgetData<String>(
        'widget_draw_label',
        drawId != null
            ? 'Kỳ #$drawId${when.isEmpty ? '' : ' · $when'}'
            : 'Săn Chia Giải 535',
      );
      await HomeWidget.saveWidgetData<String>(
        'widget_next_draw',
        'Kỳ tới: ${_nextDrawIdLabel(drawId)}${_nextDrawTimeText()}',
      );
      await HomeWidget.updateWidget(androidName: _androidProviderName);
    } catch (_) {
      // Máy không hỗ trợ widget, chưa gắn widget nào, hoặc lỗi ghi dữ liệu
      // — bỏ qua êm, không ảnh hưởng luồng kiểm tra chính của app.
    }
  }

  /// "2026-09-01" + "13:00" -> "01/09/2026 - 13:00". Rỗng nếu thiếu ngày.
  static String _fmtDrawWhen(String? isoDate, String? time) {
    if (isoDate == null || isoDate.isEmpty) return '';
    final parts = isoDate.split('-');
    if (parts.length != 3) return '';
    final dmy = '${parts[2]}/${parts[1]}/${parts[0]}';
    return time == null || time.isEmpty ? dmy : '$dmy - $time';
  }
}
