import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

import '../models/draw.dart';
import 'draw_parser.dart';
import 'jackpot_parser.dart';
import 'minh_ngoc_parser.dart';
import 'vietlott_tier_parser.dart';

export '../models/draw.dart' show Snapshot, Draw, PrizeTier;

/// Nguồn dữ liệu — PORT từ `Sources.kt` (app native Android đã kiểm chứng
/// thực tế nhiều tháng).
///
/// WAF của vietlott.vn chặn IP datacenter, nên GitHub Actions luôn nhận 403
/// và pipeline trên server phải sống bằng nguồn bên thứ ba. Điện thoại chạy
/// IP dân cư/di động — loại IP mà WAF cho qua — nên app đọc thẳng nguồn gốc
/// được, khác hẳn hoàn cảnh của CI. Đây là lý do đổi lại vietlott.vn thành
/// nguồn CHÍNH thay vì xosominhngoc.
class JackpotSources {
  /// Trang chính thức — nguồn duy nhất theo mặc định.
  static const official = [
    'https://vietlott.vn/vi/trung-thuong/ket-qua-trung-thuong/535',
    'https://vietlott.vn/vi/choi/lotto535/gioi-thieu-san-pham-535',
  ];

  /// Nguồn dự phòng, MẶC ĐỊNH TẮT. Chỉ bật khi mạng của người dùng không
  /// vào được vietlott.vn — bật trong Cài đặt, không phải sửa code.
  static const mirrors = [
    'https://xosominhngoc.net.vn/kqxs-lotto-535',
    'https://www.minhchinh.com/xo-so-dien-toan-lotto-535.html',
  ];

  static const userAgent = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36';
  static const acceptLanguage = 'vi-VN,vi;q=0.9';
}

/// Cào + parse dữ liệu Lotto 5/35.
///
/// PORT từ `Repository.kt`: thử lần lượt các nguồn trong danh sách, dừng
/// ngay khi đã có ĐỦ (kỳ quay + giá trị Độc Đắc). Không còn nguồn thứ hai
/// để đối chiếu chéo (trừ khi bật mirror), nên nguyên tắc giữ nguyên: dữ
/// liệu nào không chắc thì KHÔNG trả về.
class JackpotRepository {
  static const _timeout = Duration(seconds: 20);

  /// Nguồn dữ liệu ĐÃ CÀO SẴN, do GitHub Actions (repo lotto-scan) cào 2
  /// lần/ngày theo giờ quay + commit lên đây. App đọc thẳng file JSON này
  /// thay vì tự cào HTML — nhẹ hơn, không cần parse HTML trên máy, và
  /// không phụ thuộc app có vào được vietlott.vn lúc đó hay không.
  static const _githubResultsUrl =
      'https://raw.githubusercontent.com/thuantn005/lotto-scan/main/data/full_results.json';

  /// Kiểm tra hợp lý (giống lớp kiểm tra bên `scrape_full_result_json.py`
  /// trong repo lotto-scan) — LỚP PHÒNG THỦ THỨ 2, phòng khi dữ liệu vẫn
  /// lọt lỗi nào đó trong tương lai (bug parser mới, file bị sửa tay
  /// nhầm...) — dù đọc từ GitHub hay đính kèm thẳng trong tin FCM. Ném lỗi
  /// thay vì âm thầm hiển thị số sai.
  static void validate(Snapshot s) {
    final d = s.latestDraw;
    if (d == null) throw const FormatException('Không có kỳ quay nào');
    if (d.numbers.length != 5 || d.numbers.toSet().length != 5) {
      throw FormatException('Số chính không hợp lệ: ${d.numbers}');
    }
    if (d.numbers.any((n) => n < 1 || n > 35)) {
      throw FormatException('Số chính ngoài khoảng 1-35: ${d.numbers}');
    }
    if (d.special == null || d.special! < 1 || d.special! > 12) {
      throw FormatException('Số đặc biệt ngoài khoảng 1-12: ${d.special}');
    }
    if (s.jackpotVnd != null && s.jackpotVnd! < 1000000000) {
      throw FormatException('Giá trị Độc Đắc vô lý: ${s.jackpotVnd}');
    }
    if (s.prizeTiers.isNotEmpty) {
      if (s.prizeTiers.length != 7) {
        throw FormatException('Thiếu/thừa hạng giải: có ${s.prizeTiers.length}/7');
      }
      // Giá trị Giải Khuyến Khích CỐ ĐỊNH theo luật chơi, không bao giờ
      // đổi kể cả kỳ chia giải — bất biến mạnh nhất để kiểm tra.
      final kk = s.prizeTiers.last;
      if (kk.name.contains('Khuyến Khích') && kk.valueVnd != 10000) {
        throw FormatException('Giải Khuyến Khích phải luôn = 10.000, đọc được ${kk.valueVnd}');
      }
      for (final p in s.prizeTiers) {
        if (p.count < 0 || p.count > 200000) {
          throw FormatException('SL hạng "${p.name}" vô lý: ${p.count}');
        }
      }
    }
  }

  /// Đọc kết quả mới nhất từ file JSON trên GitHub (repo lotto-scan).
  /// Đây là đường đi CHÍNH của app từ giờ — thay cho [scrape] (vẫn giữ lại
  /// bên dưới, không dùng nữa, phòng khi cần quay lại cào trực tiếp).
  static Future<Snapshot> fetchFromGitHub() async {
    // raw.githubusercontent.com nam sau CDN cua GitHub - co the tra ve
    // BAN CACHE CU trong vai phut sau khi lotto-scan vua commit ban moi.
    // Them query param doi moi moi lan goi de "be cache": CDN/HTTP cache
    // coi day la 1 URL KHAC voi lan truoc -> luon phai lay ban moi nhat
    // tu goc, khong duoc phep tra ve ban da luu san.
    final bustedUri = Uri.parse(_githubResultsUrl).replace(
      queryParameters: {'t': DateTime.now().millisecondsSinceEpoch.toString()},
    );
    final resp = await http.get(
      bustedUri,
      headers: const {'Cache-Control': 'no-cache, no-store', 'Pragma': 'no-cache'},
    ).timeout(_timeout);
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw HttpException('HTTP ${resp.statusCode} khi đọc full_results.json');
    }
    final decoded = jsonDecode(resp.body);
    if (decoded is! List || decoded.isEmpty) {
      throw const FormatException('full_results.json rỗng hoặc sai định dạng');
    }
    final record = decoded.last as Map<String, dynamic>;
    final snap = fromJson(record, source: 'github:lotto-scan');
    validate(snap);
    return snap;
  }

  /// Dựng [Snapshot] từ 1 record JSON (đúng schema mà
  /// `scrape_full_result_json.py` ghi ra) — dùng chung cho cả
  /// [fetchFromGitHub] (gọi mạng) lẫn dữ liệu đính kèm thẳng trong tin FCM
  /// (không cần gọi mạng thêm lần nào, xem `PushService`).
  static Snapshot fromJson(Map<String, dynamic> record, {String? source}) {
    final drawId = record['draw_id'] as String;
    final drawDate = record['draw_date'] as String? ?? '';
    final drawTime = record['draw_time'] as String?;
    final numbers = (record['numbers'] as List).map((n) => n as int).toList();
    final special = record['special_number'] as int?;
    final jackpotVnd = record['jackpot_value'] as int?;

    final draw = Draw(
      drawId: drawId,
      drawDate: drawDate,
      drawTime: drawTime,
      numbers: numbers,
      special: special,
    );

    final prizeTiers = ((record['prizes'] as List?) ?? const [])
        .map((p) => PrizeTier(
              name: p['tier'] as String,
              rule: p['match'] as String? ?? '',
              count: p['count'] as int,
              valueVnd: p['value'] as int,
            ))
        .toList();

    return Snapshot(
      jackpotVnd: jackpotVnd,
      jackpotDrawId: drawId,
      latestDraw: draw,
      draws: [draw],
      jackpotSource: source,
      drawSource: source,
      prizeTiers: prizeTiers,
    );
  }

  static Future<(String, int)> _fetch(String url) async {
    // Header đầy đủ để giống request trình duyệt thật — thiếu các header
    // này (Accept-Encoding, Sec-Fetch-*, Referer, DNT) là dấu hiệu rõ của
    // bot đối với các hệ chặn theo pattern header, kể cả khi User-Agent đã
    // giả trình duyệt. Referer bám theo origin của chính URL đang gọi, vì
    // Referer trỏ sai domain cũng là một dấu hiệu bot.
    final origin = Uri.parse(url).origin;
    final resp = await http.get(
      Uri.parse(url),
      headers: {
        'User-Agent': JackpotSources.userAgent,
        'Accept-Language': JackpotSources.acceptLanguage,
        'Accept':
            'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Referer': '$origin/',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Upgrade-Insecure-Requests': '1',
      },
    ).timeout(_timeout);
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw HttpException('HTTP ${resp.statusCode}');
    }
    return (resp.body, resp.statusCode);
  }

  static String _host(String url) {
    try {
      return Uri.parse(url).host;
    } catch (_) {
      return url;
    }
  }

  /// [allowMirrors] bật nguồn dự phòng khi mạng không vào được vietlott.vn
  /// (đọc từ Cài đặt — mặc định TẮT, giống app gốc).
  static Future<Snapshot> scrape({bool allowMirrors = false}) async {
    final errors = <String>[];

    int? jackpotVnd;
    String? jackpotDrawId;
    String? jackpotSource;
    Draw? latestDraw;
    List<Draw> draws = const [];
    String? drawSource;
    List<PrizeTier> prizeTiers = const [];

    final urls = allowMirrors
        ? [...JackpotSources.official, ...JackpotSources.mirrors]
        : JackpotSources.official;

    for (final url in urls) {
      if (jackpotVnd != null && latestDraw != null) break;
      final host = _host(url);
      String html;
      try {
        final (body, _) = await _fetch(url);
        html = body;
      } catch (e) {
        errors.add('$host: $e');
        continue;
      }

      // xosominhngoc.net.vn dùng parser CHUYÊN DỤNG (đọc kèm bảng 7 bậc
      // giải trong đúng 1 lần) — chính xác hơn cặp parser tổng quát bên
      // dưới vốn dành cho vietlott.vn. Các nguồn khác (vietlott.vn chính
      // thức, minhchinh.com mirror) dùng cặp parser tổng quát.
      if (host.contains('xosominhngoc')) {
        final (snap, reason) = MinhNgocParser.parseVerbose(html);
        if (snap != null) {
          if (latestDraw == null && snap.latestDraw != null) {
            latestDraw = snap.latestDraw;
            draws = snap.draws;
            drawSource = host;
          }
          if (jackpotVnd == null && snap.jackpotVnd != null) {
            jackpotVnd = snap.jackpotVnd;
            jackpotDrawId = snap.jackpotDrawId;
            jackpotSource = host;
          }
          if (prizeTiers.isEmpty) prizeTiers = snap.prizeTiers;
        } else {
          errors.add('$host: HTTP 200, ${html.length} bytes — $reason');
        }
        continue;
      }

      if (latestDraw == null) {
        final found = DrawParser.parseAll(html);
        if (found.isNotEmpty) {
          draws = found;
          latestDraw = found.last;
          drawSource = host;
        } else {
          // Nói rõ là KHÔNG ĐỌC ĐƯỢC, chứ không im lặng bỏ qua — im lặng
          // khiến số cũ nằm lại trên màn hình như thể mới.
          errors.add('$host: tải được trang nhưng không đọc chắc chắn được dãy số');
        }
      }

      if (jackpotVnd == null) {
        final r = JackpotParser.extract(html, latestDraw?.drawId);
        if (r.amountVnd != null) {
          jackpotVnd = r.amountVnd;
          jackpotDrawId = r.drawId;
          jackpotSource = host;
        }
      }

      // Bảng 7 bậc giải (Số lượng giải / Giá trị giải) — chỉ trang có bảng
      // "trung-thuong" mới có (trang "gioi-thieu-san-pham" không có), nên
      // parse() tự trả về rỗng và không ghi đè nếu trang không có bảng.
      if (prizeTiers.isEmpty) {
        final tiers = VietlottTierParser.parse(html);
        if (tiers.isNotEmpty) prizeTiers = tiers;
      }
    }

    if (jackpotVnd == null && latestDraw == null && errors.isEmpty) {
      errors.add('vietlott.vn: không trả về dữ liệu dùng được');
    }

    return Snapshot(
      jackpotVnd: jackpotVnd,
      jackpotDrawId: jackpotDrawId,
      latestDraw: latestDraw,
      draws: draws,
      jackpotSource: jackpotSource,
      drawSource: drawSource,
      prizeTiers: prizeTiers,
      errors: errors,
    );
  }
}
