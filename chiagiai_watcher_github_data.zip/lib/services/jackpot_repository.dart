import 'dart:convert';
import 'dart:io';

import '../models/draw.dart';
import 'github_cdn.dart';

export '../models/draw.dart' show Snapshot, Draw, PrizeTier, ServerShareState;
export 'share_draw_machine.dart' show ServerShareEvent, EventKind;

/// Đọc dữ liệu Lotto 5/35 — CHỈ đọc từ dữ liệu đã cào sẵn trên GitHub (repo
/// `lotto-scan`, do GitHub Actions cào 2 lần/ngày), qua CDN jsDelivr
/// ([GithubCdn]). App KHÔNG còn tự cào/parse trực tiếp HTML từ
/// vietlott.vn hay bất kỳ trang mirror nào trên máy nữa — bỏ hẳn nhánh cào
/// trực tiếp (giữ pin: không còn request HTML nặng + parse DOM trên máy,
/// chỉ còn 1 request JSON nhỏ gọn qua CDN có cache).
class JackpotRepository {
  static const _timeout = Duration(seconds: 20);

  /// Nguồn dữ liệu ĐÃ CÀO SẴN, do GitHub Actions (repo lotto-scan) cào 2
  /// lần/ngày theo giờ quay + commit lên đây. App đọc thẳng file JSON này
  /// thay vì tự cào HTML — nhẹ hơn, không cần parse HTML trên máy, và
  /// không phụ thuộc app có vào được vietlott.vn lúc đó hay không. Tải qua
  /// [GithubCdn] (jsDelivr, tự rơi về raw.githubusercontent.com nếu lỗi).
  static const _githubResultsPath = 'data/full_results.json';

  /// Kiểm tra hợp lý (giống lớp kiểm tra bên `scrape_full_result_json.py`
  /// trong repo lotto-scan) — LỚP PHÒNG THỦ THỨ 2, phòng khi dữ liệu vẫn
  /// lọt lỗi nào đó trong tương lai (bug parser mới, file bị sửa tay
  /// nhầm...) — dù đọc từ GitHub hay đính kèm thẳng trong tin FCM. Ném lỗi
  /// thay vì âm thầm hiển thị số sai.
  static void validate(Snapshot s) {
    final d = s.latestDraw;
    if (d == null) throw const FormatException('Không có kỳ quay nào');
    if (d.numbers.length != 5 || d.numbers.toSet().length != 5) {
      throw FormatException('Số chính không hợp lệ: ${d.numbers}');
    }
    if (d.numbers.any((n) => n < 1 || n > 35)) {
      throw FormatException('Số chính ngoài khoảng 1-35: ${d.numbers}');
    }
    if (d.special == null || d.special! < 1 || d.special! > 12) {
      throw FormatException('Số đặc biệt ngoài khoảng 1-12: ${d.special}');
    }
    if (s.jackpotVnd != null && s.jackpotVnd! < 1000000000) {
      throw FormatException('Giá trị Độc Đắc vô lý: ${s.jackpotVnd}');
    }
    if (s.prizeTiers.isNotEmpty) {
      if (s.prizeTiers.length != 7) {
        throw FormatException('Thiếu/thừa hạng giải: có ${s.prizeTiers.length}/7');
      }
      // Giá trị Giải Khuyến Khích CỐ ĐỊNH theo luật chơi, không bao giờ
      // đổi kể cả kỳ chia giải — bất biến mạnh nhất để kiểm tra.
      final kk = s.prizeTiers.last;
      if (kk.name.contains('Khuyến Khích') && kk.valueVnd != 10000) {
        throw FormatException('Giải Khuyến Khích phải luôn = 10.000, đọc được ${kk.valueVnd}');
      }
      for (final p in s.prizeTiers) {
        if (p.count < 0 || p.count > 200000) {
          throw FormatException('SL hạng "${p.name}" vô lý: ${p.count}');
        }
      }
    }
  }

  /// Đọc kết quả mới nhất từ file JSON trên GitHub (repo lotto-scan) — nguồn
  /// DUY NHẤT của app (không còn cào trực tiếp trên máy). Luôn gọi mạng
  /// thật mỗi lần gọi (không có cache riêng ở đây) nên không cần tham số
  /// "forceRefresh" — khác với `DrawHistorySource`/`GithubSeedSource` vốn có
  /// cache trong RAM để tránh tải lại file CSV/JSON lớn nhiều lần.
  static Future<Snapshot> fetchFromGitHub() async {
    final resp = await GithubCdn.fetch(
      _githubResultsPath,
      timeout: _timeout,
    );
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw HttpException('HTTP ${resp.statusCode} khi đọc full_results.json');
    }
    final decoded = jsonDecode(resp.body);
    if (decoded is! List || decoded.isEmpty) {
      throw const FormatException('full_results.json rỗng hoặc sai định dạng');
    }
    final record = decoded.last as Map<String, dynamic>;
    final snap = fromJson(record, source: 'github:lotto-scan');
    validate(snap);
    return snap;
  }

  /// Dựng [Snapshot] từ 1 record JSON (đúng schema mà
  /// `scrape_full_result_json.py` ghi ra) — dùng chung cho cả
  /// [fetchFromGitHub] (gọi mạng) lẫn dữ liệu đính kèm thẳng trong tin FCM
  /// (không cần gọi mạng thêm lần nào, xem `PushService`).
  static Snapshot fromJson(Map<String, dynamic> record, {String? source}) {
    final drawId = record['draw_id'] as String;
    final drawDate = record['draw_date'] as String? ?? '';
    final drawTime = record['draw_time'] as String?;
    final numbers = (record['numbers'] as List).map((n) => n as int).toList();
    final special = record['special_number'] as int?;
    final jackpotVnd = record['jackpot_value'] as int?;

    final draw = Draw(
      drawId: drawId,
      drawDate: drawDate,
      drawTime: drawTime,
      numbers: numbers,
      special: special,
    );

    final prizeTiers = ((record['prizes'] as List?) ?? const [])
        .map((p) => PrizeTier(
              name: p['tier'] as String,
              rule: p['match'] as String? ?? '',
              count: p['count'] as int,
              valueVnd: p['value'] as int,
            ))
        .toList();

    // "share_state": trạng thái kỳ CHIA GIẢI do SERVER tính sẵn (xem
    // share_draw_machine.dart) — bản ghi cũ (trước khi thêm trường này) sẽ
    // không có, coi như null, không phải lỗi.
    final shareStateRaw = record['share_state'] as Map<String, dynamic>?;
    final shareState = shareStateRaw != null ? ServerShareState.fromJson(shareStateRaw) : null;

    return Snapshot(
      jackpotVnd: jackpotVnd,
      jackpotDrawId: drawId,
      latestDraw: draw,
      draws: [draw],
      jackpotSource: source,
      drawSource: source,
      prizeTiers: prizeTiers,
      shareState: shareState,
    );
  }
}
