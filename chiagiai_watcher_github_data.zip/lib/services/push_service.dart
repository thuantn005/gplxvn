import 'dart:async';
import 'dart:convert';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'jackpot_check_service.dart';
import 'jackpot_repository.dart';

/// Nhận tin "đánh thức" từ Firebase Cloud Messaging — GitHub Actions gọi
/// sau khi cào xong, gửi DATA MESSAGE THUẦN (không kèm field "notification")
/// nên Android KHÔNG tự hiện gì cả. Tin đính kèm THẲNG dữ liệu kỳ mới nhất
/// (field "latest_draw") — app đọc trực tiếp từ tin, KHÔNG cần gọi mạng
/// thêm lần nào. App chỉ âm thầm chạy `JackpotCheckService.runCheck()` —
/// nơi đó (qua `ShareDrawMachine` + `NotificationService`) mới là chỗ TỰ
/// QUYẾT ĐỊNH có thông báo hay không.
const String kPushTopic = 'chiagiai_updates';

/// Đọc field "latest_draw" (JSON đã được stringify) trong tin FCM, nếu có.
/// Trả về null nếu tin không kèm dữ liệu (vd tin cũ dạng chỉ đánh thức) —
/// lúc đó runCheck() sẽ tự đọc lại từ GitHub như bình thường.
Snapshot? _snapshotFromMessage(RemoteMessage message) {
  final raw = message.data['latest_draw'];
  if (raw == null || raw.isEmpty) return null;
  try {
    final record = jsonDecode(raw) as Map<String, dynamic>;
    return JackpotRepository.fromJson(record, source: 'fcm');
  } catch (_) {
    // Du lieu dinh kem loi/hong -> bo qua, de runCheck() tu doc lai tu
    // GitHub thay vi lam sap ca lan kiem tra.
    return null;
  }
}

/// Bắt buộc là top-level function + @pragma — hàm này chạy trong 1 isolate
/// riêng, tách biệt hoàn toàn với isolate UI khi app đang ở background/đã
/// bị tắt hẳn, nên phải tự Firebase.initializeApp() lại, không dùng chung
/// state đã khởi tạo bên main().
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  await JackpotCheckService.runCheck(preloadedSnapshot: _snapshotFromMessage(message));
}

class PushService {
  static Future<void> initialize() async {
    await Firebase.initializeApp();
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

    // App đang MỞ SẴN (foreground) lúc tin đến -> onBackgroundMessage
    // không được gọi (đây là hành vi bình thường của FCM, không phải lỗi
    // thiếu cấu hình), nên cần nghe thêm onMessage để phủ đúng trường hợp
    // này, tránh bỏ lỡ lần cào khi người dùng đang mở app.
    FirebaseMessaging.onMessage.listen((message) {
      unawaited(JackpotCheckService.runCheck(preloadedSnapshot: _snapshotFromMessage(message)));
    });

    // Đăng ký nhận tin của đúng topic mà GitHub Actions sẽ gửi tới.
    await FirebaseMessaging.instance.subscribeToTopic(kPushTopic);
  }
}
