import 'dart:async';
import 'dart:convert';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'jackpot_check_service.dart';
import 'jackpot_repository.dart';

/// Nhận tin "đánh thức" từ Firebase Cloud Messaging — GitHub Actions gọi
/// sau khi cào xong, gửi DATA MESSAGE THUẦN (không kèm field "notification")
/// nên Android KHÔNG tự hiện gì cả. Tin đính kèm THẲNG dữ liệu kỳ mới nhất
/// (field "latest_draw") — app đọc trực tiếp từ tin, KHÔNG cần gọi mạng
/// thêm lần nào. App chỉ âm thầm chạy `JackpotCheckService.runCheck()` —
/// nơi đó (qua `ShareDrawMachine` + `NotificationService`) mới là chỗ TỰ
/// QUYẾT ĐỊNH có thông báo hay không.
const String kPushTopic = 'chiagiai_updates';

/// Đọc field "latest_draw" (JSON đã được stringify) trong tin FCM, nếu có.
/// Trả về null nếu tin không kèm dữ liệu (vd tin cũ dạng chỉ đánh thức) —
/// lúc đó runCheck() sẽ tự đọc lại từ GitHub như bình thường.
Snapshot? _snapshotFromMessage(RemoteMessage message) {
  final raw = message.data['latest_draw'];
  if (raw == null || raw.isEmpty) return null;
  try {
    final record = jsonDecode(raw) as Map<String, dynamic>;
    final snap = JackpotRepository.fromJson(record, source: 'fcm');
    JackpotRepository.validate(snap);
    return snap;
  } catch (_) {
    // Du lieu dinh kem loi/hong/khong hop le -> bo qua, de runCheck() tu
    // doc lai tu GitHub (co kiem tra lai o do) thay vi lam sap ca lan
    // kiem tra hoac hien so sai.
    return null;
  }
}

/// Bắt buộc là top-level function + @pragma — hàm này chạy trong 1 isolate
/// riêng, tách biệt hoàn toàn với isolate UI khi app đang ở background/đã
/// bị tắt hẳn, nên phải tự Firebase.initializeApp() lại, không dùng chung
/// state đã khởi tạo bên main().
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  await JackpotCheckService.runCheck(preloadedSnapshot: _snapshotFromMessage(message));
}

class PushService {
  static Future<void> initialize() async {
    // Toan bo qua trinh nay co goi mang (dang ky voi server FCM) — gioi
    // han thoi gian + bat loi CHAT, vi ham nay gio chay unawaited() sau
    // runApp() (xem main.dart): khong con chan giao dien nua, nhung neu
    // khong bat loi thi 1 loi/timeout o day se thanh "unhandled exception"
    // am tham trong log, va ban than lenh subscribeToTopic() khong tu co
    // timeout - can boc bang .timeout() thu cong.
    try {
      await Firebase.initializeApp().timeout(const Duration(seconds: 15));
      FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

      // App đang MỞ SẴN (foreground) lúc tin đến -> onBackgroundMessage
      // không được gọi (đây là hành vi bình thường của FCM, không phải lỗi
      // thiếu cấu hình), nên cần nghe thêm onMessage để phủ đúng trường hợp
      // này, tránh bỏ lỡ lần cào khi người dùng đang mở app.
      FirebaseMessaging.onMessage.listen((message) {
        unawaited(JackpotCheckService.runCheck(preloadedSnapshot: _snapshotFromMessage(message)));
      });

      // App đang Ở NỀN (chưa tắt hẳn) và người dùng BẤM vào thông báo hệ
      // thống để mở lại app -> tin này KHÔNG đi qua onBackgroundMessage
      // hay onMessage, mà qua đường riêng onMessageOpenedApp. Không xử lý
      // ở đây thì lúc mở app coi như "không có gì xảy ra" dù chính tin đó
      // đã đánh thức app.
      FirebaseMessaging.onMessageOpenedApp.listen((message) {
        unawaited(JackpotCheckService.runCheck(preloadedSnapshot: _snapshotFromMessage(message)));
      });

      // App ĐÃ BỊ TẮT HẲN (không còn tiến trình nào) và người dùng BẤM vào
      // thông báo để MỞ LẠI TỪ ĐẦU -> onBackgroundMessage lẽ ra đã chạy
      // lúc tin đến (kể cả khi app đã tắt, Android vẫn có thể đánh thức 1
      // isolate riêng để chạy handler), NHƯNG một số hãng máy (đặc biệt
      // OPPO/ColorOS, Xiaomi/MIUI, Vivo...) chủ động CHẶN việc này nếu
      // người dùng chưa bật "Tự khởi chạy"/"Autostart" cho app trong cài
      // đặt hệ thống — khi đó handler nền không chạy, dữ liệu không được
      // cập nhật cho tới khi app tự mở. getInitialMessage() lấy lại ĐÚNG
      // tin đã khiến hệ thống hiện thông báo đó (do OS lưu sẵn, không phụ
      // thuộc handler nền có chạy được hay không) — lớp bảo hiểm cuối
      // cùng để chắc chắn đọc được kết quả mới nhất ngay khi app vừa mở,
      // dù mọi đường khác đều bị hãng máy chặn.
      final initialMessage = await FirebaseMessaging.instance.getInitialMessage();
      if (initialMessage != null) {
        unawaited(JackpotCheckService.runCheck(preloadedSnapshot: _snapshotFromMessage(initialMessage)));
      }

      // Đăng ký nhận tin của đúng topic mà GitHub Actions sẽ gửi tới.
      await FirebaseMessaging.instance.subscribeToTopic(kPushTopic).timeout(const Duration(seconds: 15));
    } catch (e) {
      // Mat mang / Firebase loi luc mo app: bo qua, KHONG lam sap app.
      // WorkManager (task 3 tieng/lan) van la luoi an toan neu lan nay
      // dang ky FCM khong thanh cong - app se tu thu lai o lan mo sau.
      // ignore: avoid_print
      print('PushService.initialize() loi (bo qua, khong anh huong app): $e');
    }
  }
}
