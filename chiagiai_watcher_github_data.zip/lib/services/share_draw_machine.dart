/// DTO + hàm định dạng cho "kỳ CHIA GIẢI Độc Đắc" — port từ
/// `ShareDrawMachine.kt`.
///
/// QUAN TRỌNG: phần TÍNH TOÁN (state machine — khi nào coi là "đã xác định
/// kỳ chia giải", "nhắc tối nay", "huỷ", "hoàn tất"...) ĐÃ CHUYỂN SANG CHẠY
/// TRÊN SERVER (GitHub Actions, script `share_draw_machine.py` trong repo
/// `lotto-scan`), KHÔNG còn chạy trên từng máy nữa.
///
/// Lý do: máy chủ chạy 2 lần/ngày đều đặn theo đúng lịch quay, nên trạng
/// thái luôn nhất quán. Nếu để MỖI MÁY tự tính lấy (như trước đây), máy nào
/// mất mạng/tắt app đúng lúc có biến động (bỏ lỡ 1-2 lần kiểm tra) sẽ tính
/// RA KẾT QUẢ KHÁC với máy khác — dẫn tới có máy báo "kỳ chia giải" sai kỳ,
/// có máy không báo dù đã tới ngày, hai người dùng thấy hai trạng thái khác
/// nhau cho CÙNG 1 kỳ quay thực tế. Server tính 1 lần, LUÔN đúng, rồi gửi
/// kết quả (trường `share_state` trong `full_results.json`, kèm cả trong
/// tin FCM) — app chỉ HIỂN THỊ LẠI đúng những gì server đã tính, không tự
/// suy luận thêm.
library share_draw_machine;

enum EventKind { scheduled, reminder, cancelled, completed, scrapeFail, newDraw, missed }

class ShareDrawEvent {
  final EventKind kind;
  final String title;
  final String message;
  final bool urgent;

  ShareDrawEvent({
    required this.kind,
    required this.title,
    required this.message,
    this.urgent = false,
  });
}

/// Trạng thái kỳ chia giải — CHỈ LÀ BẢN SAO (mirror) của trường
/// `share_state` mà server tính sẵn và gửi kèm dữ liệu (xem
/// `JackpotRepository.fromJson`). App lưu lại để hiển thị (thẻ đếm ngược ở
/// màn hình chính), KHÔNG tự sửa/tính các trường này ở đâu khác.
class ShareDrawState {
  bool pending;
  String? shareDate; // yyyy-MM-dd
  int peakJackpot;
  String? triggerDrawId;

  ShareDrawState({
    this.pending = false,
    this.shareDate,
    this.peakJackpot = 0,
    this.triggerDrawId,
  });

  Map<String, dynamic> toJson() => {
        'pending': pending,
        'shareDate': shareDate,
        'peakJackpot': peakJackpot,
        'triggerDrawId': triggerDrawId,
      };

  factory ShareDrawState.fromJson(Map<String, dynamic> json) => ShareDrawState(
        pending: json['pending'] as bool? ?? false,
        shareDate: json['shareDate'] as String?,
        peakJackpot: json['peakJackpot'] as int? ?? 0,
        triggerDrawId: json['triggerDrawId'] as String?,
      );
}

/// 1 sự kiện chia giải mà SERVER đã xác định (đính kèm trong `share_state`
/// → `last_event`) — có `id` duy nhất để app so sánh, tránh báo trùng nếu
/// đọc lại cùng 1 sự kiện qua nhiều lần fetch (FCM + mở app + kiểm tra nền
/// đều có thể cùng thấy sự kiện này).
class ServerShareEvent {
  final String id;
  final EventKind kind;
  final String titleVi;
  final String titleEn;
  final String messageVi;
  final String messageEn;
  final bool urgent;

  ServerShareEvent({
    required this.id,
    required this.kind,
    required this.titleVi,
    required this.titleEn,
    required this.messageVi,
    required this.messageEn,
    this.urgent = false,
  });

  static EventKind _kindFromName(String? name) {
    switch (name) {
      case 'scheduled':
        return EventKind.scheduled;
      case 'reminder':
        return EventKind.reminder;
      case 'cancelled':
        return EventKind.cancelled;
      case 'completed':
        return EventKind.completed;
      default:
        return EventKind.scheduled;
    }
  }

  static ServerShareEvent? fromJson(Map<String, dynamic>? json) {
    if (json == null) return null;
    final id = json['id'] as String?;
    if (id == null || id.isEmpty) return null;
    return ServerShareEvent(
      id: id,
      kind: _kindFromName(json['kind'] as String?),
      titleVi: json['title_vi'] as String? ?? '',
      titleEn: json['title_en'] as String? ?? '',
      messageVi: json['message_vi'] as String? ?? '',
      messageEn: json['message_en'] as String? ?? '',
      urgent: json['urgent'] as bool? ?? false,
    );
  }
}

class ShareDrawMachine {
  /// Vẫn giữ NGƯỠNG này ở client — chỉ dùng để hiển thị "còn cách X để tới
  /// ngưỡng" trên màn hình chính (con số tĩnh, không phải logic quyết định
  /// gì), không liên quan tới việc tính toán kỳ chia giải (đã chuyển sang
  /// server).
  static const thresholdVnd = 12000000000;

  static String fmt(int? vnd) {
    if (vnd == null) return '?';
    final s = _thousands(vnd);
    if (vnd >= 1000000000) {
      final ty = (vnd / 1e9).toStringAsFixed(1);
      return '$s (~$ty tỷ)';
    }
    return s;
  }

  static String _thousands(int v) {
    final s = v.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }
}
