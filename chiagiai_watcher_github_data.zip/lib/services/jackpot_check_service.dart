import 'app_language.dart';
import 'error_text.dart';
import 'home_widget_service.dart';
import 'jackpot_repository.dart';
import 'jackpot_storage_service.dart';
import 'notification_service.dart';
import 'share_draw_machine.dart';

/// 1 lần kiểm tra: cào dữ liệu → chạy máy trạng thái chia giải → bắn thông
/// báo. Port lõi từ `WatchWorker.kt`, giản lược phần vá lỗ hổng lịch sử qua
/// history.json (app này đã có nguồn CSV lịch sử riêng qua l1_merged, không
/// cần nguồn vá thứ hai).
class JackpotCheckService {
  static final _storage = JackpotStorageService();

  /// Trả về true nếu lần kiểm tra coi là thành công (có dữ liệu dùng được),
  /// dùng làm tín hiệu retry cho WorkManager.
  ///
  /// [preloadedSnapshot]: khi tin FCM đã đính kèm thẳng dữ liệu kỳ mới nhất
  /// (xem `PushService`), truyền vào đây để dùng ngay — KHÔNG gọi mạng
  /// thêm lần nào nữa. Để trống (mặc định) khi gọi từ WorkManager/mở app
  /// bình thường — lúc đó đọc `full_results.json` trên GitHub.
  ///
  /// [allowDirectScrapeFallback]: CHỈ bật (true) khi người dùng bấm kiểm
  /// tra tay (`JackpotBackgroundService.checkNow()`, xem home_screen.dart)
  /// — lúc đó nếu GitHub lỗi/chưa có dữ liệu, mới cào trực tiếp
  /// vietlott.vn/mirror làm dự phòng. Các lượt tự động (WorkManager, tin
  /// FCM) giữ mặc định false — KHÔNG tự ý cào trực tiếp, chỉ báo lỗi và
  /// đợi lượt kiểm tra sau (tránh app âm thầm tải HTML liên tục ở nền mà
  /// người dùng không hay).
  static Future<bool> runCheck({
    Snapshot? preloadedSnapshot,
    bool allowDirectScrapeFallback = false,
  }) async {
    final knownDrawBefore = await _storage.lastDrawId;

    // TOI UU PIN + DU LIEU: neu day la lan kiem tra TU DONG (khong phai
    // bam tay, khong co du lieu dinh kem san trong tin FCM) VA da co DUNG
    // ket qua cua ky vua qua roi -> khong can goi mang lam gi nua, dung
    // luon ket qua da co. Chi bo qua buoc nay khi: nguoi dung bam tay
    // (luon muon kiem tra lai that su), hoac tin FCM da kem san du lieu
    // (khong ton network call nao them de kiem tra dieu nay).
    if (preloadedSnapshot == null && !allowDirectScrapeFallback) {
      if (await _alreadyHaveLatestResult()) {
        await _storage.setLastStatus(t('Đã có kết quả mới nhất', 'Already up to date'));
        return true;
      }
    }

    Snapshot? snapshot = preloadedSnapshot;
    String? githubError;
    if (snapshot == null) {
      try {
        snapshot = await JackpotRepository.fetchFromGitHub();
      } catch (e) {
        githubError = '$e';
      }
    }
    if (snapshot == null && allowDirectScrapeFallback) {
      // GitHub loi hoac chua co ky moi, VA nguoi dung dang bam kiem tra
      // tay -> cao truc tiep tren may lam du phong (dieu kien mang cua
      // nguoi dung, khong bi WAF chan nhu CI).
      try {
        final allowMirrors = await _storage.useMirrors;
        snapshot = await JackpotRepository.scrape(allowMirrors: allowMirrors);
      } catch (e) {
        await _storage.setLastStatus(t(friendlyError(e), friendlyErrorEn(e)));
        return false;
      }
    }
    if (snapshot == null) {
      final err = githubError == null ? Exception('unknown') : Exception(githubError);
      await _storage.setLastStatus(t(friendlyError(err), friendlyErrorEn(err)));
      return false;
    }
    final snap = snapshot;

    final state = await _storage.loadState();
    final history = await _storage.jackpotHistory();
    final events = ShareDrawMachine.check(
      state: state,
      jackpotVnd: snap.jackpotVnd,
      lastDrawId: snap.latestDraw?.drawId ?? snap.jackpotDrawId,
      lastDrawDate: snap.latestDraw?.drawDate,
      recentJackpots: history,
    );
    await _storage.saveState(state);

    final newDraw = snap.latestDraw;
    final gotNewDraw = newDraw != null && newDraw.drawId != knownDrawBefore;
    final allEvents = [...events];

    if (gotNewDraw && knownDrawBefore != null) {
      final whenPart = _fmtDrawWhen(newDraw.drawDate, newDraw.drawTime);
      allEvents.add(ShareDrawEvent(
        kind: EventKind.newDraw,
        title: '🎲 Kết quả kỳ #${newDraw.drawId}${whenPart.isEmpty ? "" : " · $whenPart"}',
        message: '${newDraw.pretty()}\nĐộc Đắc: ${ShareDrawMachine.fmt(snap.jackpotVnd)}',
      ));
    }

    if (newDraw != null) {
      await _storage.setLastDrawId(newDraw.drawId);
      if (newDraw.drawDate.isNotEmpty) await _storage.setLastDrawDate(newDraw.drawDate);
      await _storage.setLastDrawTime(newDraw.drawTime);
    }
    if (snap.jackpotVnd != null) {
      await _storage.setLastJackpot(snap.jackpotVnd!);
      if (newDraw != null) {
        await _storage.pushJackpotEntry(
          drawId: newDraw.drawId,
          drawDate: newDraw.drawDate,
          jackpotVnd: snap.jackpotVnd!,
        );
      }
    }
    await _storage.setPrizeTiers(snap.prizeTiers);

    // Ghi log cac moc chia giai quan trong de thong ke tan suat sau nay.
    final now = DateTime.now();
    for (final e in events) {
      if (e.kind == EventKind.scheduled || e.kind == EventKind.completed || e.kind == EventKind.cancelled) {
        await _storage.appendShareDrawLog(ShareDrawLogEntry(
          loggedAtIso: now.toIso8601String(),
          kind: e.kind.name,
          jackpotVnd: snap.jackpotVnd,
          shareDate: state.shareDate,
        ));
      }
    }

    var id = 4000;
    for (final e in allEvents) {
      if (await _storage.isEnabled(e.kind)) {
        await NotificationService.show(e, id++);
      }
    }

    final ok = snap.jackpotVnd != null || newDraw != null;
    await _storage.setLastDrawText(
      newDraw != null ? '#${newDraw.drawId} — ${newDraw.pretty()}' : '⚠️ Không đọc được dãy số',
    );
    final sourceSummary = [
      if (snap.jackpotSource != null) 'Độc Đắc: ${snap.jackpotSource}',
      if (snap.drawSource != null && snap.drawSource != snap.jackpotSource)
        'Kỳ quay: ${snap.drawSource}',
    ].join(' · ');
    // Truoc day khi khong co nguon nao tra du lieu, ta chi ghi chung chung
    // "khong nguon nao tra loi" va vut bo ly do that su (snap.errors) - lam
    // khong the biet la do timeout, HTTP loi, hay parse that bai. Gio hien
    // thi thang loi dau tien de con biet duong ma sua.
    await _storage.setLastSource(
      sourceSummary.isNotEmpty
          ? sourceSummary
          : (snap.errors.isNotEmpty ? snap.errors.first : 'không nguồn nào trả lời'),
    );
    await _storage.setLastStatus(
      ok ? 'Cập nhật ${_fmtTime(now)}' : 'Không lấy được gì lúc ${_fmtTime(now)}',
    );

    // Đẩy dữ liệu mới nhất sang Widget màn hình chính (nếu người dùng đã
    // gắn widget) — an toàn khi lỗi (không có widget nào được gắn, hoặc
    // máy không hỗ trợ), không ảnh hưởng luồng kiểm tra chính.
    await HomeWidgetService.push(
      jackpotVnd: snap.jackpotVnd,
      drawId: newDraw?.drawId,
      drawDate: newDraw?.drawDate,
      drawTime: newDraw?.drawTime,
    );

    return ok;
  }

  /// So sánh kỳ đã lưu (lastDrawDate/lastDrawTime) với kỳ VỪA QUA (13:00
  /// hoặc 21:00 gần nhất trước "bây giờ") — TRÙNG thì coi là đã cập nhật,
  /// không cần gọi mạng nữa. Cùng công thức với `_updateCountdown()` bên
  /// home_screen.dart (xác định "đang chờ kết quả" trên UI).
  static Future<bool> _alreadyHaveLatestResult() async {
    final now = DateTime.now();
    final today13 = DateTime(now.year, now.month, now.day, 13, 0);
    final today21 = DateTime(now.year, now.month, now.day, 21, 0);
    DateTime justPassed;
    String justPassedTime;
    if (now.isBefore(today13)) {
      justPassed = today13.subtract(const Duration(hours: 16)); // 21:00 hôm trước
      justPassedTime = '21:00';
    } else if (now.isBefore(today21)) {
      justPassed = today13;
      justPassedTime = '13:00';
    } else {
      justPassed = today21;
      justPassedTime = '21:00';
    }
    final justPassedDateIso =
        '${justPassed.year.toString().padLeft(4, '0')}-${justPassed.month.toString().padLeft(2, '0')}-${justPassed.day.toString().padLeft(2, '0')}';

    final lastDate = await _storage.lastDrawDate;
    final lastTime = await _storage.lastDrawTime;
    return lastDate == justPassedDateIso && lastTime == justPassedTime;
  }

  static String _fmtTime(DateTime t) {
    final h = t.hour.toString().padLeft(2, '0');
    final m = t.minute.toString().padLeft(2, '0');
    final d = t.day.toString().padLeft(2, '0');
    final mo = t.month.toString().padLeft(2, '0');
    return '$h:$m $d/$mo/${t.year}';
  }

  /// "2026-09-01" + "13:00" -> "01/09/2026 - 13:00". Rỗng nếu thiếu ngày.
  static String _fmtDrawWhen(String? isoDate, String? time) {
    if (isoDate == null || isoDate.isEmpty) return '';
    final parts = isoDate.split('-');
    if (parts.length != 3) return '';
    final dmy = '${parts[2]}/${parts[1]}/${parts[0]}';
    return time == null || time.isEmpty ? dmy : '$dmy - $time';
  }
}
