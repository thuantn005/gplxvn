import 'package:flutter/foundation.dart';

import 'app_language.dart';
import 'error_helper.dart';
import 'home_widget_service.dart';
import 'jackpot_repository.dart';
import 'jackpot_storage_service.dart';
import 'notification_service.dart';
import 'share_draw_machine.dart';

/// 1 lần kiểm tra: cào dữ liệu → chạy máy trạng thái chia giải → bắn thông
/// báo. Port lõi từ `WatchWorker.kt`, giản lược phần vá lỗ hổng lịch sử qua
/// history.json (app này đã có nguồn CSV lịch sử riêng qua l1_merged, không
/// cần nguồn vá thứ hai).
class JackpotCheckService {
  static final _storage = JackpotStorageService();

  /// Trả về true nếu lần kiểm tra coi là thành công (có dữ liệu dùng được),
  /// dùng làm tín hiệu retry cho WorkManager.
  ///
  /// [preloadedSnapshot]: khi tin FCM đã đính kèm thẳng dữ liệu kỳ mới nhất
  /// (xem `PushService`), truyền vào đây để dùng ngay — KHÔNG gọi mạng
  /// thêm lần nào nữa. Để trống (mặc định) khi gọi từ WorkManager/mở app
  /// bình thường — lúc đó đọc `full_results.json` trên GitHub.
  ///
  /// [forceRefresh]: bật khi người dùng CHỦ ĐỘNG bấm kiểm tra tay (xem
  /// `JackpotBackgroundService.checkNow()`) — lúc đó xoá cache CDN
  /// (jsDelivr) trước khi đọc lại, đảm bảo lấy đúng bản mới nhất ngay. App
  /// KHÔNG còn tự cào trực tiếp vietlott.vn/mirror trên máy nữa — nguồn
  /// DUY NHẤT là dữ liệu đã cào sẵn trên GitHub (đọc qua CDN), giúp tiết
  /// kiệm pin (không còn tự tải HTML + parse DOM trên máy).
  static Future<bool> runCheck({
    Snapshot? preloadedSnapshot,
    bool forceRefresh = false,
  }) async {
    final knownDrawBefore = await _storage.lastDrawId;

    Snapshot? snapshot = preloadedSnapshot;
    String? githubError;
    if (snapshot == null) {
      try {
        snapshot = await JackpotRepository.fetchFromGitHub(forceRefresh: forceRefresh);
      } catch (e) {
        githubError = friendlyError(e);
      }
    }
    if (snapshot == null) {
      await _storage.setLastStatus(githubError ??
          t('Đã có lỗi xảy ra. Vui lòng thử lại sau.',
              'Something went wrong. Please try again later.'));
      return false;
    }
    final snap = snapshot;

    // Trạng thái "kỳ chia giải" — CHỈ LÀ BẢN SAO của những gì SERVER đã
    // tính sẵn (snap.shareState), lưu lại để hiển thị thẻ đếm ngược. App
    // KHÔNG tự tính lại — xem giải thích trong share_draw_machine.dart.
    final serverState = snap.shareState;
    if (serverState != null) {
      await _storage.saveState(ShareDrawState(
        pending: serverState.pending,
        shareDate: serverState.shareDate,
        peakJackpot: serverState.peakJackpot,
        triggerDrawId: serverState.triggerDrawId,
      ));
    }

    final newDraw = snap.latestDraw;
    final gotNewDraw = newDraw != null && newDraw.drawId != knownDrawBefore;
    final allEvents = <ShareDrawEvent>[];

    if (gotNewDraw && knownDrawBefore != null) {
      final whenPart = _fmtDrawWhen(newDraw.drawDate, newDraw.drawTime);
      allEvents.add(ShareDrawEvent(
        kind: EventKind.newDraw,
        title: '🎲 Kết quả kỳ #${newDraw.drawId}${whenPart.isEmpty ? "" : " · $whenPart"}',
        message: '${newDraw.pretty()}\nĐộc Đắc: ${ShareDrawMachine.fmt(snap.jackpotVnd)}',
      ));
    }

    // Sự kiện chia giải (đã xác định/nhắc/huỷ/hoàn tất) do SERVER tính —
    // chỉ báo nếu ID khác lần báo gần nhất đã lưu (tránh báo trùng khi FCM,
    // mở app, và kiểm tra nền cùng thấy 1 sự kiện).
    final serverEvent = serverState?.lastEvent;
    if (serverEvent != null && serverEvent.id != await _storage.lastNotifiedEventId) {
      allEvents.add(ShareDrawEvent(
        kind: serverEvent.kind,
        title: t(serverEvent.titleVi, serverEvent.titleEn),
        message: t(serverEvent.messageVi, serverEvent.messageEn),
        urgent: serverEvent.urgent,
      ));
      await _storage.setLastNotifiedEventId(serverEvent.id);

      // Ghi log cac moc chia giai quan trong de thong ke tan suat sau nay.
      if (serverEvent.kind == EventKind.scheduled ||
          serverEvent.kind == EventKind.completed ||
          serverEvent.kind == EventKind.cancelled) {
        await _storage.appendShareDrawLog(ShareDrawLogEntry(
          loggedAtIso: DateTime.now().toIso8601String(),
          kind: serverEvent.kind.name,
          jackpotVnd: snap.jackpotVnd,
          shareDate: serverState?.shareDate,
        ));
      }
    }

    if (newDraw != null) {
      await _storage.setLastDrawId(newDraw.drawId);
      if (newDraw.drawDate.isNotEmpty) await _storage.setLastDrawDate(newDraw.drawDate);
      await _storage.setLastDrawTime(newDraw.drawTime);
    }
    if (snap.jackpotVnd != null) {
      await _storage.setLastJackpot(snap.jackpotVnd!);
      if (newDraw != null) {
        await _storage.pushJackpotEntry(
          drawId: newDraw.drawId,
          drawDate: newDraw.drawDate,
          jackpotVnd: snap.jackpotVnd!,
        );
      }
    }
    await _storage.setPrizeTiers(snap.prizeTiers);

    var id = 4000;
    for (final e in allEvents) {
      if (await _storage.isEnabled(e.kind)) {
        await NotificationService.show(e, id++);
      }
    }

    final now = DateTime.now();
    final ok = snap.jackpotVnd != null || newDraw != null;
    await _storage.setLastDrawText(
      newDraw != null ? '#${newDraw.drawId} — ${newDraw.pretty()}' : '⚠️ Không đọc được dãy số',
    );
    final sourceSummary = [
      if (snap.jackpotSource != null) 'Độc Đắc: ${snap.jackpotSource}',
      if (snap.drawSource != null && snap.drawSource != snap.jackpotSource)
        'Kỳ quay: ${snap.drawSource}',
    ].join(' · ');
    // Log chi tiết lỗi từng nguồn ra console cho việc debug (không hiện lên
    // UI) — vẫn giữ được lý do thật sự (timeout, HTTP lỗi, parse thất bại)
    // mà không lộ chi tiết kỹ thuật (exception, URL...) cho người dùng.
    if (snap.errors.isNotEmpty) {
      debugPrint('JackpotCheckService: nguồn lỗi -> ${snap.errors.join(' | ')}');
    }
    await _storage.setLastSource(
      sourceSummary.isNotEmpty
          ? sourceSummary
          : t('Không có nguồn nào phản hồi', 'No source responded'),
    );
    await _storage.setLastStatus(
      ok ? 'Cập nhật ${_fmtTime(now)}' : 'Không lấy được gì lúc ${_fmtTime(now)}',
    );

    // Đẩy dữ liệu mới nhất sang Widget màn hình chính (nếu người dùng đã
    // gắn widget) — an toàn khi lỗi (không có widget nào được gắn, hoặc
    // máy không hỗ trợ), không ảnh hưởng luồng kiểm tra chính.
    await HomeWidgetService.push(
      jackpotVnd: snap.jackpotVnd,
      drawId: newDraw?.drawId,
      drawDate: newDraw?.drawDate,
      drawTime: newDraw?.drawTime,
    );

    return ok;
  }

  static String _fmtTime(DateTime t) {
    final h = t.hour.toString().padLeft(2, '0');
    final m = t.minute.toString().padLeft(2, '0');
    final d = t.day.toString().padLeft(2, '0');
    final mo = t.month.toString().padLeft(2, '0');
    return '$h:$m $d/$mo/${t.year}';
  }

  /// "2026-09-01" + "13:00" -> "01/09/2026 - 13:00". Rỗng nếu thiếu ngày.
  static String _fmtDrawWhen(String? isoDate, String? time) {
    if (isoDate == null || isoDate.isEmpty) return '';
    final parts = isoDate.split('-');
    if (parts.length != 3) return '';
    final dmy = '${parts[2]}/${parts[1]}/${parts[0]}';
    return time == null || time.isEmpty ? dmy : '$dmy - $time';
  }
}
