import 'home_widget_service.dart';
import 'jackpot_repository.dart';
import 'jackpot_storage_service.dart';
import 'notification_service.dart';
import 'share_draw_machine.dart';

/// 1 lần kiểm tra: cào dữ liệu → chạy máy trạng thái chia giải → bắn thông
/// báo. Port lõi từ `WatchWorker.kt`, giản lược phần vá lỗ hổng lịch sử qua
/// history.json (app này đã có nguồn CSV lịch sử riêng qua l1_merged, không
/// cần nguồn vá thứ hai).
class JackpotCheckService {
  static final _storage = JackpotStorageService();

  /// Trả về true nếu lần kiểm tra coi là thành công (có dữ liệu dùng được),
  /// dùng làm tín hiệu retry cho WorkManager.
  ///
  /// [preloadedSnapshot]: khi tin FCM đã đính kèm thẳng dữ liệu kỳ mới nhất
  /// (xem `PushService`), truyền vào đây để dùng ngay — KHÔNG gọi mạng
  /// thêm lần nào nữa. Để trống (mặc định) khi gọi từ WorkManager/mở app
  /// bình thường — lúc đó đọc `full_results.json` trên GitHub.
  ///
  /// [allowDirectScrapeFallback]: CHỈ bật (true) khi người dùng bấm kiểm
  /// tra tay (`JackpotBackgroundService.checkNow()`, xem home_screen.dart)
  /// — lúc đó nếu GitHub lỗi/chưa có dữ liệu, mới cào trực tiếp
  /// vietlott.vn/mirror làm dự phòng. Các lượt tự động (WorkManager, tin
  /// FCM) giữ mặc định false — KHÔNG tự ý cào trực tiếp, chỉ báo lỗi và
  /// đợi lượt kiểm tra sau (tránh app âm thầm tải HTML liên tục ở nền mà
  /// người dùng không hay).
  static Future<bool> runCheck({
    Snapshot? preloadedSnapshot,
    bool allowDirectScrapeFallback = false,
  }) async {
    final knownDrawBefore = await _storage.lastDrawId;

    Snapshot? snapshot = preloadedSnapshot;
    String? githubError;
    if (snapshot == null) {
      try {
        snapshot = await JackpotRepository.fetchFromGitHub();
      } catch (e) {
        githubError = '$e';
      }
    }
    if (snapshot == null && allowDirectScrapeFallback) {
      // GitHub loi hoac chua co ky moi, VA nguoi dung dang bam kiem tra
      // tay -> cao truc tiep tren may lam du phong (dieu kien mang cua
      // nguoi dung, khong bi WAF chan nhu CI).
      try {
        final allowMirrors = await _storage.useMirrors;
        snapshot = await JackpotRepository.scrape(allowMirrors: allowMirrors);
      } catch (e) {
        await _storage.setLastStatus('Lỗi: GitHub ($githubError) · cào trực tiếp ($e)');
        return false;
      }
    }
    if (snapshot == null) {
      await _storage.setLastStatus('Lỗi đọc dữ liệu: $githubError');
      return false;
    }
    final snap = snapshot;

    final state = await _storage.loadState();
    final history = await _storage.jackpotHistory();
    final events = ShareDrawMachine.check(
      state: state,
      jackpotVnd: snap.jackpotVnd,
      lastDrawId: snap.latestDraw?.drawId ?? snap.jackpotDrawId,
      lastDrawDate: snap.latestDraw?.drawDate,
      recentJackpots: history,
    );
    await _storage.saveState(state);

    final newDraw = snap.latestDraw;
    final gotNewDraw = newDraw != null && newDraw.drawId != knownDrawBefore;
    final allEvents = [...events];

    if (gotNewDraw && knownDrawBefore != null) {
      allEvents.add(ShareDrawEvent(
        kind: EventKind.newDraw,
        title: '🎲 Kết quả kỳ #${newDraw.drawId}',
        message: '${newDraw.pretty()}\nĐộc Đắc: ${ShareDrawMachine.fmt(snap.jackpotVnd)}',
      ));
    }

    if (newDraw != null) {
      await _storage.setLastDrawId(newDraw.drawId);
      if (newDraw.drawDate.isNotEmpty) await _storage.setLastDrawDate(newDraw.drawDate);
    }
    if (snap.jackpotVnd != null) {
      await _storage.setLastJackpot(snap.jackpotVnd!);
      if (newDraw != null) {
        await _storage.pushJackpotEntry(
          drawId: newDraw.drawId,
          drawDate: newDraw.drawDate,
          jackpotVnd: snap.jackpotVnd!,
        );
      }
    }
    await _storage.setPrizeTiers(snap.prizeTiers);

    // Ghi log cac moc chia giai quan trong de thong ke tan suat sau nay.
    final now = DateTime.now();
    for (final e in events) {
      if (e.kind == EventKind.scheduled || e.kind == EventKind.completed || e.kind == EventKind.cancelled) {
        await _storage.appendShareDrawLog(ShareDrawLogEntry(
          loggedAtIso: now.toIso8601String(),
          kind: e.kind.name,
          jackpotVnd: snap.jackpotVnd,
          shareDate: state.shareDate,
        ));
      }
    }

    var id = 4000;
    for (final e in allEvents) {
      if (await _storage.isEnabled(e.kind)) {
        await NotificationService.show(e, id++);
      }
    }

    final ok = snap.jackpotVnd != null || newDraw != null;
    await _storage.setLastDrawText(
      newDraw != null ? '#${newDraw.drawId} — ${newDraw.pretty()}' : '⚠️ Không đọc được dãy số',
    );
    final sourceSummary = [
      if (snap.jackpotSource != null) 'Độc Đắc: ${snap.jackpotSource}',
      if (snap.drawSource != null && snap.drawSource != snap.jackpotSource)
        'Kỳ quay: ${snap.drawSource}',
    ].join(' · ');
    // Truoc day khi khong co nguon nao tra du lieu, ta chi ghi chung chung
    // "khong nguon nao tra loi" va vut bo ly do that su (snap.errors) - lam
    // khong the biet la do timeout, HTTP loi, hay parse that bai. Gio hien
    // thi thang loi dau tien de con biet duong ma sua.
    await _storage.setLastSource(
      sourceSummary.isNotEmpty
          ? sourceSummary
          : (snap.errors.isNotEmpty ? snap.errors.first : 'không nguồn nào trả lời'),
    );
    await _storage.setLastStatus(
      ok ? 'Cập nhật ${_fmtTime(now)}' : 'Không lấy được gì lúc ${_fmtTime(now)}',
    );

    // Đẩy dữ liệu mới nhất sang Widget màn hình chính (nếu người dùng đã
    // gắn widget) — an toàn khi lỗi (không có widget nào được gắn, hoặc
    // máy không hỗ trợ), không ảnh hưởng luồng kiểm tra chính.
    await HomeWidgetService.push(
      jackpotVnd: snap.jackpotVnd,
      drawId: newDraw?.drawId,
    );

    return ok;
  }

  static String _fmtTime(DateTime t) {
    final h = t.hour.toString().padLeft(2, '0');
    final m = t.minute.toString().padLeft(2, '0');
    final d = t.day.toString().padLeft(2, '0');
    final mo = t.month.toString().padLeft(2, '0');
    return '$h:$m $d/$mo/${t.year}';
  }
}
