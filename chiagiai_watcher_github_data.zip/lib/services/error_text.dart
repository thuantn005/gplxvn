/// Chuyển lỗi kỹ thuật (SocketException, TimeoutException, HTTP status,
/// FormatException...) thành 1 câu ngắn gọn, dễ hiểu cho người dùng — thay
/// vì hiện nguyên văn exception (dài, có URI, errno, tên class...).
String friendlyError(Object e) {
  final s = e.toString();
  final lower = s.toLowerCase();

  if (lower.contains('failed host lookup') ||
      lower.contains('socketexception') ||
      lower.contains('network is unreachable') ||
      lower.contains('connection refused') ||
      lower.contains('connection reset')) {
    return 'Không có kết nối mạng';
  }
  if (lower.contains('timeoutexception') || lower.contains('timed out')) {
    return 'Kết nối quá chậm, thử lại sau';
  }
  if (lower.contains('handshake') || lower.contains('certificate')) {
    return 'Lỗi kết nối bảo mật, thử lại sau';
  }
  if (lower.contains('formatexception') || lower.contains('unexpected character')) {
    return 'Dữ liệu nhận được không đúng định dạng';
  }
  // Loi HTTP dang "HTTP 404 khi doc ..." da tu viet san gon gang tu code
  // goi API (khong phai exception he thong) - giu nguyen, khong can dich.
  if (s.startsWith('HTTP ')) return s;

  return 'Có lỗi xảy ra, thử lại sau';
}

/// Bản tiếng Anh song song, dùng khi `AppLanguage.isEnglish.value == true`.
String friendlyErrorEn(Object e) {
  final s = e.toString();
  final lower = s.toLowerCase();

  if (lower.contains('failed host lookup') ||
      lower.contains('socketexception') ||
      lower.contains('network is unreachable') ||
      lower.contains('connection refused') ||
      lower.contains('connection reset')) {
    return 'No internet connection';
  }
  if (lower.contains('timeoutexception') || lower.contains('timed out')) {
    return 'Connection too slow, try again later';
  }
  if (lower.contains('handshake') || lower.contains('certificate')) {
    return 'Secure connection error, try again later';
  }
  if (lower.contains('formatexception') || lower.contains('unexpected character')) {
    return 'Received data is malformed';
  }
  if (s.startsWith('HTTP ')) return s;

  return 'Something went wrong, try again later';
}
