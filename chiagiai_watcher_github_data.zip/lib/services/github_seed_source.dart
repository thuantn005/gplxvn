import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'github_cdn.dart';

/// Tải danh sách seed đang được theo dõi từ `l1_merged/merged_seed*.json`
/// trên GitHub (repo `lotto-scan`) — CÙNG file dữ liệu mà app
/// `seed_batch_tracker` dùng. Không tạo seed mới — chỉ lấy lại đúng danh
/// sách đang có sẵn để khỏi phải gõ tay.
///
/// LƯU Ý: những seed này từng trùng J1 ở MỘT kỳ trong quá khứ (theo cách
/// quét brute-force), điều này KHÔNG có nghĩa vé sinh từ seed đó có khả
/// năng trúng cao hơn vé sinh từ số bất kỳ — công thức sinh vé là hàm băm,
/// với kỳ quay MỚI (chưa xảy ra), phân bố kết quả vẫn trải đều như nhau dù
/// seed là gì.
///
/// CƠ CHẾ CHỌN POOL THEO CỬA SỔ (theo yêu cầu): khi sinh số cho kỳ N, KHÔNG
/// dùng seed từ TOÀN BỘ lịch sử — chỉ ưu tiên seed đến từ các kỳ CÁCH kỳ N
/// tối thiểu 200 kỳ, và tối đa 700 kỳ (một cửa sổ rộng 500 kỳ, kết thúc 200
/// kỳ trước N). Ví dụ sinh số cho kỳ 800: cửa sổ là kỳ [101, 600] — tức
/// "cách 200 kỳ" (800-200=600) rồi lùi thêm 500 kỳ nữa (600-500+1=101).
class GithubSeedSource {
  static const _path = 'l1_merged/merged_seed682305800400.json';

  /// Số kỳ tối thiểu phải cách kỳ đang sinh số (loại bỏ seed quá "mới" so
  /// với kỳ hiện tại).
  static const gapDraws = 200;

  /// Bề rộng cửa sổ (số kỳ) tính từ mốc [gapDraws] lùi về quá khứ.
  static const windowDraws = 500;

  static List<_RawDraw>? _cache;

  static Future<List<_RawDraw>> _fetchDraws({bool forceRefresh = false}) async {
    if (!forceRefresh && _cache != null) return _cache!;

    final resp = await GithubCdn.fetch(
      _path,
      forcePurge: forceRefresh,
      headers: {'Cache-Control': 'no-cache'},
      timeout: const Duration(seconds: 30),
    );
    if (resp.statusCode != 200) {
      throw HttpException('GitHub trả về lỗi ${resp.statusCode}');
    }

    final data = jsonDecode(resp.body) as Map<String, dynamic>;
    final drawsRaw = data['draws'] as List?;
    if (drawsRaw == null) {
      throw const FormatException('File không có mảng "draws"');
    }

    final draws = <_RawDraw>[];
    for (final item in drawsRaw) {
      final map = item as Map<String, dynamic>;
      final seeds = (map['seeds'] as List?)?.cast<int>();
      if (seeds == null || seeds.isEmpty) continue;
      draws.add(_RawDraw(map['draw_id'] as int, seeds));
    }

    if (draws.isEmpty) {
      throw const FormatException('Không có seed nào trong file (đã rỗng?)');
    }

    _cache = draws;
    return draws;
  }

  /// Trả về pool seed (DUY NHẤT, đã loại trùng) dùng để sinh số cho kỳ
  /// [targetDrawId] — đã áp dụng cửa sổ ưu tiên [gapDraws]/[windowDraws]
  /// nói trên. Truyền `null` cho [targetDrawId] khi chưa biết kỳ tiếp theo
  /// (VD lần đầu mở app, chưa từng "Kiểm tra" lần nào) — khi đó dùng tạm
  /// TOÀN BỘ dữ liệu đang có, không lọc theo cửa sổ.
  static Future<List<int>> fetchSeedsForDraw(
    int? targetDrawId, {
    bool forceRefresh = false,
  }) async {
    final draws = await _fetchDraws(forceRefresh: forceRefresh);
    return _windowFilter(draws, targetDrawId);
  }

  static List<int> _windowFilter(List<_RawDraw> draws, int? targetDrawId) {
    if (targetDrawId == null) {
      final all = <int>{};
      for (final d in draws) {
        all.addAll(d.seeds);
      }
      return all.toList();
    }

    final windowEnd = targetDrawId - gapDraws;
    final windowStart = max(1, windowEnd - windowDraws + 1);

    final inWindow = <int>{};
    for (final d in draws) {
      if (d.drawId >= windowStart && d.drawId <= windowEnd) {
        inWindow.addAll(d.seeds);
      }
    }
    if (inWindow.isNotEmpty) return inWindow.toList();

    // Chưa đủ 500 kỳ lịch sử tính từ mốc "cách 200 kỳ" (kỳ hiện tại còn
    // quá sớm, VD kỳ < 701) — dùng tạm MỌI kỳ đã có, miễn là vẫn cách kỳ
    // hiện tại tối thiểu [gapDraws], để tính năng không bị "trắng" pool.
    if (windowEnd >= 1) {
      final fallback = <int>{};
      for (final d in draws) {
        if (d.drawId <= windowEnd) fallback.addAll(d.seeds);
      }
      if (fallback.isNotEmpty) return fallback.toList();
    }

    // Vẫn rỗng (kỳ hiện tại < gapDraws, gần như không xảy ra trong thực
    // tế) — dùng tạm toàn bộ dữ liệu đang có, thà có còn hơn không.
    final all = <int>{};
    for (final d in draws) {
      all.addAll(d.seeds);
    }
    return all.toList();
  }
}

class _RawDraw {
  final int drawId;
  final List<int> seeds;
  _RawDraw(this.drawId, this.seeds);
}
