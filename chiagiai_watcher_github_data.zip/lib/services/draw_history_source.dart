import 'dart:convert';
import 'dart:io';

import '../models/draw.dart';
import 'github_cdn.dart';

/// Cào file CSV lịch sử toàn bộ các kỳ Lotto 5/35 từ GitHub, dùng RIÊNG cho
/// mục thống kê tần suất số (khác với nguồn xosominhngoc.net.vn — nguồn đó
/// chỉ cho kỳ mới nhất, không có lịch sử).
///
/// File có ~850+ dòng, mỗi dòng 1 kỳ, cột `result_json` chứa JSON dạng
/// {"numbers":[...5 số...],"special_numbers":[1 số]}. Một số cột khác
/// (attributes_json, ...) cũng là JSON lồng trong CSV nên KHÔNG thể tách
/// dòng bằng split(',') đơn giản — phải tự bóc theo chuẩn CSV (RFC 4180:
/// field trong dấu " " có thể chứa dấu phẩy, dấu " lặp đôi "" nghĩa là 1
/// dấu " thật).
class DrawHistorySource {
  static const _path = 'data/all.csv';

  static const _timeout = Duration(seconds: 30);

  // Cache tam trong RAM (khong luu dia) - tan suat va lich su deu doc CUNG
  // 1 file CSV, cache o day de mo tab Thong Ke chi ton 1 lan tai mang thay
  // vi 2 lan (moi ham fetch rieng se dung lai chuoi da tai thay vi goi
  // mang lai tu dau).
  static String? _csvCache;

  static Future<String> _fetch({bool forceRefresh = false}) async {
    if (!forceRefresh && _csvCache != null) return _csvCache!;
    final resp = await GithubCdn.fetch(_path, timeout: _timeout);
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw HttpException('HTTP ${resp.statusCode}');
    }
    _csvCache = resp.body;
    return resp.body;
  }

  /// Bóc 1 dòng CSV theo chuẩn RFC 4180 (field trong "..." có thể chứa dấu
  /// phẩy; "" bên trong field nghĩa là 1 dấu " thật).
  static List<String> _parseCsvLine(String line) {
    final result = <String>[];
    final buf = StringBuffer();
    var inQuotes = false;
    for (var i = 0; i < line.length; i++) {
      final c = line[i];
      if (inQuotes) {
        if (c == '"') {
          if (i + 1 < line.length && line[i + 1] == '"') {
            buf.write('"');
            i++;
          } else {
            inQuotes = false;
          }
        } else {
          buf.write(c);
        }
      } else {
        if (c == '"') {
          inQuotes = true;
        } else if (c == ',') {
          result.add(buf.toString());
          buf.clear();
        } else {
          buf.write(c);
        }
      }
    }
    result.add(buf.toString());
    return result;
  }

  /// Cào + tính tần suất từng số (1-35 cho số chính, 1-12 cho số đặc biệt)
  /// và kỳ gần nhất mỗi số xuất hiện, để tính "gan" (số kỳ chưa về).
  /// Trả về null nếu không đọc được đủ dữ liệu.
  static Future<NumberFreqStats?> fetchAndCompute({bool forceRefresh = false}) async {
    final csv = await _fetch(forceRefresh: forceRefresh);
    final lines = const LineSplitter().convert(csv);
    if (lines.length < 2) return null;

    final mainFreq = {for (var n = 1; n <= 35; n++) n: 0};
    final specialFreq = {for (var n = 1; n <= 12; n++) n: 0};
    final mainLast = <int, String>{};
    final specialLast = <int, String>{};
    String? firstId;
    String? lastId;
    var count = 0;

    for (var i = 1; i < lines.length; i++) {
      final line = lines[i].trim();
      if (line.isEmpty) continue;
      final cols = _parseCsvLine(line);
      if (cols.length < 5) continue;
      if (cols[0] != 'lotto535') continue; // phong khi file gom nhieu san pham
      final drawId = cols[1];
      Map<String, dynamic> parsed;
      try {
        parsed = jsonDecode(cols[4]) as Map<String, dynamic>;
      } catch (_) {
        continue;
      }
      final numbers = (parsed['numbers'] as List?)?.whereType<int>().toList();
      final specials = (parsed['special_numbers'] as List?)?.whereType<int>().toList();
      if (numbers == null || numbers.length != 5) continue;
      if (specials == null || specials.isEmpty) continue;

      firstId ??= drawId;
      lastId = drawId;
      count++;
      for (final n in numbers) {
        if (n >= 1 && n <= 35) {
          mainFreq[n] = (mainFreq[n] ?? 0) + 1;
          mainLast[n] = drawId;
        }
      }
      final sp = specials.first;
      if (sp >= 1 && sp <= 12) {
        specialFreq[sp] = (specialFreq[sp] ?? 0) + 1;
        specialLast[sp] = drawId;
      }
    }

    if (count == 0 || firstId == null || lastId == null) return null;
    return NumberFreqStats(
      mainFreq: mainFreq,
      specialFreq: specialFreq,
      mainLastDrawId: mainLast,
      specialLastDrawId: specialLast,
      totalDraws: count,
      firstDrawId: firstId,
      lastDrawId: lastId,
      fetchedAt: DateTime.now(),
    );
  }
  /// Tra cứu kết quả THẬT của các kỳ trong [drawIds] — dùng để so sánh với
  /// vé đã sinh (mục "Lịch sử" ở tab Sinh Số). Chỉ trả về những kỳ ĐÃ quay
  /// (đã có trong file CSV lịch sử); kỳ chưa quay sẽ không có trong map trả
  /// về (không phải lỗi — coi như "chưa có kết quả để so").
  static Future<Map<String, Draw>> fetchResultsFor(Set<String> drawIds, {bool forceRefresh = false}) async {
    if (drawIds.isEmpty) return {};
    final wanted = drawIds.map((id) => id.padLeft(5, '0')).toSet();
    final csv = await _fetch(forceRefresh: forceRefresh);
    final lines = const LineSplitter().convert(csv);
    final out = <String, Draw>{};
    for (var i = 1; i < lines.length; i++) {
      final line = lines[i].trim();
      if (line.isEmpty) continue;
      final cols = _parseCsvLine(line);
      if (cols.length < 5) continue;
      if (cols[0] != 'lotto535') continue;
      final drawId = cols[1].padLeft(5, '0');
      if (!wanted.contains(drawId)) continue;
      Map<String, dynamic> parsed;
      try {
        parsed = jsonDecode(cols[4]) as Map<String, dynamic>;
      } catch (_) {
        continue;
      }
      final numbers = (parsed['numbers'] as List?)?.whereType<int>().toList();
      final specials = (parsed['special_numbers'] as List?)?.whereType<int>().toList();
      if (numbers == null || numbers.length != 5) continue;
      if (specials == null || specials.isEmpty) continue;
      out[drawId] = Draw(
        drawId: drawId,
        drawDate: cols.length > 2 ? cols[2] : '',
        numbers: numbers..sort(),
        special: specials.first,
      );
      if (out.length == wanted.length) break;
    }
    return out;
  }

  /// Trả về TOÀN BỘ lịch sử kỳ quay đã đọc được (mới nhất trước), dùng cho
  /// mục "Lịch sử tất cả kỳ quay" ở tab Thống Kê.
  static Future<List<Draw>> fetchAllDraws({bool forceRefresh = false}) async {
    final csv = await _fetch(forceRefresh: forceRefresh);
    final lines = const LineSplitter().convert(csv);
    final draws = <Draw>[];
    for (var i = 1; i < lines.length; i++) {
      final line = lines[i].trim();
      if (line.isEmpty) continue;
      final cols = _parseCsvLine(line);
      if (cols.length < 5) continue;
      if (cols[0] != 'lotto535') continue;
      Map<String, dynamic> parsed;
      try {
        parsed = jsonDecode(cols[4]) as Map<String, dynamic>;
      } catch (_) {
        continue;
      }
      final numbers = (parsed['numbers'] as List?)?.whereType<int>().toList();
      final specials = (parsed['special_numbers'] as List?)?.whereType<int>().toList();
      if (numbers == null || numbers.length != 5) continue;
      if (specials == null || specials.isEmpty) continue;
      draws.add(Draw(
        drawId: cols[1].padLeft(5, '0'),
        drawDate: cols.length > 2 ? cols[2] : '',
        numbers: numbers..sort(),
        special: specials.first,
      ));
    }
    draws.sort((a, b) => (int.tryParse(b.drawId) ?? 0).compareTo(int.tryParse(a.drawId) ?? 0));
    return draws;
  }
}

/// Kết quả tính tần suất — có thể lưu/đọc JSON để cache, khỏi phải cào lại
/// ~850 dòng mỗi lần mở tab Thống Kê.
class NumberFreqStats {
  final Map<int, int> mainFreq;
  final Map<int, int> specialFreq;
  final Map<int, String> mainLastDrawId;
  final Map<int, String> specialLastDrawId;
  final int totalDraws;
  final String firstDrawId;
  final String lastDrawId;
  final DateTime fetchedAt;

  NumberFreqStats({
    required this.mainFreq,
    required this.specialFreq,
    required this.mainLastDrawId,
    required this.specialLastDrawId,
    required this.totalDraws,
    required this.firstDrawId,
    required this.lastDrawId,
    required this.fetchedAt,
  });

  /// Số kỳ đã trôi qua kể từ lần cuối [n] (số chính) về — 0 nếu về ở kỳ mới
  /// nhất, totalDraws nếu chưa từng thấy trong toàn bộ dữ liệu.
  int mainGan(int n) {
    final last = mainLastDrawId[n];
    if (last == null) return totalDraws;
    return (int.tryParse(lastDrawId) ?? 0) - (int.tryParse(last) ?? 0);
  }

  int specialGan(int n) {
    final last = specialLastDrawId[n];
    if (last == null) return totalDraws;
    return (int.tryParse(lastDrawId) ?? 0) - (int.tryParse(last) ?? 0);
  }

  Map<String, dynamic> toJson() => {
        'mainFreq': mainFreq.map((k, v) => MapEntry(k.toString(), v)),
        'specialFreq': specialFreq.map((k, v) => MapEntry(k.toString(), v)),
        'mainLastDrawId': mainLastDrawId.map((k, v) => MapEntry(k.toString(), v)),
        'specialLastDrawId': specialLastDrawId.map((k, v) => MapEntry(k.toString(), v)),
        'totalDraws': totalDraws,
        'firstDrawId': firstDrawId,
        'lastDrawId': lastDrawId,
        'fetchedAt': fetchedAt.toIso8601String(),
      };

  factory NumberFreqStats.fromJson(Map<String, dynamic> j) {
    Map<int, int> toIntMap(dynamic raw) =>
        (raw as Map<String, dynamic>).map((k, v) => MapEntry(int.parse(k), v as int));
    Map<int, String> toStrMap(dynamic raw) =>
        (raw as Map<String, dynamic>).map((k, v) => MapEntry(int.parse(k), v as String));
    return NumberFreqStats(
      mainFreq: toIntMap(j['mainFreq']),
      specialFreq: toIntMap(j['specialFreq']),
      mainLastDrawId: toStrMap(j['mainLastDrawId']),
      specialLastDrawId: toStrMap(j['specialLastDrawId']),
      totalDraws: j['totalDraws'] as int,
      firstDrawId: j['firstDrawId'] as String,
      lastDrawId: j['lastDrawId'] as String,
      fetchedAt: DateTime.parse(j['fetchedAt'] as String),
    );
  }
}
