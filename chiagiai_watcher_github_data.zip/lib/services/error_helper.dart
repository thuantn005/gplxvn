import 'dart:async';
import 'dart:io';

import 'app_language.dart';

/// Chuyển 1 exception bất kỳ (network, parse, timeout...) thành 1 câu
/// thông báo CHUNG CHUNG, dễ hiểu cho người dùng — không lộ chi tiết kỹ
/// thuật (tên class exception, URL, host, stack trace...).
///
/// Chi tiết thật của lỗi vẫn được in ra console (`debugPrint`) ở nơi gọi
/// nếu cần, chỉ riêng CHUỖI HIỂN THỊ LÊN UI là được rút gọn qua hàm này.
String friendlyError(Object e) {
  if (e is SocketException || e is HttpException || e is TimeoutException) {
    return t('Lỗi kết nối mạng. Vui lòng kiểm tra Internet và thử lại.',
        'Network error. Please check your connection and try again.');
  }
  final s = e.toString();
  if (s.contains('SocketException') ||
      s.contains('ClientException') ||
      s.contains('Failed host lookup') ||
      s.contains('Connection') ||
      s.contains('TimeoutException')) {
    return t('Lỗi kết nối mạng. Vui lòng kiểm tra Internet và thử lại.',
        'Network error. Please check your connection and try again.');
  }
  return t('Đã có lỗi xảy ra. Vui lòng thử lại sau.',
      'Something went wrong. Please try again later.');
}
