# Hướng dẫn build APK/AAB qua GitHub Actions và đăng lên CH Play

Toàn bộ quá trình dưới đây **không cần cài Flutter/Android Studio trên máy**. Bạn chỉ cần trình duyệt.

---

## PHẦN 1: Đưa code lên GitHub (làm 1 lần)

1. Tạo repo mới trên GitHub, ví dụ `gplx-vn-app` (Private để bảo mật).
2. Upload toàn bộ nội dung thư mục này lên repo (kéo-thả trên web GitHub hoặc dùng git):
   ```
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/<username>/gplx-vn-app.git
   git push -u origin main
   ```
3. **QUAN TRỌNG:** Kiểm tra file `.gitignore` phải có dòng `android/key.properties` và `*.jks` để KHÔNG BAO GIỜ commit nhầm keystore lên git công khai.

---

## PHẦN 2: Tạo Keystore ký ứng dụng (làm 1 lần, giữ file này MÃI MÃI)

Keystore là "chữ ký số" của app — mất file này thì **không thể update app đã đăng nữa**, phải đăng app mới hoàn toàn. Cần backup an toàn (Google Drive riêng, không chia sẻ).

Cách tạo (chỉ cần máy có Java, không cần Flutter — hoặc dùng https://keystore-explorer.org/ nếu không quen dòng lệnh):

```bash
keytool -genkey -v -keystore release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias gplx-key
```

Trả lời các câu hỏi (tên, tổ chức, quốc gia...) — không cần chính xác 100%, nhưng nhớ kỹ:
- Mật khẩu keystore (storePassword)
- Mật khẩu key (keyPassword)
- Alias: `gplx-key`

## PHẦN 3: Đưa Keystore vào GitHub Secrets (làm 1 lần)

1. Convert file `.jks` sang base64:
   ```bash
   base64 -i release-key.jks -o release-key-base64.txt
   ```
   (Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("release-key.jks")) | Out-File release-key-base64.txt`)

2. Vào repo GitHub → **Settings → Secrets and variables → Actions → New repository secret**, tạo 4 secrets:

   | Tên secret | Giá trị |
   |---|---|
   | `KEYSTORE_BASE64` | Nội dung file `release-key-base64.txt` |
   | `KEYSTORE_PASSWORD` | Mật khẩu keystore bạn đặt ở Phần 2 |
   | `KEY_PASSWORD` | Mật khẩu key bạn đặt ở Phần 2 |
   | `KEY_ALIAS` | `gplx-key` |

---

## PHẦN 4: Chạy build tự động

Workflow đã có sẵn tại `.github/workflows/build_release.yml`. Cách chạy:

**Cách 1 - Chạy thủ công:**
Vào tab **Actions** trên GitHub → chọn workflow "Build Release AAB" → **Run workflow**.

**Cách 2 - Tự động khi bạn tag phiên bản:**
```bash
git tag v1.0.0
git push origin v1.0.0
```

Sau ~5-8 phút, vào tab **Actions** → chọn lần chạy mới nhất → mục **Artifacts** phía dưới → tải về:
- `app-release-aab` → dùng file này để **upload lên Play Console**
- `app-release-apk` → dùng để tự cài thử trên điện thoại bạn (test trước khi đăng)

---

## PHẦN 5: Trước khi upload — thay các placeholder bằng thông tin thật

Trong code hiện đang dùng **Test App ID của Google** cho AdMob, bạn PHẢI thay bằng ID thật trước khi phát hành chính thức (test ID không tạo ra doanh thu):

1. Tạo tài khoản tại https://admob.google.com/ → tạo App mới → lấy **App ID**
2. Thay vào `android/app/src/main/AndroidManifest.xml`:
   ```xml
   <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY" />
   ```
3. Tạo thêm **Ad Unit ID** cho Banner và Interstitial trong AdMob Console, gắn vào code (hiện tại `home_screen.dart` mới có placeholder UI, cần thêm `BannerAd`/`InterstitialAd` thật — nói tôi nếu muốn tôi viết tiếp phần này).

---

## PHẦN 6: Đăng lên Google Play Console

1. Tạo tài khoản Developer tại https://play.google.com/console (phí $25 một lần).
2. **Tạo ứng dụng mới** → điền tên, ngôn ngữ mặc định (Tiếng Việt), loại (Ứng dụng), miễn phí.
3. Mục **Chính sách bảo mật (Privacy Policy)**: bắt buộc phải có 1 URL công khai. Dùng nội dung ở file `PRIVACY_POLICY.md` đính kèm — cách nhanh nhất là paste vào 1 trang GitHub Pages, Google Sites, hoặc Notion public.
4. Mục **App content**: khai báo Target audience (không hướng đến trẻ em), Data safety (khai báo có thu thập dữ liệu qua AdMob/IAP), Ads (Có chứa quảng cáo).
5. Mục **Store listing**: cần chuẩn bị
   - Icon 512x512px
   - Feature graphic 1024x500px
   - Ít nhất 2 ảnh chụp màn hình điện thoại
   - Mô tả ngắn (80 ký tự) + mô tả đầy đủ
6. Mục **Production → Create new release**: upload file `.aab` đã tải ở Phần 4.
7. Gửi duyệt. Lần đầu thường mất **vài giờ đến vài ngày** để Google review.

---

## Checklist trước khi bấm "Gửi để xét duyệt"

- [ ] Đã thay AdMob App ID + Ad Unit ID thật (không còn test ID)
- [ ] Đã test app chạy ổn trên file APK tải từ Actions
- [ ] Đã có URL Chính sách bảo mật công khai
- [ ] Đã đổi `applicationId` trong `build.gradle` nếu muốn tên gói riêng (không trùng app khác)
- [ ] Đã backup file `release-key.jks` ở nơi an toàn (KHÔNG để mất)
- [ ] Product ID trong Play Console (`gplx_pro_remove_ads`) khớp với `ProService.proProductId` trong code
