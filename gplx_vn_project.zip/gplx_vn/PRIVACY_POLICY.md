# Chính Sách Bảo Mật - Ôn Thi GPLX Việt Nam

*Cập nhật lần cuối: [ĐIỀN NGÀY]*

Ứng dụng "Ôn Thi GPLX Việt Nam" ("chúng tôi") tôn trọng quyền riêng tư của người dùng. Chính sách này giải thích cách chúng tôi xử lý thông tin khi bạn sử dụng ứng dụng.

## 1. Thông tin chúng tôi thu thập

- **Dữ liệu quảng cáo:** Ứng dụng sử dụng Google AdMob để hiển thị quảng cáo. AdMob có thể thu thập số nhận dạng thiết bị (Advertising ID) để cá nhân hóa quảng cáo. Xem chính sách của Google tại: https://policies.google.com/technologies/ads
- **Dữ liệu mua hàng:** Nếu bạn mua gói Pro, giao dịch được xử lý qua Google Play Billing; chúng tôi không lưu trữ thông tin thẻ/thanh toán của bạn.
- **Dữ liệu sử dụng cục bộ:** Tiến độ ôn tập, trạng thái Pro được lưu cục bộ trên thiết bị của bạn (`shared_preferences`), không gửi lên máy chủ của chúng tôi.

## 2. Chúng tôi KHÔNG thu thập

- Không thu thập tên, email, số điện thoại (trừ khi bạn tự nguyện cung cấp qua kênh hỗ trợ).
- Không truy cập danh bạ, tin nhắn, hoặc dữ liệu cá nhân khác trên thiết bị.

## 3. Chia sẻ dữ liệu với bên thứ ba

Chúng tôi sử dụng các dịch vụ bên thứ ba sau, mỗi dịch vụ có chính sách bảo mật riêng:
- Google AdMob (quảng cáo)
- Google Play Billing (thanh toán trong ứng dụng)

## 4. Quyền của bạn

Bạn có thể tắt quảng cáo cá nhân hóa trong cài đặt quảng cáo của thiết bị Android (Settings → Google → Ads → Opt out of Ads Personalization).

## 5. Trẻ em

Ứng dụng không hướng đến đối tượng dưới 13 tuổi và không cố ý thu thập dữ liệu từ trẻ em.

## 6. Liên hệ

Nếu có câu hỏi về chính sách này, liên hệ: [ĐIỀN EMAIL LIÊN HỆ CỦA BẠN]

---
*Lưu ý: Đây là bản mẫu tham khảo, không phải tư vấn pháp lý. Bạn nên tự rà soát hoặc nhờ luật sư kiểm tra trước khi công bố chính thức, đặc biệt nếu mở rộng thu thập thêm dữ liệu (ví dụ Firebase Analytics, đăng nhập tài khoản...).*
