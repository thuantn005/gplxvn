import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../services/challenge_service.dart';
import 'home_screen.dart' show QuizMode;
import 'quiz_screen.dart';
import 'qr_scan_screen.dart';

class ChallengeScreen extends StatefulWidget {
  final String defaultLicenseClass;

  const ChallengeScreen({super.key, required this.defaultLicenseClass});

  @override
  State<ChallengeScreen> createState() => _ChallengeScreenState();
}

class _ChallengeScreenState extends State<ChallengeScreen> {
  final ChallengeService _service = ChallengeService();
  final TextEditingController _codeController = TextEditingController();
  String? _errorText;

  void _createAndShare() {
    final data = _service.createChallenge(
      licenseClass: widget.defaultLicenseClass,
      questionCount: 20, // bộ đề rút gọn cho thách đấu, làm nhanh ~5-7 phút
    );
    final code = _service.encode(data);
    _showQrDialog(code, data);
  }

  void _showQrDialog(String code, ChallengeData data) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Mã thách đấu của bạn'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Cho bạn bè quét mã QR này bằng camera, hoặc bấm Chia sẻ để gửi qua Zalo/Facebook.',
              style: TextStyle(fontSize: 13),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(12),
              ),
              child: QrImageView(
                data: code,
                version: QrVersions.auto,
                size: 200,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // đóng dialog
              _startQuiz(data); // vào làm luôn để có điểm gắn kèm khi chia sẻ
            },
            child: const Text('Bắt đầu làm bài'),
          ),
          ElevatedButton.icon(
            onPressed: () {
              Share.share(
                'Thách đấu ôn thi GPLX hạng ${widget.defaultLicenseClass} với mình nhé! 🚗\n\n'
                'Mã thách đấu: $code\n\n'
                'Cách chơi: Mở app "Ôn Thi GPLX Việt Nam" → Thách đấu bạn bè → Quét QR hoặc dán mã trên.',
              );
            },
            icon: const Icon(Icons.share, size: 16),
            label: const Text('Chia sẻ'),
          ),
        ],
      ),
    );
  }

  void _startQuiz(ChallengeData data) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => QuizScreen(
          mode: QuizMode.byTopic,
          licenseClass: widget.defaultLicenseClass,
          challenge: data,
        ),
      ),
    );
  }

  Future<void> _scanQr() async {
    final result = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const QrScanScreen()),
    );
    if (result == null || !mounted) return;
    _codeController.text = result;
    _joinChallenge();
  }

  void _joinChallenge() {
    final data = _service.decode(_codeController.text);
    if (data == null) {
      setState(() => _errorText = 'Mã không hợp lệ, kiểm tra lại bạn nhé');
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => QuizScreen(
          mode: QuizMode.byTopic,
          licenseClass: data.licenseClass,
          challenge: data,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Thách đấu bạn bè')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.emoji_events_outlined, color: Colors.amber),
                        SizedBox(width: 8),
                        Text('Tạo thách đấu mới', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Tạo bộ 20 câu ngẫu nhiên hạng ${widget.defaultLicenseClass}, gửi mã cho bạn bè để cùng làm và so điểm.',
                      style: TextStyle(color: Colors.grey.shade700, fontSize: 13),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: _createAndShare,
                      icon: const Icon(Icons.send),
                      label: const Text('Tạo & Gửi thách đấu'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Row(
              children: [
                Icon(Icons.login, size: 20),
                SizedBox(width: 8),
                Text('Nhập mã bạn bè gửi', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
              ],
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _codeController,
              decoration: InputDecoration(
                hintText: 'VD: GPLX-A1-eyJjIjoiQTEi...',
                border: const OutlineInputBorder(),
                errorText: _errorText,
              ),
              onChanged: (_) {
                if (_errorText != null) setState(() => _errorText = null);
              },
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _scanQr,
              icon: const Icon(Icons.qr_code_scanner),
              label: const Text('Quét mã QR bằng camera'),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _joinChallenge,
              child: const Text('Bắt đầu thách đấu'),
            ),
          ],
        ),
      ),
    );
  }
}
