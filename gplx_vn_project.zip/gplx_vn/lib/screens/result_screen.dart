import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/question.dart';
import '../services/challenge_service.dart';
import '../widgets/result_share_card.dart';

class ResultScreen extends StatefulWidget {
  final QuizResult result;
  final String licenseClass;
  final ChallengeData? challenge; // != null nếu đây là kết quả của 1 lượt thách đấu

  const ResultScreen({
    super.key,
    required this.result,
    required this.licenseClass,
    this.challenge,
  });

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  final GlobalKey _cardKey = GlobalKey();
  final ChallengeService _challengeService = ChallengeService();
  bool _sharing = false;

  bool get _isChallenge => widget.challenge != null;

  /// So sánh với điểm đối thủ đã gửi kèm (nếu có) để hiện thông báo thắng/thua
  String? get _vsMessage {
    final c = widget.challenge;
    if (c?.creatorScore == null) return null;
    final myScore = widget.result.correctAnswers;
    final theirScore = c!.creatorScore!;
    if (myScore > theirScore) return 'Bạn thắng đối thủ $myScore - $theirScore! 🎉';
    if (myScore < theirScore) return 'Đối thủ thắng $theirScore - $myScore. Ôn thêm rồi thách đấu lại!';
    return 'Hòa $myScore - $theirScore! Đấu tiếp nào!';
  }

  Future<void> _shareResult() async {
    setState(() => _sharing = true);
    try {
      final boundary = _cardKey.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final image = await boundary.toImage(pixelRatio: 3.0);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      final pngBytes = byteData!.buffer.asUint8List();

      final tempDir = await getTemporaryDirectory();
      final file = File('${tempDir.path}/ket_qua_thi_thu.png');
      await file.writeAsBytes(pngBytes);

      String text;
      if (_isChallenge) {
        // Gắn điểm của mình vào challenge cũ, tạo mã mới để mời thách đấu tiếp
        final updated = _challengeService.withCreatorResult(
          widget.challenge!,
          widget.result.correctAnswers,
          widget.result.totalQuestions,
        );
        final newCode = _challengeService.encode(updated);
        text = 'Mình đạt ${widget.result.correctAnswers}/${widget.result.totalQuestions} câu trong bài thách đấu GPLX hạng ${widget.licenseClass}!\n\n'
            'Thách đấu lại mình không? Mã: $newCode\n\n'
            'Mở app "Ôn Thi GPLX Việt Nam" → Thách đấu bạn bè → Nhập mã trên.';
      } else {
        text = widget.result.isPassed
            ? 'Mình vừa thi thử ĐẠT trên app Ôn Thi GPLX Việt Nam! Cùng ôn thi nhé 🚗'
            : 'Đang luyện thi bằng lái trên app Ôn Thi GPLX Việt Nam, cùng ôn nào 💪';
      }

      await Share.shareXFiles([XFile(file.path)], text: text);
    } finally {
      if (mounted) setState(() => _sharing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final result = widget.result;
    return Scaffold(
      appBar: AppBar(title: Text(_isChallenge ? 'Kết quả thách đấu' : 'Kết quả')),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                RepaintBoundary(
                  key: _cardKey,
                  child: ResultShareCard(
                    result: result,
                    licenseClass: widget.licenseClass,
                  ),
                ),
                if (_vsMessage != null) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.amber.shade50,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.amber.shade200),
                    ),
                    child: Text(
                      _vsMessage!,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
                const SizedBox(height: 28),
                SizedBox(
                  width: 320,
                  child: ElevatedButton.icon(
                    onPressed: _sharing ? null : _shareResult,
                    icon: _sharing
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Icon(_isChallenge ? Icons.emoji_events_outlined : Icons.share),
                    label: Text(_sharing
                        ? 'Đang tạo ảnh...'
                        : (_isChallenge ? 'Chia sẻ & Thách đấu tiếp' : 'Chia sẻ kết quả')),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: 320,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    },
                    child: const Text('Về trang chủ'),
                  ),
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: const Text('Xem lại chi tiết bài làm'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

