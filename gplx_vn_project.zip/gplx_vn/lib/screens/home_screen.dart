import 'package:flutter/material.dart';
import 'quiz_screen.dart';
import 'settings_screen.dart';
import 'challenge_screen.dart';
import '../services/db_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _selectedClass = 'A1';
  int _dueReviewCount = 0;

  final List<String> _licenseClasses = ['A1', 'A2', 'B1', 'B2', 'C', 'D', 'E', 'F'];

  @override
  void initState() {
    super.initState();
    _loadDueCount();
  }

  Future<void> _loadDueCount() async {
    final count = await DbService.instance.getDueCount();
    if (mounted) setState(() => _dueReviewCount = count);
  }

  final List<_ModeCard> _modes = const [
    _ModeCard(
      title: 'Ôn theo chủ đề',
      subtitle: '600 câu chia theo chương',
      icon: Icons.category_outlined,
      mode: QuizMode.byTopic,
    ),
    _ModeCard(
      title: 'Câu điểm liệt',
      subtitle: 'Các câu bắt buộc phải đúng',
      icon: Icons.warning_amber_rounded,
      mode: QuizMode.diemLiet,
    ),
    _ModeCard(
      title: 'Mô phỏng tình huống',
      subtitle: '120 tình huống giao thông',
      icon: Icons.videocam_outlined,
      mode: QuizMode.simulation,
    ),
    _ModeCard(
      title: 'Thi thử',
      subtitle: 'Đề chuẩn Bộ GTVT, tính giờ',
      icon: Icons.timer_outlined,
      mode: QuizMode.examSimulator,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ôn Thi GPLX Việt Nam'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Chọn hạng bằng lái',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 10),
                  _buildClassSelector(),
                  const SizedBox(height: 24),
                  if (_dueReviewCount > 0) ...[
                    _buildReviewBanner(),
                    const SizedBox(height: 12),
                  ],
                  _buildChallengeBanner(),
                  const SizedBox(height: 24),
                  const Text(
                    'Chế độ luyện tập',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 10),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _modes.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 1.05,
                    ),
                    itemBuilder: (context, index) {
                      final m = _modes[index];
                      return _buildModeCard(m);
                    },
                  ),
                ],
              ),
            ),
          ),
          // TODO: Thay bằng AdWidget thực tế khi tích hợp google_mobile_ads
          _buildAdBannerPlaceholder(),
        ],
      ),
    );
  }

  Widget _buildClassSelector() {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: _licenseClasses.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final cls = _licenseClasses[index];
          final selected = cls == _selectedClass;
          return ChoiceChip(
            label: Text(cls),
            selected: selected,
            onSelected: (_) => setState(() => _selectedClass = cls),
          );
        },
      ),
    );
  }

  Widget _buildModeCard(_ModeCard m) {
    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => QuizScreen(
                mode: m.mode,
                licenseClass: _selectedClass,
              ),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(m.icon, size: 32, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 10),
              Text(m.title, style: const TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text(
                m.subtitle,
                style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildReviewBanner() {
    return Card(
      color: Colors.red.shade50,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: Colors.red.shade200),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => QuizScreen(
                mode: QuizMode.review,
                licenseClass: _selectedClass,
              ),
            ),
          );
          _loadDueCount(); // cập nhật lại badge sau khi ôn xong
        },
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.red.shade100,
                  shape: BoxShape.circle,
                ),
                child: Text(
                  '$_dueReviewCount',
                  style: TextStyle(color: Colors.red.shade800, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Câu hay sai cần ôn lại', style: TextStyle(fontWeight: FontWeight.w700)),
                    Text(
                      'Hệ thống tự chọn ra $_dueReviewCount câu bạn hay sai, đến lúc ôn lại',
                      style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildChallengeBanner() {
    return Card(
      color: Colors.amber.shade50,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: Colors.amber.shade200),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ChallengeScreen(defaultLicenseClass: _selectedClass),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Icon(Icons.emoji_events_outlined, color: Colors.amber.shade800, size: 28),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Thách đấu bạn bè', style: TextStyle(fontWeight: FontWeight.w700)),
                    Text(
                      'Gửi mã cho bạn, cùng làm 20 câu, so tài xem ai điểm cao hơn',
                      style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAdBannerPlaceholder() {
    return Container(
      width: double.infinity,
      height: 50,
      color: Colors.grey.shade200,
      alignment: Alignment.center,
      child: const Text(
        '[ AdMob Banner Ad ]',
        style: TextStyle(color: Colors.grey, fontSize: 12),
      ),
    );
  }
}

enum QuizMode { byTopic, diemLiet, simulation, examSimulator, review }

class _ModeCard {
  final String title;
  final String subtitle;
  final IconData icon;
  final QuizMode mode;

  const _ModeCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.mode,
  });
}
