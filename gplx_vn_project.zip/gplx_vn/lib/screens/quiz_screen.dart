import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import '../models/question.dart';
import '../services/challenge_service.dart';
import '../services/db_service.dart';
import 'home_screen.dart' show QuizMode;
import 'result_screen.dart';

class QuizScreen extends StatefulWidget {
  final QuizMode mode;
  final String licenseClass;
  final ChallengeData? challenge; // null nếu không phải chế độ thách đấu

  const QuizScreen({
    super.key,
    required this.mode,
    required this.licenseClass,
    this.challenge,
  });

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  List<Question> _questions = [];
  int _currentIndex = 0;
  int? _selectedOption;
  bool _answered = false;
  int _correctCount = 0;
  bool _failedDiemLiet = false;
  bool _loading = true;

  // Timer cho chế độ Thi thử (đề chuẩn 19 phút / 25 câu)
  Timer? _timer;
  Duration _remaining = const Duration(minutes: 19);

  @override
  void initState() {
    super.initState();
    _loadQuestions();
    if (widget.mode == QuizMode.examSimulator) {
      _startTimer();
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadQuestions() async {
    // Trong sản phẩm thật: tải từ local asset đầy đủ 600 câu hoặc từ Firestore cache.
    final raw = await rootBundle.loadString('lib/sample_data/questions_sample.json');
    final List<dynamic> data = jsonDecode(raw);
    List<Question> all = data.map((e) => Question.fromJson(e)).toList();

    // Lọc theo chế độ đã chọn
    switch (widget.mode) {
      case QuizMode.diemLiet:
        all = all.where((q) => q.isDiemLiet).toList();
        break;
      case QuizMode.simulation:
        all = all.where((q) => q.isSimulation).toList();
        break;
      case QuizMode.review:
        // Chỉ lấy các câu đã "đến hạn" ôn lại theo thuật toán spaced-repetition
        // trong DbService (ưu tiên câu sai nhiều nhất lên đầu).
        final dueIds = await DbService.instance.getDueQuestionIds();
        final dueSet = dueIds.toSet();
        all = all.where((q) => dueSet.contains(q.id)).toList();
        all.sort((a, b) => dueIds.indexOf(a.id).compareTo(dueIds.indexOf(b.id)));
        break;
      case QuizMode.byTopic:
      case QuizMode.examSimulator:
        all = all.where((q) => q.licenseClasses.contains(widget.licenseClass)).toList();
        break;
    }

    // Chế độ thách đấu: xáo câu hỏi theo đúng seed được chia sẻ, để cả 2
    // người thi đấu nhận CHÍNH XÁC cùng bộ câu hỏi & thứ tự - đảm bảo công bằng.
    if (widget.challenge != null) {
      final service = ChallengeService();
      all = service.shuffleWithSeed(all, widget.challenge!.seed, widget.challenge!.questionCount);
    }

    setState(() {
      _questions = all;
      _loading = false;
    });
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_remaining.inSeconds <= 0) {
        timer.cancel();
        _finishQuiz();
        return;
      }
      setState(() => _remaining -= const Duration(seconds: 1));
    });
  }

  void _selectOption(int index) {
    if (_answered) return;
    final q = _questions[_currentIndex];
    final isCorrect = index == q.correctIndex;
    setState(() {
      _selectedOption = index;
      _answered = true;
      if (isCorrect) {
        _correctCount++;
      } else if (q.isDiemLiet) {
        _failedDiemLiet = true;
      }
    });

    // Ghi nhận vào SQLite để phục vụ tính năng "Ôn câu hay sai" (spaced repetition).
    // Không await - không cần chặn UI chờ ghi DB xong mới cho qua câu tiếp theo.
    DbService.instance.recordAnswer(
      questionId: q.id,
      wasCorrect: isCorrect,
      isDiemLiet: q.isDiemLiet,
    );
  }

  void _nextQuestion() {
    if (_currentIndex + 1 >= _questions.length) {
      _finishQuiz();
      return;
    }
    setState(() {
      _currentIndex++;
      _selectedOption = null;
      _answered = false;
    });
  }

  void _finishQuiz() {
    _timer?.cancel();
    final result = QuizResult(
      totalQuestions: _questions.length,
      correctAnswers: _correctCount,
      failedDiemLiet: _failedDiemLiet,
      timeTaken: const Duration(minutes: 19) - _remaining,
    );
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ResultScreen(
          result: result,
          licenseClass: widget.licenseClass,
          challenge: widget.challenge,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Thi thử')),
        body: const Center(child: Text('Chưa có câu hỏi cho chế độ này.')),
      );
    }

    final q = _questions[_currentIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text('Câu ${_currentIndex + 1}/${_questions.length}'),
        actions: [
          if (widget.mode == QuizMode.examSimulator)
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Center(
                child: Text(
                  _formatDuration(_remaining),
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            LinearProgressIndicator(
              value: (_currentIndex + 1) / _questions.length,
            ),
            const SizedBox(height: 16),
            if (widget.challenge != null)
              Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.amber.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.amber.shade200),
                ),
                child: Row(
                  children: [
                    Icon(Icons.emoji_events_outlined, size: 16, color: Colors.amber.shade800),
                    const SizedBox(width: 6),
                    Text(
                      widget.challenge!.creatorScore != null
                          ? 'Thách đấu - Đối thủ đạt ${widget.challenge!.creatorScore}/${widget.challenge!.creatorTotal} câu'
                          : 'Đang làm bài thách đấu',
                      style: TextStyle(color: Colors.amber.shade900, fontSize: 12, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            if (q.isDiemLiet)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.red.shade200),
                ),
                child: Text(
                  'CÂU ĐIỂM LIỆT',
                  style: TextStyle(color: Colors.red.shade700, fontWeight: FontWeight.bold, fontSize: 12),
                ),
              ),
            const SizedBox(height: 12),
            Text(
              q.question,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 20),
            if (q.options != null)
              ...List.generate(q.options!.length, (i) => _buildOption(q, i)),
            if (_answered) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Giải thích: ${q.explanation}'),
                    if (q.memoryTip != null) ...[
                      const SizedBox(height: 6),
                      Text('Mẹo nhớ: ${q.memoryTip}',
                          style: const TextStyle(fontStyle: FontStyle.italic)),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _nextQuestion,
                  child: Text(
                    _currentIndex + 1 >= _questions.length ? 'Nộp bài' : 'Câu tiếp theo',
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildOption(Question q, int index) {
    Color? bgColor;
    if (_answered) {
      if (index == q.correctIndex) {
        bgColor = Colors.green.shade100;
      } else if (index == _selectedOption) {
        bgColor = Colors.red.shade100;
      }
    } else if (index == _selectedOption) {
      bgColor = Colors.blue.shade50;
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        onTap: () => _selectOption(index),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: bgColor ?? Colors.white,
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              CircleAvatar(
                radius: 12,
                backgroundColor: Colors.grey.shade200,
                child: Text(
                  String.fromCharCode(65 + index), // A, B, C, D
                  style: const TextStyle(fontSize: 12, color: Colors.black87),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(child: Text(q.options![index])),
            ],
          ),
        ),
      ),
    );
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }
}
