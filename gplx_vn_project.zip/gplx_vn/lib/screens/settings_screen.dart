import 'dart:async';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import '../services/pro_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final ProService _proService = ProService();
  bool _isPro = false;
  bool _loading = true;
  ProductDetails? _product;
  StreamSubscription<List<PurchaseDetails>>? _sub;

  @override
  void initState() {
    super.initState();
    _load();
    _sub = _proService.purchaseStream.listen(_onPurchaseUpdate);
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final pro = await _proService.isPro();
    final available = await _proService.isAvailable;
    ProductDetails? product;
    if (available) {
      final response = await _proService.queryProduct();
      if (response.productDetails.isNotEmpty) {
        product = response.productDetails.first;
      }
    }
    setState(() {
      _isPro = pro;
      _product = product;
      _loading = false;
    });
  }

  void _onPurchaseUpdate(List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      if (purchase.status == PurchaseStatus.purchased ||
          purchase.status == PurchaseStatus.restored) {
        await _proService.setPro(true);
        await _proService.completePurchase(purchase);
        if (mounted) setState(() => _isPro = true);
      } else if (purchase.status == PurchaseStatus.error) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Giao dịch thất bại, vui lòng thử lại.')),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cài đặt')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  color: _isPro ? Colors.green.shade50 : null,
                  child: ListTile(
                    leading: Icon(
                      _isPro ? Icons.verified : Icons.workspace_premium_outlined,
                      color: _isPro ? Colors.green : Colors.amber,
                    ),
                    title: Text(_isPro ? 'Bạn đang dùng bản Pro' : 'Nâng cấp Pro'),
                    subtitle: Text(_isPro
                        ? 'Cảm ơn bạn đã ủng hộ ứng dụng!'
                        : 'Xóa toàn bộ quảng cáo, hỗ trợ phát triển app'
                            '${_product != null ? " - ${_product!.price}" : ""}'),
                    trailing: _isPro
                        ? null
                        : ElevatedButton(
                            onPressed: _product == null
                                ? null
                                : () => _proService.buyPro(_product!),
                            child: const Text('Mua ngay'),
                          ),
                  ),
                ),
                const SizedBox(height: 12),
                ListTile(
                  leading: const Icon(Icons.restore),
                  title: const Text('Khôi phục giao dịch'),
                  onTap: () => InAppPurchase.instance.restorePurchases(),
                ),
                ListTile(
                  leading: const Icon(Icons.privacy_tip_outlined),
                  title: const Text('Chính sách bảo mật'),
                  onTap: () {
                    // TODO: mở URL chính sách bảo mật thật (dùng url_launcher)
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.star_border),
                  title: const Text('Đánh giá 5 sao cho ứng dụng'),
                  onTap: () {
                    // TODO: mở link Play Store bằng url_launcher
                  },
                ),
              ],
            ),
    );
  }
}
