import 'package:shared_preferences/shared_preferences.dart';
import 'package:in_app_purchase/in_app_purchase.dart';

/// Quản lý trạng thái gói Pro (xóa quảng cáo).
/// Product ID này phải khớp với ID bạn tạo trong Play Console > Monetize > Products.
class ProService {
  static const String proProductId = 'gplx_pro_remove_ads';
  static const String _prefsKey = 'is_pro_user';

  final InAppPurchase _iap = InAppPurchase.instance;

  Future<bool> isPro() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_prefsKey) ?? false;
  }

  Future<void> setPro(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_prefsKey, value);
  }

  Future<bool> get isAvailable => _iap.isAvailable();

  Future<ProductDetailsResponse> queryProduct() {
    return _iap.queryProductDetails({proProductId});
  }

  Future<void> buyPro(ProductDetails product) async {
    final purchaseParam = PurchaseParam(productDetails: product);
    await _iap.buyNonConsumable(purchaseParam: purchaseParam);
  }

  Stream<List<PurchaseDetails>> get purchaseStream => _iap.purchaseStream;

  Future<void> completePurchase(PurchaseDetails purchase) async {
    if (purchase.pendingCompletePurchase) {
      await _iap.completePurchase(purchase);
    }
  }
}
