import 'dart:convert';
import 'dart:math';

/// Thông tin 1 lượt thách đấu, tự chứa toàn bộ dữ liệu cần thiết trong mã
/// (không cần backend) - encode bằng base64 để dễ dán/gõ tay khi chia sẻ.
class ChallengeData {
  final String licenseClass;
  final int seed; // dùng để xáo câu hỏi theo cùng 1 thứ tự cho cả 2 người
  final int questionCount;
  final int? creatorScore; // điểm người tạo đã đạt, null nếu tự tạo chưa làm
  final int? creatorTotal;

  ChallengeData({
    required this.licenseClass,
    required this.seed,
    required this.questionCount,
    this.creatorScore,
    this.creatorTotal,
  });

  Map<String, dynamic> toJson() => {
        'c': licenseClass,
        's': seed,
        'n': questionCount,
        'cs': creatorScore,
        'ct': creatorTotal,
      };

  factory ChallengeData.fromJson(Map<String, dynamic> json) => ChallengeData(
        licenseClass: json['c'] as String,
        seed: json['s'] as int,
        questionCount: json['n'] as int,
        creatorScore: json['cs'] as int?,
        creatorTotal: json['ct'] as int?,
      );
}

class ChallengeService {
  /// Tạo mã thách đấu mới, dạng dễ đọc: GPLX-A1-XXXXXXXX
  ChallengeData createChallenge({
    required String licenseClass,
    required int questionCount,
  }) {
    final seed = Random().nextInt(999999999);
    return ChallengeData(
      licenseClass: licenseClass,
      seed: seed,
      questionCount: questionCount,
    );
  }

  /// Gắn điểm số của người tạo vào challenge để chia sẻ cho bạn bè so tài
  ChallengeData withCreatorResult(ChallengeData data, int score, int total) {
    return ChallengeData(
      licenseClass: data.licenseClass,
      seed: data.seed,
      questionCount: data.questionCount,
      creatorScore: score,
      creatorTotal: total,
    );
  }

  String encode(ChallengeData data) {
    final jsonStr = jsonEncode(data.toJson());
    final b64 = base64Url.encode(utf8.encode(jsonStr));
    return 'GPLX-${data.licenseClass}-$b64';
  }

  /// Trả về null nếu mã không hợp lệ (người dùng gõ sai/thiếu)
  ChallengeData? decode(String code) {
    try {
      final trimmed = code.trim();
      final lastDash = trimmed.lastIndexOf('-');
      if (lastDash == -1) return null;
      final b64 = trimmed.substring(lastDash + 1);
      final jsonStr = utf8.decode(base64Url.decode(b64));
      final map = jsonDecode(jsonStr) as Map<String, dynamic>;
      return ChallengeData.fromJson(map);
    } catch (_) {
      return null;
    }
  }

  /// Xáo danh sách câu hỏi theo seed cố định - đảm bảo 2 người thách đấu
  /// nhận đúng cùng thứ tự câu hỏi để so tài công bằng.
  List<T> shuffleWithSeed<T>(List<T> items, int seed, int count) {
    final list = List<T>.from(items);
    list.shuffle(Random(seed));
    return list.take(count).toList();
  }
}
