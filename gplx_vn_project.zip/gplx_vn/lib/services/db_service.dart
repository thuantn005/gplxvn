import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/question_stats.dart';

/// Quản lý toàn bộ dữ liệu cục bộ (SQLite) của app:
/// - question_stats: lịch sử làm bài từng câu, dùng cho tính năng ôn câu sai
///   theo thuật toán spaced-repetition rút gọn (SM-2 đơn giản hóa).
/// - video_cache: theo dõi video mô phỏng nào đã tải về máy để phát offline.
///
/// Đây là singleton - toàn app dùng chung 1 kết nối DB.
class DbService {
  DbService._internal();
  static final DbService instance = DbService._internal();

  Database? _db;

  Future<Database> get database async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'gplx_vn.db');

    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE question_stats (
            question_id TEXT PRIMARY KEY,
            times_seen INTEGER NOT NULL DEFAULT 0,
            times_wrong INTEGER NOT NULL DEFAULT 0,
            last_wrong_at TEXT,
            next_review_at TEXT NOT NULL,
            ease_factor REAL NOT NULL DEFAULT 2.5
          )
        ''');

        await db.execute('''
          CREATE TABLE video_cache (
            question_id TEXT PRIMARY KEY,
            local_path TEXT NOT NULL,
            downloaded_at TEXT NOT NULL,
            file_size_bytes INTEGER NOT NULL DEFAULT 0
          )
        ''');
      },
    );
  }

  // ---------------- QUESTION STATS (ôn câu sai) ----------------

  Future<QuestionStats> getStats(String questionId) async {
    final db = await database;
    final rows = await db.query(
      'question_stats',
      where: 'question_id = ?',
      whereArgs: [questionId],
    );
    if (rows.isEmpty) return QuestionStats.initial(questionId);
    return QuestionStats.fromMap(rows.first);
  }

  /// Gọi ngay sau khi người dùng trả lời 1 câu, cập nhật lịch ôn tập tiếp theo
  /// theo thuật toán spaced-repetition rút gọn:
  /// - Đúng: giãn dần khoảng cách lần ôn tới (1 ngày -> 3 -> 7 -> 14...)
  /// - Sai: đưa về ôn lại ngay hôm sau, giảm ease_factor
  /// - Câu điểm liệt sai luôn được set next_review_at = ngay bây giờ
  ///   (isDiemLiet ưu tiên tuyệt đối, không theo lịch giãn cách thông thường)
  Future<void> recordAnswer({
    required String questionId,
    required bool wasCorrect,
    required bool isDiemLiet,
  }) async {
    final current = await getStats(questionId);
    final now = DateTime.now();

    final newTimesSeen = current.timesSeen + 1;
    final newTimesWrong = current.timesWrong + (wasCorrect ? 0 : 1);

    double newEase = current.easeFactor;
    DateTime nextReview;
    DateTime? lastWrongAt = current.lastWrongAt;

    if (wasCorrect) {
      newEase = (current.easeFactor + 0.1).clamp(1.3, 3.0);
      final daysAhead = _intervalDaysForEase(newEase, current.timesSeen);
      nextReview = now.add(Duration(days: daysAhead));
    } else {
      newEase = (current.easeFactor - 0.3).clamp(1.3, 3.0);
      lastWrongAt = now;
      nextReview = isDiemLiet ? now : now.add(const Duration(days: 1));
    }

    final updated = QuestionStats(
      questionId: questionId,
      timesSeen: newTimesSeen,
      timesWrong: newTimesWrong,
      lastWrongAt: lastWrongAt,
      nextReviewAt: nextReview,
      easeFactor: newEase,
    );

    final db = await database;
    await db.insert(
      'question_stats',
      updated.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// Khoảng cách ngày tới lần ôn tiếp theo, tăng dần theo ease_factor và
  /// số lần đã ôn đúng liên tiếp - mô phỏng đường cong quên (forgetting curve).
  int _intervalDaysForEase(double ease, int timesSeenBefore) {
    if (timesSeenBefore <= 0) return 1;
    if (timesSeenBefore == 1) return 3;
    final base = timesSeenBefore == 2 ? 7 : 14;
    return (base * (ease / 2.5)).round().clamp(1, 30);
  }

  /// Danh sách question_id cần ôn lại NGAY (đến hạn hoặc quá hạn),
  /// sắp xếp ưu tiên: sai nhiều nhất lên đầu.
  Future<List<String>> getDueQuestionIds() async {
    final db = await database;
    final nowIso = DateTime.now().toIso8601String();
    final rows = await db.query(
      'question_stats',
      where: 'next_review_at <= ?',
      whereArgs: [nowIso],
      orderBy: 'times_wrong DESC',
    );
    return rows.map((r) => r['question_id'] as String).toList();
  }

  Future<int> getDueCount() async {
    final ids = await getDueQuestionIds();
    return ids.length;
  }

  // ---------------- VIDEO CACHE (mô phỏng offline) ----------------

  Future<String?> getCachedVideoPath(String questionId) async {
    final db = await database;
    final rows = await db.query(
      'video_cache',
      where: 'question_id = ?',
      whereArgs: [questionId],
    );
    if (rows.isEmpty) return null;
    return rows.first['local_path'] as String;
  }

  Future<void> saveCachedVideo({
    required String questionId,
    required String localPath,
    required int fileSizeBytes,
  }) async {
    final db = await database;
    await db.insert(
      'video_cache',
      {
        'question_id': questionId,
        'local_path': localPath,
        'downloaded_at': DateTime.now().toIso8601String(),
        'file_size_bytes': fileSizeBytes,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<int> getCachedVideoCount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) as c FROM video_cache');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<void> clearAllCache() async {
    final db = await database;
    await db.delete('video_cache');
  }
}
