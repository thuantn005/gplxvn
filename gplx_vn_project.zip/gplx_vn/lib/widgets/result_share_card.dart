import 'package:flutter/material.dart';
import '../models/question.dart';

/// Card hiển thị kết quả thi thử, được thiết kế để chụp thành ảnh chia sẻ.
/// Giữ layout đơn giản, tương phản cao, chữ to - dễ đọc khi hiển thị dạng
/// ảnh thu nhỏ trên newsfeed Facebook/Zalo.
class ResultShareCard extends StatelessWidget {
  final QuizResult result;
  final String licenseClass;

  const ResultShareCard({
    super.key,
    required this.result,
    required this.licenseClass,
  });

  @override
  Widget build(BuildContext context) {
    final passed = result.isPassed;
    final primaryColor = passed ? const Color(0xFF2E7D32) : const Color(0xFFC62828);

    return Container(
      width: 360,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [primaryColor.withOpacity(0.9), primaryColor],
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.directions_car, color: Colors.white, size: 20),
              const SizedBox(width: 6),
              const Text(
                'ÔN THI GPLX VIỆT NAM',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              'Hạng $licenseClass',
              style: TextStyle(color: primaryColor, fontWeight: FontWeight.bold, fontSize: 13),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            passed ? 'ĐẠT' : 'CHƯA ĐẠT',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 40,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '${result.correctAnswers}/${result.totalQuestions} câu đúng '
            '(${result.scorePercent.toStringAsFixed(0)}%)',
            style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500),
          ),
          if (result.failedDiemLiet) ...[
            const SizedBox(height: 6),
            const Text(
              'Sai câu điểm liệt',
              style: TextStyle(color: Colors.white70, fontSize: 12, fontStyle: FontStyle.italic),
            ),
          ],
          const SizedBox(height: 20),
          Container(height: 1, color: Colors.white.withOpacity(0.3)),
          const SizedBox(height: 12),
          const Text(
            'Thách đấu bạn bè cùng ôn thi!\nTải app tại CH Play',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white, fontSize: 12),
          ),
        ],
      ),
    );
  }
}
