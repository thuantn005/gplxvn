class Question {
  final String id;
  final String category;
  final List<String> licenseClasses;
  final String question;
  final String? imageUrl;
  final String? videoUrl;
  final List<String>? options;
  final int? correctIndex;
  final bool isDiemLiet;
  final String explanation;
  final String? memoryTip;

  Question({
    required this.id,
    required this.category,
    required this.licenseClasses,
    required this.question,
    this.imageUrl,
    this.videoUrl,
    this.options,
    this.correctIndex,
    this.isDiemLiet = false,
    required this.explanation,
    this.memoryTip,
  });

  factory Question.fromJson(Map<String, dynamic> json) {
    return Question(
      id: json['id'] as String,
      category: json['category'] as String? ?? '',
      licenseClasses: (json['license_classes'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          [],
      question: json['question'] as String,
      imageUrl: json['image_url'] as String?,
      videoUrl: json['video_url'] as String?,
      options: (json['options'] as List<dynamic>?)
          ?.map((e) => e.toString())
          .toList(),
      correctIndex: json['correct_index'] as int?,
      isDiemLiet: json['is_diem_liet'] as bool? ?? false,
      explanation: json['explanation'] as String? ?? '',
      memoryTip: json['memory_tip'] as String?,
    );
  }

  bool get isSimulation => videoUrl != null;
}

class QuizResult {
  final int totalQuestions;
  final int correctAnswers;
  final bool failedDiemLiet;
  final Duration timeTaken;

  QuizResult({
    required this.totalQuestions,
    required this.correctAnswers,
    required this.failedDiemLiet,
    required this.timeTaken,
  });

  // Đề chuẩn Bộ GTVT: cần đạt điểm tối thiểu VÀ không sai câu điểm liệt
  bool get isPassed => !failedDiemLiet && correctAnswers >= (totalQuestions * 0.9).ceil();

  double get scorePercent => (correctAnswers / totalQuestions) * 100;
}
