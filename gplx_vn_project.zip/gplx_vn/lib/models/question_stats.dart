class QuestionStats {
  final String questionId;
  final int timesSeen;
  final int timesWrong;
  final DateTime? lastWrongAt;
  final DateTime nextReviewAt;
  final double easeFactor;

  QuestionStats({
    required this.questionId,
    required this.timesSeen,
    required this.timesWrong,
    this.lastWrongAt,
    required this.nextReviewAt,
    required this.easeFactor,
  });

  factory QuestionStats.initial(String questionId) => QuestionStats(
        questionId: questionId,
        timesSeen: 0,
        timesWrong: 0,
        lastWrongAt: null,
        nextReviewAt: DateTime.now(),
        easeFactor: 2.5,
      );

  factory QuestionStats.fromMap(Map<String, dynamic> map) => QuestionStats(
        questionId: map['question_id'] as String,
        timesSeen: map['times_seen'] as int,
        timesWrong: map['times_wrong'] as int,
        lastWrongAt: map['last_wrong_at'] != null
            ? DateTime.parse(map['last_wrong_at'] as String)
            : null,
        nextReviewAt: DateTime.parse(map['next_review_at'] as String),
        easeFactor: (map['ease_factor'] as num).toDouble(),
      );

  Map<String, dynamic> toMap() => {
        'question_id': questionId,
        'times_seen': timesSeen,
        'times_wrong': timesWrong,
        'last_wrong_at': lastWrongAt?.toIso8601String(),
        'next_review_at': nextReviewAt.toIso8601String(),
        'ease_factor': easeFactor,
      };

  bool get isDue => nextReviewAt.isBefore(DateTime.now());

  double get wrongRate => timesSeen == 0 ? 0 : timesWrong / timesSeen;
}
