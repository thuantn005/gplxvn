# Giữ nguyên các class của Flutter, không cho R8/ProGuard đổi tên/xóa nhầm
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }

# Giữ nguyên các class của AdMob (google_mobile_ads) - tránh lỗi ẩn quảng cáo khi build release
-keep class com.google.android.gms.ads.** { *; }

# Giữ nguyên các class của mobile_scanner / Google ML Kit (quét mã QR)
-keep class com.google.mlkit.** { *; }
