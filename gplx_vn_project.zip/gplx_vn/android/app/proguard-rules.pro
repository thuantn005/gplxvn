# Giữ nguyên các class của Flutter, không cho R8/ProGuard đổi tên/xóa nhầm
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }

# Giữ nguyên các class của AdMob (google_mobile_ads) - tránh lỗi ẩn quảng cáo khi build release
-keep class com.google.android.gms.ads.** { *; }

# Giữ nguyên các class của mobile_scanner / Google ML Kit (quét mã QR)
-keep class com.google.mlkit.** { *; }

# Bỏ qua cảnh báo thiếu class "Play Core" (thư viện tải module động - Deferred
# Components) - Flutter engine có tham chiếu tới nhưng app này KHÔNG dùng tính
# năng đó, nên các class này không tồn tại trong project là bình thường.
# Thiếu rule này sẽ làm R8 chặn hẳn bước build release (lỗi "Missing classes").
-dontwarn com.google.android.play.core.splitcompat.**
-dontwarn com.google.android.play.core.splitinstall.**
-dontwarn com.google.android.play.core.tasks.**
